# Magic Render Pro V5W — Gemini dan Groq (0.2.9)

Baseline: revisi distribusi V5W 0.2.8, berasal dari
`Magic-Render-Pro-V5W-Playlist-Sticker-SEO-Help.zip`.

## Penyebab dan perbaikan

- `src/main/services/settingsService.ts`, `src/renderer/components/SettingsPanel.tsx`,
  `src/main/domain/project/projectFactory.ts`: default Gemini 2.5 sudah tidak
  tersedia untuk banyak project baru. Default menjadi Gemini 3.5 Flash-Lite.
  Project lama yang menerima 404 pada model 2.5 memakai daftar model milik
  key tersebut untuk mencari pengganti, mengujinya lewat permintaan vision,
  kemudian menyimpan ID yang lolos dan menyampaikan pergantiannya kepada user.
- `src/main/services/aiService/aiProviderClient.ts`: uji vision terdahulu
  menggunakan gambar 2×2 piksel yang berpotensi ditolak batas ukuran provider.
  Gambar uji menjadi PNG 96×96. Request Qwen di Groq memakai parameter
  `max_completion_tokens` dan mode instruct. HTTP 400 sekarang meneruskan pesan
  spesifik provider secara ringkas dengan pola API key umum disamarkan; ID
  permintaan tetap disertakan.
- `src/shared/ipc.ts`: tipe hasil konfigurasi mencakup pemberitahuan model
  pengganti. `scripts/test-ai-validation-fixes.cjs` menguji 404 model lama,
  fallback yang valid, payload Groq, ukuran PNG, dan diagnosis 400. Test
  tersebut dijalankan bersama rangkaian `npm test`.
- `package.json`, `package-lock.json`, `README.md`: versi dan instruksi diperbarui.

Tidak ada file aplikasi yang dihapus. Folder `node_modules` dan output test
tidak dimasukkan ke ZIP; output `dist/` saat pengujian ikut sebagai referensi.
Jalankan `npm ci` pada Windows sebelum build; `npm run dist` membangun ulang.

## Verifikasi

`npm run build` dan `npm test` lulus pada Linux, termasuk render FFmpeg,
playlist, monitor, dan regresi AI. API key asli tidak disertakan, sehingga
tes langsung Gemini/Groq pada project pengguna dan installer Windows perlu
dijalankan di perangkat pembuat: `npm ci`, `npm test`, `npm run dist`, lalu
Settings → AI Configuration → Simpan & Validasi.

HTTP 400 masih dapat terjadi jika akses model, batas account, atau kebijakan
provider menolak request. Pesan provider yang kini tampil akan menyebut
penyebab yang diperlukan untuk koreksi lanjutan.
