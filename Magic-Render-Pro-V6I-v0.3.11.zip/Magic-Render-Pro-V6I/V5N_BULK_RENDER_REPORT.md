# Magic Render Pro V5N — lima revisi

Basis: ZIP V5M terakhir. Arsip V5N berisi source, build `dist`, konfigurasi, skrip uji, dan laporan ini. Jalankan `npm ci` lalu `npm run dev` untuk pengembangan atau `npm run build` dan `npm start` untuk build lokal. `node_modules` tidak disertakan.

## Hasil

1. **Canvas preview.** Ukuran panggung kini dibatasi oleh lebar dan tinggi viewport, dengan ruang untuk border/scrollbar agar zoom 100% tidak berulang mengubah ukurannya. Ikon reset di kanan Play/Pause menghentikan pemutaran dan mengembalikan waktu ke 00:00. Pemutar MP3 playlist terpisah ditambahkan; video utama dibisukan hanya bila playlist aktif atau opsi auto mute memang dipilih. Volume dan seek menyinkronkan video dengan urutan MP3. Preview intro ikut dalam timeline final dan audio playlist mulai setelah intro.
2. **Sticker subscribe.** Sticker baru memakai jadwal sepanjang durasi dan opacity 100% sehingga langsung terlihat pada render. Sticker lama tetap mengikuti jadwal dan opacity tersimpan. Preview saat Play/seek memakai jadwal final termasuk intro; mode edit yang menampilkan sticker di luar jadwal diberi keterangan. FFmpeg sekarang menempatkan media sticker di tengah bingkai 220×124 seperti `object-fit: contain` pada preview sebelum rotasi, keying, dan komposisi. Opacity tetap diterapkan satu kali. Angka opacity ditampilkan di panel. Uji render memeriksa pixel sticker pada MP4.
3. **Tracklist Manager.** Asset Library kini menyimpan daftar folder MP3, dapat menambah, melihat isi, dan menghapus entri folder. Pemindaian membaca folder serta subfolder hingga dua tingkat dan menyegarkan isi saat menu dibuka. File MP3 sumber tetap berada di lokasi asal; folder yang dipindah/hilang akan tampil kosong sampai ditambahkan ulang.
4. **Text Overlay System.** Setiap teks mempunyai ikon mata untuk preview, gembok posisi, hapus, dan collapse/expand. Status mata/kunci tersimpan di proyek. Ikon mata memengaruhi canvas preview, sama seperti overlay dan sticker, sementara hasil render tetap menyertakan layer tersebut.
5. **Bulk Render.** Tab header baru menerima banyak gambar **atau** banyak video, tidak menerima campuran; grid memperlihatkan thumbnail, ID media, dan tombol ×. Pilih folder tracklist dan jumlah MP3. Pemilihan acak menjamin lagu yang sama muncul paling banyak dua kali **per video**. Opsi acak overlay, intro, sticker, fade in awal, dan fade out akhir tersedia. Satu media ber-ID menghasilkan satu output dengan nama unik, dirender berurutan dengan progress per item, pembatalan antrean, dan tombol buka video hasil. Resolusi, FPS, CPU, preset, bitrate, CBR/VBR, serta folder ekspor diambil dari Settings saat persiapan. Fade out diterapkan setelah seluruh layer visual/sticker agar akhir video benar-benar memudar.

Jika asset acak yang diaktifkan belum tersedia, folder MP3 kosong, media campur, atau jumlah MP3 melebihi dua kali jumlah lagu di folder, persiapan menolak antrean dengan pesan yang jelas. Satu item gagal tidak menghentikan item berikutnya. Antrean dapat ditinggal ke menu lain selama jendela aplikasi tetap terbuka; progres tersimpan dalam state aplikasi selama sesi berjalan.

## Akar masalah dan file

| Masalah | Penyebab | File terkait |
| --- | --- | --- |
| Canvas bergetar dan tanpa suara | ResizeObserver memakai lebar yang ikut berubah saat scrollbar muncul; preview belum memutar MP3 playlist | `src/renderer/components/CanvasPreview.tsx`, `src/renderer/styles/index.css` |
| Sticker berbeda/kurang tampak | Default sticker mulai pada 00:30 tetapi mode edit menampilkannya terus; FFmpeg menempelkan hasil `scale` ke pojok bingkai tanpa padding di tengah | `src/main/services/stickerService.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/renderer/components/{CanvasPreview,StickerPanel}.tsx` |
| Tracklist folder dan bulk belum ada | Belum ada model, penyimpanan, IPC, panel, dan perencana antrean | `src/main/services/bulk/{tracklistStore,bulkPlanner}.ts`, `src/main/ipc/bulkHandlers.ts`, `src/renderer/components/{TracklistManager,BulkRenderPage}.tsx`, `src/shared/domain/bulkTypes.ts` |
| Text eye/lock belum ada | Status dan kontrol belum dimodelkan pada text overlay | `src/shared/domain/{textOverlayTypes,previewTypes}.ts`, `src/main/services/ffmpegEngine/textOverlayService.ts`, `src/renderer/App.tsx` |

File penghubung lain yang diubah: `src/shared/{ipc.ts,domain/projectTypes.ts,domain/introTypes.ts}`, `src/preload/index.ts`, `src/main/ipc/registerIpc.ts`, `src/main/services/project/projectValidator.ts`, `src/main/services/render/renderCommandBuilder.ts`, `src/renderer/components/MainNav.tsx`, `src/renderer/App.tsx`, `package.json`. Skrip uji baru: `scripts/test-v5n-bulk.cjs`. Tidak ada file yang dihapus.

## Verifikasi

- `npm run typecheck` dan `npm run build`: lulus.
- `npm run test:v5n-bulk`: lulus. Menguji batas dua salinan MP3, penolakan gambar/video campur, dua render gambar dengan intro+overlay+sticker+audio, satu render video dengan CBR+audio, file output berbeda, FPS, dan pixel sticker hasil ekspor.
- `npm run test:v5m-revisions`, `npm run test:phase22`, `npm run test:render-engine`, dan `npm run test:output-encoding`: lulus.

Pengujian interaksi GUI Electron di Windows belum dapat dijalankan di lingkungan Linux ini. Uji zoom, perangkat suara, folder MP3 asli, dan beberapa file media nyata pada Windows sebelum menjalankan antrean besar.
