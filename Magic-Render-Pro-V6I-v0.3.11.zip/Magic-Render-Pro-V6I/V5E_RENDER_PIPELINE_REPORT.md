# Perbaikan Render v5e

## Akar masalah

- `src/main/services/render/renderOrchestrator.ts` menormalisasi media utama, membuat visual, menggabungkan intro, dan mengode output secara berurutan. Video utama dikode beberapa kali dan progress yang ditampilkan dibagi rata berdasarkan jumlah tahap, sehingga monitor sulit mencerminkan pekerjaan yang sedang berjalan.
- `src/main/ipc/renderHandlers.ts` menjalankan diagnostik FFmpeg lengkap sebelum memulai job; selama itu proses belum terdaftar dan Pause/Cancel tidak dapat dikendalikan.
- `src/main/services/ffmpegEngine/stickerFilterBuilder.ts` memasukkan ekspresi waktu ke `colorchannelmixer=aa`, padahal opsi itu menerima konstanta. Render dengan sticker berjadwal gagal sebelum progres video berjalan.
- Warna stroke pada `src/renderer/App.tsx` dipatok ke `#05050d` ketika edit diterapkan.

## Perbaikan

1. Playlist MP3 digabung lebih dulu; durasi gabungan menjadi durasi konten. Media utama di-loop sampai durasi ini. Overlay, teks, sticker berjadwal, dan intro disusun dalam satu filtergraph, lalu video H.264 dikode sekali. Audio AAC dari playlist dimux tanpa encoding ulang.
2. Output mengikuti resolusi, FPS (24/25/30/50/60), dan batas bitrate pada Settings. CRF dengan `-maxrate` serta `-bufsize` menjaga detail sekaligus menahan ukuran pada adegan sederhana. Intro menambah durasi output; playlist bergeser sesudah intro.
3. Monitor mengambil `-progress` FFmpeg, menghitung 8% untuk persiapan audio dan 92% untuk pengodean video, serta ETA berdasarkan durasi video tersisa dan speed nyata. Waktu berhenti saat jeda dan batal. Pause/Cancel tersedia saat job aktif, termasuk persiapan media.
4. Sticker schedule menggunakan `overlay enable` atau `blend enable`; opacity tetap numerik dan fade diterapkan per window. Pemilih warna stroke tersedia dan mengikuti preview serta render.
5. Mode timestamp menghasilkan `youtubetimestamp.txt`. Mode Timestamp + SEO menghasilkan `youtubetimestamp.txt` dan `youtubeseo.txt` setelah layanan AI selesai; API key tetap diperlukan. Offset timestamp intro gambar disamakan dengan durasi intro render.

## File yang diubah

- Engine: `src/main/services/render/renderOrchestrator.ts`, `renderCommandBuilder.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/main/ipc/renderHandlers.ts`.
- Settings dan project: `src/shared/domain/settingsTypes.ts`, `projectTypes.ts`, `src/main/services/settingsService.ts`, `src/main/ipc/settingsHandlers.ts`, `src/main/domain/project/projectFactory.ts`, `src/main/services/project/projectService.ts`.
- UI: `src/renderer/App.tsx`, `src/renderer/components/SettingsPanel.tsx`.
- SEO: `src/main/services/aiService/youtubeSeoService.ts`, `seoFileWriter.ts`.
- Dokumentasi/pengujian: `README.md`, `scripts/test-render-orchestrator.cjs`, `test-monitor-pause-cache.cjs`, `test-output-encoding.cjs`, `test-ai-files.cjs`, `test-phase22-integration.cjs`, `verify-phase12.mjs`, `verify-phase20.mjs`.
- Tidak ada file yang dihapus.

## Verifikasi

- `npm run build`: lulus.
- Render FFmpeg nyata: dua MP3 + loop media + overlay + dua sticker (jadwal, fade, blend) + teks stroke + intro, output 2 detik pada 25 FPS dengan audio: lulus.
- Media utama gambar mengikuti playlist 1,5 detik: lulus.
- `scripts/test-monitor-pause-cache.cjs` dan `scripts/test-v5d-regressions.cjs`: lulus.
- `test:output-encoding`, `test:ai-files`, `test:render-engine`: lulus.
- Suite `npm test` berhenti pada `verify:phase10` karena pemeriksaan statis lama mengharapkan class `aspect-video` di Canvas Preview baseline. Pemeriksaan itu tidak menguji alur render ini.

Untuk packaging Windows, sediakan `ffmpeg.exe` dan `ffprobe.exe` di `resources/ffmpeg/` atau atur path executable melalui Settings. ZIP ini berisi source dan build aplikasi, bukan installer Windows.
