# npm install + Native Windows Window/Menu Fix — 2026-09-09

## npm ERESOLVE root cause

The root project declared `react` and `react-dom` with the same lower bound (`^19.1.1`) but npm was allowed to resolve different minor/patch releases. The user's install resolved React `19.2.8` while React DOM resolved to `19.3.0`, whose peer dependency requires React `^19.3.0`.

## Fix

Both dependencies are now pinned to the same installed-compatible version:

- `react`: `19.2.8`
- `react-dom`: `19.2.8`

This avoids the peer dependency mismatch without using `--force` or `--legacy-peer-deps`.

## Native Windows frame/menu requirement

The BrowserWindow now explicitly uses:

- `frame: true`
- `autoHideMenuBar: false`

No custom Minimize / Maximize / Close controls are rendered by React. Windows therefore owns those title-bar buttons.

`src/main/applicationMenu.ts` continues to create Electron's native application menu with `File` and `Help`.

## Validation

- `node scripts/test-native-window-and-deps.cjs` — PASS
- `node scripts/test-user-14-fixes.cjs` — PASS
- FFmpeg multi-sticker/filtergraph smoke — PASS
- Full TypeScript build could not be executed in this Linux environment because project dependencies are intentionally not installed; `npm install` must be run on the Windows machine after this dependency correction.
