# Magic Render Pro — User 14 Fixes Changelog

This document records the implementation delta requested for the latest project snapshot.

## Changed

- **Home/Header:** branded `Magic Render Pro` header with `CREATE • RENDER • INSPIRE`; native Electron/Windows frame remains enabled, so Windows minimize/maximize/close controls remain native. `New`, `Open`, and `Save` are now shown only in **Beranda**.
- **Navigation:** removed numeric menu codes; the bottom-left footer now shows `© 2026 Radist Ginola. All rights reserved.` instead of Ready.
- **Render Queue:** moved into Render Monitor directly under render controls and added icon-only collapse/expand control.
- **CPU Load:** removed from Beranda; it remains in Settings only.
- **Notifications/logging:** all IPC handlers now pass through a logging wrapper; renderer `console.log/info/warn/error`, `window.onerror`, and unhandled promise rejections are forwarded to the Main logger. Global notifications are top-right, closable with `X`, and auto-hide after 5 seconds.
- **Canvas preview:** local `file:` media support was enabled in CSP; image and video main media are rendered with the correct element; Play/Pause/Stop/seek/volume work for video. Technical fallback text and project-name header were removed.
- **Overlay editing:** overlay changes are staged and require **Terapkan** to update the Canvas Preview. Existing opacity, position, resize, rotation, speed, blend, chroma/color key controls remain available.
- **Sticker Subscribe:** upgraded from one sticker to a backward-compatible multi-sticker representation (`stickerSubscribes`). Added Apply workflow, library loading, mute/unmute, opacity, blend, speed, scale, position, rotation, fade in/out, display duration, repeat count/timestamps/full-duration scheduling, and black/green background removal controls.
- **Playlist:** Shuffle is now a button that explicitly randomizes playback order and the displayed playlist summary follows the shuffled order.
- **YouTube SEO:** panel now exposes only Main Keyword plus AI status. Provider/model/API key remain in Settings; SEO generation uses the global Settings provider/model.
- **Intro:** added media upload/import flow. Enable is disabled until an intro asset exists, preventing the previous `Intro harus memiliki aset...` handler error.
- **Main media controls:** IPC validation now accepts the actual flat `{ autoMute, fadeInSec, fadeOutSec, ... }` payload sent by the renderer, fixing `Invalid fade controls.`
- **FilterGraph:** removed no-op `null` filters from overlay composition and rebuilt sticker scheduling around FFmpeg `fade` + `overlay`/`blend`, including multiple stickers/windows. Lanczos scaling is used wherever the render pipeline scales media.
- **Render robustness:** fixed nullable audio artifact handling in the orchestrator.
- **Settings executable paths:** relative executable names such as `ffmpeg` are no longer accidentally converted into an absolute project path.

## Added

- `src/main/ipc/loggedHandler.ts` — centralized IPC activity/error logging wrapper.
- `scripts/test-user-14-fixes.cjs` — focused validation for the requested 14 fixes plus an actual FFmpeg multi-sticker/filtergraph smoke test.
- `docs/USER_14_FIXES_CHANGELOG.md` — this change inventory.
- `docs/USER_14_FIXES_TEST_REPORT.md` — validation report and environment limitations.
- `stickerSubscribes?: ProjectStickerReference[]` in project data for backward-compatible multi-sticker storage.
- `INTRO_IMPORT` and `APP_LOG` typed IPC channels.

## Removed / intentionally no longer visible

- Numeric navigation codes under the left menu.
- `Ready` footer text.
- Technical `css+pipe:1 fallback` / project-name text above the canvas.
- Global New/Open/Save toolbar outside Beranda.
- CPU Load control outside Settings.
- Provider/model/API-key controls from the YouTube SEO panel.
- Sticker Subscribe single-sticker-only behavior.
- The old overlay filtergraph no-op `null` chain that produced graphs such as `[1:v]null...`.

No original project source file was deleted as part of this fix set.
