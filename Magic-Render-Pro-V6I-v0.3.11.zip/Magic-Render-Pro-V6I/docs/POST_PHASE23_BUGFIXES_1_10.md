# Post-Phase 23 Bugfixes #1–#10

Tanggal: 2026-09-06

## Perubahan

1. Fixed relative imports in `projectRepository.ts` and `stickerScheduler.ts` from `../../../shared/domain/*` to `../../shared/domain/*`.
2. Downgraded `electron-store` to CJS-compatible `^8.2.0`; added `@ffmpeg/ffmpeg` dependency for the existing best-effort WASM path.
3. Centralized Electron open-dialog invocation in `src/main/ipc/dialogHelper.ts`, preventing `BrowserWindow | undefined` from reaching the window-bound overload.
4. Added strict guards to sticker timestamp parsing and explicit numeric callback typing for `noUncheckedIndexedAccess`.
5. Changed `npm test` to begin with the real `npm run build` and explicitly execute Phase 22/23 verification plus auxiliary suites.
6. Removed hardcoded `/opt/nvm/versions/node/.../typescript` references from test scripts; they now use local `require('typescript')`.
7. Registered the previously orphaned tests in `package.json`.
8. Explicitly wired `verify:phase22` and `verify:phase23` into `npm test`.
9. Added `@ffmpeg/ffmpeg` as a real runtime dependency for the renderer WASM path.
10. README now documents both required native binaries: `ffmpeg.exe` and `ffprobe.exe`.

## Verification

- Import/export runtime smoke: TEST PASSED
- Remaining-fixes runtime: TEST PASSED
- FFmpeg graceful-stop/environment runtime: TEST PASSED
- Phase 22 static verification: TEST PASSED
- Phase 23 final-audit verification: TEST PASSED
- Package QA registration/path portability: TEST PASSED
- Hardcoded developer TypeScript path scan: TEST PASSED (0 matches)
- `npm run build:main`: BLOCKED by missing installed `node_modules/@types/node`
- Full `npm test`: NOT RUN TO COMPLETION until dependencies are installed; the script now contains a real build gate.

## Packaging note

This patch does not manufacture native Windows binaries. A real Windows package still requires installed project dependencies and the native `resources/ffmpeg/ffmpeg.exe` plus `resources/ffmpeg/ffprobe.exe` assets.
