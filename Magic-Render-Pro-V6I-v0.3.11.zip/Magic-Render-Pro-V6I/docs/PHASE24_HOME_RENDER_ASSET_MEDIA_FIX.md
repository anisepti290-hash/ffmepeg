# Phase 24 — Home / Render / Asset / Setting / Help + Media Preview Fix

## Scope
- Separate Home page from Render workspace.
- Top-level navigation is exactly Home, Render, Asset, Setting, Help.
- Remove File from the visible application UI.
- Keep Minimize / Maximize / Close as React custom title-bar controls backed by Electron IPC.
- Home page contains branding, slogan, Start New Project, and four superpower cards.
- Render page contains Media, Intro, Overlay, Playlist, Sticker Subscribe, Youtube SEO, Canvas Preview, Render Monitor, Render Queue, and Console Log.
- Asset page provides three global locked-asset grids: Intro, Overlay, Sticker Subscribe.
- Settings page provides FFmpeg/FFprobe paths, default upload folder, output defaults, CPU load, and AI configuration.
- Fix local image/video preview source failures and video playback.
- Make application logging observable in realtime and replay recent entries when the renderer connects.

## Important runtime fix
Electron's renderer is loaded from HTTP during development and from a local file during production. Direct `file://` media URLs were blocked by the renderer CSP/origin rules in the affected workflow. The app now exposes a controlled `mrp-media://` protocol in the Main Process and explicitly allows it in CSP.

## Validation
- TypeScript/TSX syntax transpile check: PASS.
- Phase 24 static UI validation: PASS.
- Custom window chrome validation: PASS.
- Foundation + Phase 2–23 static verification: PASS.
- User-14 regression + FFmpeg multi-sticker smoke: PASS.
- Render engine / orchestrator / Phase 22 runtime tests: PASS.
- Full npm install/build was not executed in this environment because the registry was not reachable and the environment had no cached dependency tree. Run `npm install` then `npm run build` on Windows before distribution.
