# Phase 24 Change Log

## Changed
- Reworked `App.tsx` into top-level Home / Render / Asset / Setting / Help routing.
- Reworked `MainNav.tsx` to five requested pages.
- Reworked `WindowChrome.tsx` into a minimal React custom title bar with Electron-backed window controls.
- Added Home hero/superpower presentation matching the supplied reference direction.
- Added Asset Library page with three lock/unlock grids.
- Added default upload-folder setting and Settings IPC.
- Added `mrp-media://` protocol and CSP support for local image/video playback.
- Added video load/playback error reporting to the Console Log.
- Added recent-log replay plus realtime IPC logging wrapper coverage.
- Added collapse/expand icon behavior to Render Queue.
- Updated legacy verification scripts so they test the current architecture instead of obsolete native-menu assumptions.

## Preserved
- Existing source files and legacy components remain in the archive.
- No original ZIP entry was intentionally deleted.
- Existing project-level and persistent asset models remain backward compatible.
