# Magic Render Pro — PHASE 22 Testing & Quality Assurance Strategy

## 1. Tujuan

Phase 22 memvalidasi fitur yang telah dibangun pada Phase 1–21 tanpa menyamakan static verification dengan runtime verification. Setiap hasil wajib menggunakan salah satu klasifikasi:

- **TEST PASSED** — test benar-benar dijalankan dan assertion lulus.
- **NOT RUN** — test belum dijalankan karena sengaja ditunda atau membutuhkan kondisi yang tidak tersedia namun bukan kegagalan implementasi yang dapat disimpulkan dari environment.
- **BLOCKED** — test tidak dapat dijalankan karena dependency/runtime/environment yang diperlukan tidak tersedia.
- **MANUAL VERIFICATION REQUIRED** — test membutuhkan interaksi GUI/Windows/device/user credential yang tidak dapat disimulasikan secara aman oleh automation saat ini.

## 2. Unit Tests

| ID | Area | Positive cases | Error / edge cases | Automation |
|---|---|---|---|---|
| U-001 | Utility | numeric/path helpers return normalized values | NaN, Infinity, empty path, invalid input | automated |
| U-002 | Duration calculation | exact duration, trim, loop, loop+trim | zero, negative, empty playlist, invalid track duration | automated |
| U-003 | CPU calculation | 1/25/50/75/100% mapping, core clamp | <1%, >100%, NaN, zero cores | automated |
| U-004 | Filter builders | normal/multiply/screen/overlay, chroma/color key | invalid blend, invalid color, negative position | automated |
| U-005 | Scheduling | full-duration, iterative, timestamp | malformed timestamp, >100 timestamps, timestamps beyond duration | automated |
| U-006 | Timestamp generation | intro offset, ordered playlist, repeated segments | empty plan, final-duration boundary, duplicate starts | automated |
| U-007 | Error translator | known error rules and fallback | unknown errors, contextual stage/exit code | automated |
| U-008 | Encoding/output helpers | H.264/AAC/CBR args, resolution/output naming | invalid bitrate, wrong extension, collision | automated |

## 3. Integration Tests

| ID | Area | Coverage | Status expectation |
|---|---|---|---|
| I-001 | IPC | shared channel contracts, preload exposure, handler registration | static automated; runtime Electron verification manual/blockable |
| I-002 | FFmpeg spawn | real ffmpeg process, pipe/exit handling | automated when ffmpeg executable exists |
| I-003 | Progress parsing | FFmpeg progress line parsing from representative output | automated |
| I-004 | Render lifecycle | orchestrator stage sequence and final output | automated smoke; full GUI lifecycle still manual |
| I-005 | Cleanup | cache job creation, artifact deletion, source/output protection | automated |

## 4. End-to-End Tests

### E2E-001 — Core render path

Create project → import media → add overlay → add playlist → render → verify MP4 output → verify timestamp file.

### E2E-002 — SEO completion path

Core render path → valid AI provider/model/API key → keyframe extraction → AI response validation → `youtubeSEO.txt` + `youtubetimestamp.txt`.

### E2E-003 — Windows GUI path

Launch packaged Electron app → create project → interact with every navigation tab → render control → inspect output folder.

E2E-002 requires a real API key. E2E-003 requires a Windows Electron runtime/package, so these are not falsely marked passed when those prerequisites are absent.

## 5. Error / Edge Case Matrix

1. Missing source media / malformed media.
2. Empty playlist or playlist tracks with invalid duration.
3. Output directory missing or non-writable.
4. Insufficient storage.
5. Existing output file and overwrite disabled.
6. Invalid resolution, bitrate, CPU percentage, or AI provider/model.
7. FFmpeg non-zero exit / unknown error.
8. Render cancellation and cleanup after failure.
9. Pause/resume at safe stage boundary.
10. API key absent/invalid and AI response schema invalid.
11. Timestamp equal to or beyond final video duration.
12. Path containing spaces and Windows-style separators.

## 6. Environment Classification

Current execution environment is Linux with FFmpeg/ffprobe available, but project dependencies are not installed (`node_modules` absent). Therefore:

- pure Node/static tests can be executed;
- real FFmpeg CLI smoke tests can be executed;
- TypeScript project typecheck is blocked until `@types/node` and project dependencies are installed;
- Electron GUI/runtime and Windows-only packaging checks require manual Windows verification;
- live multimodal SEO generation requires a user-provided API key.

## 7. Exit Criteria

Phase 22 does not claim the entire product is verified merely because the test harness exists. The final RTM records each test/result category separately and preserves the exact blocker or manual prerequisite for every unverified area.
