# Verification — Runtime Repair Baseline

- Baseline: `magic-render-pro-settings-renderer-typefix(2).zip`.
- `window.prompt(` occurrences in `src/`: 0.
- `APP_LOG`, FFmpeg picker, and FFprobe picker IPC channels are present.
- Global Settings contains persistent `ffmpegPath` and `ffprobePath`.
- Windows defaults point to `C:\\ffmpeg\\bin\\ffmpeg.exe` and `C:\\ffmpeg\\bin\\ffprobe.exe` when available.
- `resources/app-icon.ico` exists and is a valid Windows ICO containing 256x256 RGBA artwork.
- `electron-builder` Windows icon: `resources/app-icon.ico`.
- `BrowserWindow` uses AppUserModelId `com.magicrenderpro.app` and an ICO candidate chain.
- Tailwind config converted from ESM TypeScript to CommonJS `tailwind.config.cjs`.
- Windows runtime build/dist verification must still be executed on the target machine.
