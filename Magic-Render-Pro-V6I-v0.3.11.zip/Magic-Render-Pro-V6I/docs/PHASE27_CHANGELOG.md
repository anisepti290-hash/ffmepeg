# Phase 27 — UI/UX + Render Workflow Fixes

## Base
This release is built directly from `Magic Render Pro FIXED v4 — Home / Render / Asset / Media Fix`.
No source file from the base archive was intentionally removed.

## Implemented
- Main navigation Home / Render / Asset / Setting / Help is horizontal.
- File is removed from main navigation.
- Render first view shows recent projects with media thumbnail, name, project path, open and remove-from-list actions.
- Canvas overlay/text/sticker layers support direct drag, corner resize and rotation handle.
- Global dark select styling: black background, white text.
- Overlay and sticker chroma/color key controls use sliders.
- Overlay FilterGraph no longer emits redundant disabled keying `format=rgba` identity chains.
- IPC transport tracing is removed from user Console Log.
- Text Overlay has a direct Apply-to-Canvas action.
- Overlay Modular FilterGraph button is removed from UI.
- Playlist Shuffle updates the visible playback order.
- Sticker duration is probed automatically for video/GIF; UI no longer exposes manual duration editing.
- Sticker timestamp schedule has minute/second sliders.
- Fade-in/fade-out controls are sliders with seconds shown.
- YouTube SEO supports Timestamp-only and Timestamp+SEO modes.
- Timestamp-only render does not require AI configuration.
- Timestamp+SEO render is blocked until AI configuration validates successfully.
- Asset Library displays media previews and a persistent lock indicator.
- Settings uses three horizontal columns: paths/export, render controls, AI configuration.
- FFmpeg render presets: Fast, Standard, Slow.
- AI providers expanded to OpenAI, Gemini, OpenRouter, Groq and Mistral (OpenAI-compatible multimodal providers use chat completions).
- FFmpeg errors sent to the Console Log are translated to actionable Indonesian messages.

## Validation
- `scripts/verify-phase27.cjs`: 19/19 PASS.
- TypeScript/TSX transpile syntax scan: 120 source files PASS (declaration files excluded from transpile scan).
- Full `npm run build` could not be executed in the build environment because dependencies are intentionally not installed and registry installation timed out. Run `npm install`, `npm run typecheck`, and `npm run build` on Windows before distribution.
