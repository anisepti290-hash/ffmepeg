# Blank Screen Runtime Diagnostics Fix

## Scope
Hardening renderer startup so a runtime JavaScript/module/React failure is never represented only by a blank Electron window.

## Changes
- Renderer bootstrap now installs `error` and `unhandledrejection` listeners before loading `App`.
- `App` is loaded through a guarded dynamic import.
- React tree is wrapped in an error boundary.
- Module-load errors and React render errors display a readable fatal screen with the error message and stack trace.
- Existing Main Process renderer diagnostics remain enabled (`did-fail-load`, `render-process-gone`, console errors).

## Verification
- `verify-blank-screen-fix.mjs`: PASSED (7 checks).
- Runtime packaged EXE verification is still required on Windows with the rebuilt installer.

## Important
This patch makes the failure diagnosable and prevents a silent blank screen. The exact renderer runtime exception still requires observation on the affected installed build if the error persists.
