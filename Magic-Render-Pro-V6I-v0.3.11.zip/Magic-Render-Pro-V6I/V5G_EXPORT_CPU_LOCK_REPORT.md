# Magic Render Pro — pembaruan v5g

## Perbaikan

1. Export 720p (1280×720) tersedia pada Output dan Settings. Validasi project, IPC, dan resolusi engine FFmpeg telah diselaraskan. Overlay dan sticker menggunakan ukuran canvas dari peta resolusi yang sama.
2. Preset H.264 kini konsisten pada seluruh pembangun perintah: Cepat = `veryfast`/CRF 21, Standar = `medium`/CRF 20, Pelan = `slow`/CRF 19. Bitrate yang dipilih tetap menjadi batas puncak output. Preset `ultrafast` sebelumnya membuat kompresi boros dan ukuran berkas dapat membesar.
3. CPU Load Control sebelumnya menyisipkan `-threads` sebelum input, sehingga hanya mempengaruhi decoder awal. Sekarang filter dan encoder dibatasi serta proses FFmpeg diberi affinity ke sebagian inti logis (Windows melalui PowerShell bawaan sistem; Linux melalui taskset). Jumlah inti dibulatkan ke bawah agar target 60% pada delapan inti menghasilkan empat inti. Pengaturan CPU dan preset yang tersimpan di Settings berlaku pada render meskipun project lama mempunyai snapshot sebelumnya.
4. Ikon kunci tersedia di sebelah mata pada setiap Overlay dan Sticker Subscribe. Status kunci disimpan dalam project; layer terkunci tetap bisa dipilih tetapi tidak bisa digeser, diubah ukurannya, atau diputar lewat Canvas Preview. Layer lain tetap bisa disunting. Kunci ini tidak membatasi pengubahan parameter melalui panel setelah memilih Terapkan.

## Berkas terkait yang diperbaiki

- Resolusi dan validasi: `src/shared/domain/projectTypes.ts`, `src/main/services/ffmpegEngine/resolutionMap.ts`, `src/main/ipc/{outputHandlers,projectHandlers,settingsHandlers}.ts`, `src/main/services/{settingsService,project/projectValidator,overlay/overlayService,stickerService}.ts`, `src/renderer/{App.tsx,components/SettingsPanel.tsx}`.
- Preset dan CPU: `src/main/services/{render/encodingBuilder,render/renderCommandBuilder,cpuController,ffmpegEngine/ffmpegRunner,render/renderOrchestrator}.ts`, `src/main/ipc/renderHandlers.ts`.
- Kunci: `src/shared/domain/{overlayTypes,stickerTypes,previewTypes}.ts`, `src/main/services/{overlay/overlayValidator,stickerValidator}.ts`, `src/renderer/{App.tsx,components/StickerPanel.tsx,components/CanvasPreview.tsx,components/PreviewLockIcon.tsx,styles/index.css}`.
- Pengujian: `scripts/test-v5g-export-cpu-lock.cjs` (baru), `scripts/test-phase22-unit.cjs` (ekspektasi posisi negatif lama diperbaiki), `scripts/test-live-monitor.cjs` (Settings aktif mengalahkan snapshot project).

Tidak ada berkas yang dihapus.

## Verifikasi

Build TypeScript/Renderer, render FFmpeg 720p, progres, pemetaan thread dan affinity di Linux, penguncian perubahan visual, test unit, render intro/overlay, render persiapan, reset, dan monitor IPC lulus. Affinity pada Windows harus diperiksa pada komputer Windows pengguna; pemakaian CPU total komputer dapat melampaui target FFmpeg apabila aplikasi lain turut memakai CPU atau affinity ditolak sistem. Bila gagal menerapkan affinity, Console Log menampilkan pesan dan pembatasan thread tetap dipakai.

ZIP ini berisi source dan hasil build Electron, bukan installer Windows. Untuk membuat installer Windows, siapkan `ffmpeg.exe` dan `ffprobe.exe` di `resources/ffmpeg`, lalu jalankan `npm install` dan `npm run dist` pada Windows.
