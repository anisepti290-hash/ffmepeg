# Magic Render Pro v0.3.0 — sembilan pembaruan

Baseline: v0.2.9, paket V5W dengan perbaikan validasi Gemini/Groq.

## Perbaikan

1. Asset Library sekarang mempunyai editor preset overlay/sticker pada canvas
   contoh media utama yang sedang dipakai. Lebar/tinggi/zoom, posisi, rotasi,
   blend, keying, level, blend key, speed, dan opacity dapat disimpan. Impor
   berikutnya pada menu Overlay, Sticker, atau Bulk memakai preset itu. Jadwal
   sticker tetap milik video/proyek dan tidak ikut ke preset library.
2. Tombol tambah dan dialog pemilihan asset mengikuti jenis Intro/Overlay/Sticker.
3. Gembok asset kini toggling status; hapus memakai tombol × tersendiri.
4. Daftar asset Overlay mempunyai tombol Refresh.
5. Kontainer Asset dan Setting melebar sampai sisi kanan viewport; Render tetap
   fleksibel pada ukuran jendela yang berbeda.
6. Empat efek media, lima efek partikel, dan enam visualizer audio ditambahkan.
   Visualizer hasil render bersumber dari playlist gabungan yang sama dengan
   audio MP4; preview membaca audio playlist yang sedang diputar.
7. Pembatalan dialog pemilihan asset mengembalikan `null`, tidak melempar error
   `Asset selection cancelled` dari handler IPC.
8. Ikon reset pada kontrol yang diminta hanya muncul bila pengaturannya berubah.
9. Bulk Render mempunyai opsi jadwal sticker berulang/berdasarkan beberapa waktu,
   tombol tutup pada hasil selesai, dan nama timestamp yang unik per MP4.

## Script terkait

- Penyimpanan asset dan IPC: `src/main/services/persistentStore/lockedAssetStore.ts`,
  `src/main/ipc/lockedAssetHandlers.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`,
  `src/shared/domain/assetPreset.ts`.
- UI dan pratinjau: `src/renderer/App.tsx`, `src/renderer/components/AssetVisualEditor.tsx`,
  `VisualizerPreview.tsx`, `CanvasPreview.tsx`, `EffectsPanels.tsx`,
  `StickerPanel.tsx`, `BulkRenderPage.tsx`, dan `src/renderer/styles/index.css`.
- Render: `src/main/services/render/renderCommandBuilder.ts`,
  `src/main/services/effects/visualizerBuilder.ts`, `effectFilterBuilder.ts`,
  `src/main/services/bulk/bulkPlanner.ts`,
  `src/main/services/aiService/timestampGenerator.ts`,
  `src/main/ipc/renderHandlers.ts` dan validasi domain terkait.

Tidak ada file sumber yang dihapus. Folder `dist/` dibuat ulang oleh build.

## Pemeriksaan

- `npm run typecheck`: lulus.
- `npm test`: lulus, termasuk build, regresi render/IPC, Bulk FFmpeg, enam
  filter visualizer, efek baru, satu MP4 dengan visualizer dan audio, serta
  lima file timestamp yang berbeda.
- Installer Windows tidak dibuat di lingkungan Linux ini. `npm run dist`
  memerlukan Windows x64 dan akan memeriksa FFmpeg/FFprobe Windows serta
  encoder/filter yang dibutuhkan sebelum packaging.
