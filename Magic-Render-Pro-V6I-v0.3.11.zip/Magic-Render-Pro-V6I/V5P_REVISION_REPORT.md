# Magic Render Pro 0.2.0 — revisi V5P

## Penyebab dan perubahan

| Area | Penyebab | Perbaikan |
| --- | --- | --- |
| Jadwal Sticker Subscribe | Tampilan menampilkan nilai contoh 00:30 / 1 kali tanpa menyimpannya dalam proyek; preview memakai kalkulasi sendiri. | Nilai awal disimpan saat memilih mode, proyek lama dengan nilai kosong dipulihkan saat validasi, durasi kemunculan bisa diatur, preview dan FFmpeg memakai jendela jadwal bersama. Video stiker pada preview mengikuti seek/play dan restart di awal jendela. |
| Stiker tampak berbeda dan CPU berat | Jalur alfa memakai format otomatis dan menjalankan filter alfa meskipun opacity 100%. | Stiker normal dikomposisi pada YUV420 dengan alfa lurus; filter alfa yang tidak perlu dilewati. Tidak ada tahap encoding visual kedua. |
| Ukuran export | CBR dapat menahan bitrate mendekati target walau adegan sederhana. | Gunakan VBR yang sudah tersedia (default) dengan CRF dan batas bitrate; pilih 720p/preset cepat sesuai kebutuhan. Tidak ada jaminan ukuran lebih kecil sekaligus kesetaraan bit demi bit; sumber kompleks dapat memerlukan bitrate tinggi. Audio playlist disalin dari AAC hasil penggabungan, tanpa encoding ulang saat komposisi. |
| Simpan Settings | Penyimpanan proyek pada langkah berikutnya dapat membuat penyimpanan pengaturan global terlihat gagal; API key kosong kerap disalahartikan. | Keberhasilan settings dan kegagalan simpan proyek dilaporkan terpisah; kolom key kosong tidak menghapus kredensial dan tidak menghalangi simpan settings. |
| Reset dan tampilan kontrol | Beberapa panel tidak mempunyai tombol reset atau belum collapse awal. | Ikon reset untuk kontrol media, efek media, setiap overlay, teks pilihan, semua partikel, dan setiap stiker. Kontrol media, panel teks, Console Log tertutup di awal. |
| Resolusi setelah impor | Pemilihan output tidak langsung tersedia saat media diimpor. | Dialog 720p/1080p sesudah impor, simpan ke proyek dan settings global, skala extent preview sesuai resolusi sementara koordinat desain layer tetap konsisten. |
| Bantuan/versi | Isi bantuan tidak meliputi fitur baru. | Help, README dan versi paket 0.2.0 diperbarui. |

## File/script diubah atau ditambah

- `src/shared/domain/stickerTimeline.ts` **baru**; `src/main/services/stickerScheduler.ts`, `stickerValidator.ts`, `stickerService.ts`, `ffmpegEngine/stickerFilterBuilder.ts`, `src/shared/domain/stickerTypes.ts`.
- `src/renderer/components/StickerPanel.tsx`, `CanvasPreview.tsx`, `KeyedMedia.tsx`, `SettingsPanel.tsx`, `EffectsPanels.tsx`, `ConsoleLogPanel.tsx`, `LayerActionIcons.tsx`, serta `src/renderer/App.tsx`.
- `src/main/ipc/appHandlers.ts`, `README.md`, `package.json`, `package-lock.json`.
- Tes terbarui: `scripts/test-v5i-blend-sticker-timing.cjs` (sampel piksel di tengah stiker, bukan padding transparan) dan `scripts/test-sticker-input.cjs` (mocks komponen/penyimpanan).
- Tidak ada file sumber yang dihapus.

## Verifikasi

- `npm run build` dan `npm run typecheck`: lolos.
- Stiker alpha dan GPU args (`test-v5o-revisions`), jadwal timestamp/berulang/penuh dan blend (`test-v5i-blend-sticker-timing`), input jadwal (`test-sticker-input`), encoding (`test-output-encoding`), rangkaian render (`test-render-orchestrator`), bulk (`test-v5n-bulk`), dan monitor/pause/cancel (`test-monitor-pause-cache`): lolos pada Linux FFmpeg lokal.
- Performa 3 menit dan UI Electron/FFmpeg di Windows pengguna belum diukur pada perangkat tujuan; CPU, kodek sumber, resolusi, FPS, storage, dan pengaturan FFmpeg mempengaruhi waktunya. GIF animasi pada preview browser dapat memiliki frame berbeda setelah seek dibanding decoder FFmpeg.
