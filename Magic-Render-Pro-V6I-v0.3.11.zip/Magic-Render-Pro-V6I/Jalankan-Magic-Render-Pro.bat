@echo off
setlocal EnableExtensions
cd /d "%~dp0" || goto :failed
title Magic Render Pro - Install, Build, Dev

echo [1/6] npm install
call npm install || goto :failed

echo [2/6] npm install-scripts approve --all
call npm install-scripts approve --all || goto :failed

echo [3/6] rmdir /s /q node_modules\electron
if exist "node_modules\electron" rmdir /s /q "node_modules\electron"
if exist "node_modules\electron" goto :failed

echo [4/6] npm install electron@37.10.3 --save-dev
call npm install electron@37.10.3 --save-dev || goto :failed

echo [5/6] npm run build
call npm run build || goto :failed

echo [6/6] npm run dev
call npm run dev || goto :failed

echo.
echo Aplikasi telah ditutup.
pause
exit /b 0

:failed
echo.
echo Langkah gagal. Periksa pesan di atas. Perintah install-scripts memerlukan npm yang mendukung subperintah tersebut.
pause
exit /b 1
