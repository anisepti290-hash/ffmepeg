# Magic Render Pro — pembaruan v5i

## Perubahan dan penyebab

1. **Ringkasan selesai render.** Setelah output berhasil, modal menampilkan durasi video, resolusi, FPS, bitrate maksimum yang dikonfigurasi, lama render, folder dan nama file, jumlah overlay/sticker, serta status intro. Tombol membuka folder atau file MP4 dengan aplikasi pemutar bawaan Windows; ikon tutup dan Escape menutup modal.
2. **Mode screen menjadi ungu.** `blend` sebelumnya diterapkan pada kanal YUV dan kanvas transparan, sehingga chroma netral serta area transparan ikut berubah warna. Screen, multiply, dan overlay kini diproses pada kanal RGB, lalu hasilnya dipasang dengan masker alpha. Opacity diterapkan setelah chroma/color key supaya transparansi tidak ditimpa keyer. Jalur sticker nonnormal memakai masker yang sama.
3. **Text Overlay System.** Ikon panah pada judul membuka/menyembunyikan seluruh form; panah tiap item masih dapat dipakai. Tiga pemilih warna berada pada satu baris; empat pilihan Bold/Italic/Underline/Neon Glow berada pada satu baris.
4. **Katalog model AI.** Settings memuat daftar model langsung dari endpoint provider saat memilih provider yang memiliki key tersimpan, atau dengan tombol Muat Model memakai key yang sedang diketik. OpenAI menampilkan seluruh ID berawalan `gpt-` yang dikembalikan untuk key tersebut; Gemini mengambil seluruh halaman model `generateContent`; provider lain memuat daftar dari endpoint model masing-masing. Input manual tetap tersedia. Model tanpa dukungan gambar akan ditolak saat Simpan & Validasi.
5. **Jadwal sticker.** Setiap window timestamp/berulang memulai aliran sticker dari awal dengan PTS yang cocok. Frame terakhir tidak terus menempel sesudah window berakhir. Sticker digabung setelah intro supaya timestamp, berulang, dan sepanjang durasi memakai timeline video final. Preview tidak lagi memaksa sticker tampil pada detik nol untuk jadwal mendatang; slider mencakup durasi playlist.
6. **Slider overlay.** Speed, X/Y, lebar, tinggi, rotasi, dan zoom kini memakai slider. Nilai nol berarti speed 1×, ukuran awal 320×180, atau rotasi/posisi 0. Nilai negatif memperlambat/mengecilkan/menggeser kiri atau atas; nilai positif kebalikannya.
7. **Estimasi tersisa.** Sampel speed FFmpeg yang berfluktuasi dahulu membuat angka waktu naik. ETA sekarang mulai setelah 2 detik video terproses, menghitung mundur secara monoton dalam satu tahap, berhenti saat Pause, dan direset saat pekerjaan baru. Ini tetap perkiraan, terutama bila laju CPU berubah drastis.

## Berkas yang diperbaiki/ditambah

- UI: `src/renderer/App.tsx`, `src/renderer/components/{SettingsPanel,CanvasPreview}.tsx`, `src/renderer/styles/index.css`, `src/renderer/utils/renderEta.ts` (baru).
- Render: `src/main/services/ffmpegEngine/filterGraphBuilder/{blendFilterBuilder,filterGraphBuilder,overlayFilterBuilder}.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/main/services/render/renderCommandBuilder.ts`.
- Daftar model, buka hasil: `src/main/services/aiService/aiProviderClient.ts`, `src/main/services/settingsService.ts`, `src/main/ipc/{settingsHandlers,outputHandlers}.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`.
- Uji: `scripts/test-v5i-{blend-sticker-timing,ai-models,render-eta}.cjs` (baru), `scripts/test-v5h-720p-layers.cjs`, `scripts/test-{remaining-runtime,remaining-fixes,critical-hotfixes}.cjs`.

Tidak ada file yang dihapus.

## Verifikasi

Build TypeScript dan renderer; komposisi FFmpeg nyata untuk screen/multiply/overlay, chroma/color key beserta opacity; sticker gambar dan video pendek pada timestamp, berulang, sepanjang waktu; komposisi intro + sticker dengan waktu pada output akhir; ETA dan respons katalog model simulasi; uji render end-to-end dan 720p. API key/provider sungguhan, pemutar default Windows, dan video panjang harus diuji di komputer target. ZIP memuat source dan hasil build, bukan installer Windows; `node_modules` tidak termasuk.
