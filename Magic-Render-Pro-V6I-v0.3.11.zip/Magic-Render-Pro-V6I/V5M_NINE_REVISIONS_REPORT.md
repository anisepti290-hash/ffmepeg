# Magic Render Pro V5M — sembilan revisi

Basis: paket V5L terakhir. Arsip V5M memuat source, `dist`, konfigurasi, skrip pengujian, dan laporan ini. Instal dependensi dengan `npm ci`, lalu `npm run dev` atau `npm run build`. Tidak ada `node_modules` di dalam ZIP.

## Perubahan

1. Dialog render selesai sekarang membaca ukuran MP4 yang benar-benar dihasilkan dan menampilkannya dalam MB.
2. Sticker: jalur komposit FFmpeg menerapkan opacity satu kali; media disesuaikan dengan bingkai sticker preview. Sticker baru tidak diberi fade bawaan. Saat mengedit, sticker selalu tampak di canvas; saat Play atau menggeser timeline, jadwal dan fade diterapkan pada preview. Nilai fade yang sudah disimpan oleh proyek lama tetap berlaku.
3. Form konteks YouTube SEO memakai layout responsif, label konsisten, dan input yang tidak meluber dari panel.
4. Quality & Speed memiliki pilihan CBR dan VBR yang tersimpan. CBR menyetel bitrate minimum, maksimum, dan buffer sesuai target; VBR memakai CRF menurut preset serta batas maksimum bitrate.
5. Canvas: pilihan zoom 100, 150, 200, 300, 400, 500%; layer menempel pada tengah, sepertiga, dan tepi saat ditarik, dengan garis pandu hanya saat drag. Slider seek diperbarui oleh posisi video; satu tombol ikon berganti Play/Stop. Video preview berulang mengikuti durasi playlist.
6. Media utama mempunyai input nama file hasil render. Jika kosong, nama proyek digunakan. Nama keluaran disanitasi dan benturan nama ditangani oleh layanan output yang sudah ada.
7. Status ikon mata untuk overlay dan sticker kini masuk ke data proyek, sehingga tidak terhapus saat berpindah menu dan tersimpan pada file proyek.
8. Main Media Efex: tujuh efek (`blink`, `pulse`, `sway`, `shake`, `zoom`, `light`, `glitch`), bisa ditumpuk hingga delapan; kontrol intensitas, sumbu X/Y, kecepatan, dan sinkron bit. Filter FFmpeg bekerja dalam komposisi render final; preview memakai perhitungan efek yang serupa.
9. Partikel Efex: enam jenis (`firefly`, `dust`, `smoke`, `stars`, `colors`, `lines`), hingga delapan lapisan; opacity, flip X/Y, rotasi, jumlah min–maks (maksimum 40 per lapisan), jarak min–maks, arah gerak, kecepatan, dan sinkron bit. Dibuat secara prosedural di proyek tanpa aset eksternal; gerak dan opacity dibuat periodik, dengan pemudaran saat partikel melintasi batas loop.

Analisis bit mendekode sampel audio tiap trek playlist, memperkirakan BPM dan fase, lalu memakai segmen sesuai urutan/durasi trek. Jika transien audio tidak cukup jelas, dipakai 120 BPM. Sinkronisasi ini merupakan estimasi tempo, bukan deteksi setiap pukulan secara presisi. Efek berulang dengan transisi yang dirancang halus; potongan sumber video yang frame akhir dan awalnya berbeda tetap dapat memperlihatkan sambungan visual. Banyak partikel dan efek akan meningkatkan beban render.

## File yang diubah

| Area | File |
| --- | --- |
| Project dan tipe bersama | `src/shared/domain/{projectTypes,renderTypes,settingsTypes,overlayTypes,stickerTypes,effectTypes,effectPreview}.ts`, `src/main/domain/project/projectFactory.ts`, `src/main/services/project/{projectService,projectValidator}.ts` |
| Render, efek, sticker | `src/main/services/render/{renderOrchestrator,renderCommandBuilder,encodingBuilder,renderStrategySelector}.ts`, `src/main/services/effects/{beatAnalyzer,effectFilterBuilder,effectValidator}.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/main/services/{stickerService,stickerValidator,settingsService}.ts`, `src/main/services/overlay/overlayValidator.ts` |
| IPC | `src/shared/ipc.ts`, `src/preload/index.ts`, `src/main/ipc/{renderHandlers,settingsHandlers}.ts` |
| UI | `src/renderer/{App.tsx,styles/index.css}`, `src/renderer/components/{CanvasPreview,EffectsPanels,SettingsPanel,YoutubeSeoPanel}.tsx` |
| Pengujian | `scripts/test-v5m-revisions.cjs`, `scripts/test-output-encoding.cjs`, `package.json` |

Tidak ada file proyek yang dihapus.

## Verifikasi

- `npm run typecheck` dan `npm run build`: lulus.
- `npm run test:v5m-revisions`: lulus; meliputi nama keluaran, opsi CBR/VBR, analisis dua trek pada tempo berbeda, filter efek + partikel dengan jumlah min–maks, kombinasi overlay + sticker + efek, pengukuran pixel opacity sticker, dan pemudaran seam partikel.
- `npm run test:phase22:unit`, `npm run test:render-engine`, `npm run test:output-encoding`: lulus.

Pengujian interaksi grafis Electron di Windows belum dijalankan di lingkungan ini. Periksa tampilan dan hasil proyek nyata pada perangkat Windows sebelum dipakai untuk produksi panjang.
