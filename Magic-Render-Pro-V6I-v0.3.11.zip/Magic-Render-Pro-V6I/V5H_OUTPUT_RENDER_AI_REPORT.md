# Magic Render Pro — pembaruan v5h

## Penyebab dan perubahan

1. **Output Export Folder kembali ke nilai lama:** panel Settings hanya mengubah state lokal sebelum tombol Simpan Semua ditekan; project aktif juga dapat menyimpan snapshot folder lama. Pemilihan folder kini langsung disimpan ke pengaturan global dan project. Entri manual disimpan setelah input kehilangan fokus. Panel Output di Render juga menyimpan folder global dan project saat Terapkan. Validasi pengaturan tidak lagi menolak penyimpanan folder hanya karena FFmpeg belum ditemukan; tombol Uji FFmpeg tetap memeriksa engine secara terpisah.
2. **Render lambat:** penggabungan audio tetap tahap terpisah, lalu main media, overlay, teks, sticker, dan intro dikomposisi dalam satu keluaran video. Overlay normal tidak lagi melewati kanvas transparan 1080p tambahan sebelum digabung. Ukuran sticker dibatasi ke ukuran pratinjau sebelum komposisi. Preset standar H.264 menggunakan `fast`; pilihan cepat tetap `veryfast`, pelan tetap `slow`. Durasi dan kualitas tetap bergantung pada jumlah layer, efek, CPU, FPS, dan resolusi. Koordinat serta ukuran layer preview 1920×1080 diskalakan saat render 720p/2K/4K agar komposisi tidak terpotong.
3. **Kontrol daftar layer:** pada setiap overlay, text overlay, dan sticker subscribe, Hapus memakai ikon tempat sampah. Ikon panah di sebelahnya membuka/menutup kontrol pengaturan item. Untuk teks, tombol panah juga memilih teks tersebut sebelum menampilkan form edit.
4. **Konfigurasi AI:** validasi kini mengirim permintaan multimodal kecil ke endpoint yang sama jenisnya dengan fitur SEO, sehingga key, model vision, kuota, dan akses jaringan ikut diuji. Check API Key dapat mengecek key yang sedang diketik atau key tersimpan. Save & Validasi baru menyimpan setelah uji berhasil. Key tersimpan ditampilkan sebagai placeholder tersamarkan, bukan dikembalikan sebagai teks asli ke renderer. Format gambar Mistral juga disesuaikan.
5. **YouTube SEO:** Generate aktif saat opsi 2 dipilih. Jika tidak ada render pada sesi berjalan, pengguna dapat memilih video final dari disk. Provider/model/key diambil dari Settings tersimpan pada saat pembuatan SEO, termasuk render otomatis; analisis gambar menggunakan frame video final. Buka Setting AI mengarah ke halaman Settings.

## Berkas yang diubah

- Pengaturan dan AI: `src/main/services/settingsService.ts`, `src/main/services/aiService/aiProviderClient.ts`, `src/main/ipc/settingsHandlers.ts`, `src/renderer/components/SettingsPanel.tsx`.
- Render: `src/main/services/render/{encodingBuilder,renderCommandBuilder}.ts`, `src/main/services/ffmpegEngine/{filterGraphBuilder/filterGraphBuilder,stickerFilterBuilder,textOverlayBuilder}.ts`.
- SEO/IPC: `src/main/services/aiService/{keyframeExtractor,youtubeSeoService}.ts`, `src/main/ipc/{renderHandlers,seoHandlers}.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`, `src/renderer/components/YoutubeSeoPanel.tsx`.
- UI: `src/renderer/App.tsx`, `src/renderer/components/StickerPanel.tsx`, `src/renderer/components/LayerActionIcons.tsx` (baru).
- Pengujian: `scripts/test-v5h-{settings-seo,seo-integration,overlay-fastpath,720p-layers}.cjs` (baru); `scripts/test-sticker-input.cjs`, `scripts/test-user-14-fixes.cjs` (ekspektasi UI lama disesuaikan).

Tidak ada berkas yang dihapus.

## Verifikasi dan batas

`npm run build`, `npm run typecheck`, pengujian penyimpanan ulang pengaturan, validasi AI dengan respons jaringan simulasi, SEO IPC dan tombol, komposisi FFmpeg, pixel output 720p dengan overlay/sticker, dan uji integrasi FFmpeg lulus. API key nyata dan durasi render tiga menit pada Windows tidak tersedia di lingkungan pengujian; jalankan uji pertama pada komputer target untuk mengukur waktu dan menguji kuota/provider. ZIP memuat kode sumber serta hasil build Electron, bukan installer Windows; `node_modules` tidak disertakan.
