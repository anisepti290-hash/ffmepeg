# Magic Render Pro V6F — v0.3.8

Baseline: Magic-Render-Pro-V6E-v0.3.7.zip.

## Perubahan

- `youtubeSEO.txt`: lima alternatif judul 85–95 karakter dengan keyword utama dan emoji pemisah, empat paragraf deskripsi yang mengikuti fakta visual, playlist asli, daftar perfect for, ajakan dan hashtag di akhir deskripsi. Format hanya berisi `#judul`, `#deskripsi`, `#tag`. Prompt di `resources/seo/promptimageSEO.md` diselaraskan. Diksi, budaya dan struktur kalimat mengikuti bahasa serta negara pilihan. AI tetap wajib diverifikasi pengguna sebelum publikasi; tanpa API key langsung, uji generasi live tidak dijalankan.
- Timestamp dari playlist: nama lagu dibersihkan dari angka, tanda kurung, konten dalam tanda kurung, dan underscore di `youtubetimestamp.txt` dan deskripsi SEO. Judul tidak diubah pada berkas MP3 sumber.
- Menghapus project dari daftar: file `project.json`, `seo-analysis-cache.json`, dan folder `audio-metadata-cleaned` milik project terverifikasi dibersihkan. Folder project dihapus jika kosong; video export, file pengguna, dan asset yang masih terlindungi tetap ada. Project aktif ditutup setelah dihapus; penghapusan project aktif ditolak selama render.
- Settings: pilihan `Folder Asset Library` disimpan permanen. Asset baru, termasuk folder tracklist MP3 yang diimpor setelah pengaturan disimpan, disalin ke subfolder jenisnya dengan nama unik. Asset dan tracklist lama tetap di tempat sebelumnya. Berkas asal tidak dihapus.

## Berkas utama yang diperbarui

- `src/main/services/aiService/{seoPipeline,seoFileWriter,youtubeSeoService,timestampGenerator}.ts`, `resources/seo/promptimageSEO.md`
- `src/main/services/project/recentProjectsService.ts`, `src/main/ipc/projectHandlers.ts`, `src/renderer/App.tsx`
- `src/main/services/settingsService.ts`, `src/main/services/bulk/tracklistStore.ts`, `src/main/ipc/{settingsHandlers,lockedAssetHandlers,bulkHandlers}.ts`, `src/main/services/persistentStore/{index,lockedAssetStore}.ts`, `src/renderer/components/{SettingsPanel,YoutubeSeoPanel,HelpPage}.tsx`
- Kontrak `src/shared/{ipc,domain/{aiTypes,settingsTypes,lockedAssetTypes}}.ts`, preload, package version dan uji terkait.

Tidak ada file sumber aplikasi yang dihapus.

## Verifikasi

`npm run build`, `npm run test:v6e-seo`, `npm run test:v6f`, `npm run test:v5x-upgrades`, `npm run test:v5y-sync`, dan `npm run test:v5z-assets-render` lulus. Rangkaian `npm test` sampai uji V5X menemukan ekspektasi lama angka judul lagu; ekspektasi tersebut telah diperbarui dan diuji ulang. Uji live provider AI serta GUI Windows terpaket memerlukan API key dan perangkat Windows.

Paket ZIP juga menyertakan folder `dist/` hasil `npm run build`, sesuai struktur baseline V6E.
