# Magic Render Pro V6B · v0.3.4

Baseline: Magic-Render-Pro-V6A-v0.3.3.zip.

## Perbaikan

1. Monitor render: progres encoding dibatasi pada 95% saat FFmpeg masih memproses, 97% setelah proses keluar, dan 100% hanya setelah berkas output siap dan pembersihan selesai. ETA menampilkan “Finalisasi” saat jam media telah mencapai target tetapi encoder masih bekerja.
2. Partikel: bentuk Unicode tiap jenis dibuat lebih sesuai, termasuk berlian ◆. Posisi dan arah gerak FFmpeg menggunakan rumus lintasan yang sejalan dengan preview. Kecepatan 0,25 setara sekitar 6 piksel per detik pada bidang 1920×1080. Reset preview memulai ulang efek dari detik 00; perubahan kontrol tetap diterapkan langsung.
3. Visualizer: kolom padat dan equalizer bercelah dibedakan pada preview serta render; gelombang puncak, simetris, dan spektrum mengalir diberi bentuk tersendiri. Puncak frekuensi dapat diposisikan di kiri, tengah, atau kanan. Kepadatan memakai slider tiga tingkat. Setiap gaya dapat memakai warna sendiri, termasuk spektrum. Preview membaca kontrol baru tanpa menunggu tombol Terapkan.
4. Editor overlay aset: gambar mask dengan klik titik berurutan, tutup dengan klik titik pertama, kemudian area luar terpotong. Slider trim menyiapkan pilihan mulai/selesai; tombol Trim menerapkannya. Jam playback ditampilkan di bawah canvas.

## File penyebab dan file diperbaiki

| Bagian | File |
| --- | --- |
| Progres dan ETA | `src/main/services/render/renderOrchestrator.ts`, `src/renderer/utils/renderEta.ts`, `src/renderer/App.tsx` |
| Jenis/arah/kecepatan partikel | `src/shared/domain/particleGeometry.ts`, `src/shared/domain/effectPreview.ts`, `src/main/services/effects/effectFilterBuilder.ts`, `src/renderer/styles/index.css` |
| Gaya visualizer dan warna | `src/shared/domain/visualizerTypes.ts`, `src/shared/domain/visualizerPalette.ts`, `src/main/services/effects/visualizerBuilder.ts`, `src/main/services/effects/visualizerValidator.ts`, `src/renderer/components/VisualizerPreview.tsx`, `src/renderer/components/EffectsPanels.tsx` |
| Mask/trim/jam | `src/renderer/components/AssetVisualEditor.tsx`, `src/renderer/components/KeyedMedia.tsx`, `src/renderer/styles/index.css` |
| Versi dan uji | `package.json`, `package-lock.json`, `src/renderer/components/HelpPage.tsx`, `scripts/test-v6b-render-effects-editor.cjs`, `scripts/test-render-orchestrator.cjs` |

Tidak ada file proyek yang dihapus. Trim dan masking disimpan sebagai konfigurasi preset; media sumber tidak dimodifikasi.

## Pemeriksaan

- `npm run build` lulus.
- `npm run test:orchestrator` lulus, termasuk memastikan tidak ada event 100% sebelum status selesai.
- `npm run test:v6b-render-effects` lulus untuk arah, kecepatan, bentuk partikel dan filter FFmpeg visualizer.
- `npm run test:v6a-effects-mask` dan `npm run test:v5z-assets-render` lulus.

Pengujian visual interaktif pada Windows perlu dilakukan di perangkat tujuan; lingkungan ini memvalidasi build serta output FFmpeg dengan contoh media sintetis.
