import type { VisualizerEffect, VisualizerPalette } from './visualizerTypes';

export const visualizerPaletteStops: Record<Exclude<VisualizerPalette,'custom'>,string[]> = {
  rainbow:['#2cf9ff','#8b5cf6','#ff38d1'], fire:['#ff5515','#ff9c37','#fff05a'], cool:['#2ca0ff','#70d9ff','#b4ffff'],
  viridis:['#440154','#21918c','#fde725'],magma:['#521150','#b73779','#fcfdbf'],
};

export function visualizerColors(item: VisualizerEffect): string[] {
  if(item.palette==='custom') return [item.color,item.color,item.color];
  const preset = item.palette??(item.kind==='spectrumFire'?'fire':item.kind==='spectrumCool'?'cool':item.kind==='spectrumViridis'?'viridis':item.kind==='spectrumMagma'?'magma':'rainbow');
  return visualizerPaletteStops[preset??'rainbow'];
}

export function frequencyFraction(fraction:number,position:VisualizerEffect['peakPosition']):number {
  return position==='right'?1-fraction:position==='center'?Math.abs(2*fraction-1):fraction;
}
