export type ProjectIntro = {
  enabled: boolean;
  path: string | null;
  fallbackFadeInSec: number;
  fallbackStyle?: 'dark' | 'blur';
  fallbackBlur?: number;
  fallbackBrightness?: number;
  /** Optional explicit fade for the intro clip; zero disables the automatic intro fade. */
  fadeInSec?: number;
};

export type IntroLibraryItem = {
  assetId: string;
  path: string;
  name: string;
  extension: string;
  sizeBytes: number;
  modifiedAt: string;
};

export type IntroPipelinePlan = {
  enabled: boolean;
  introPath: string | null;
  fallbackFadeInSec: number;
  mainMediaFadeInSec: number;
  prependIntro: boolean;
};

/** The main media setting wins; Intro's fallback is used only without an intro and without a media fade. */
export function effectiveMainFadeIn(project: import('./projectTypes').ProjectData): number {
  const ownFade = project.mainMedia?.fade.fadeInSec ?? 0;
  return ownFade > 0 ? ownFade : project.intro.enabled ? 0 : project.intro.fallbackFadeInSec;
}

export function activeIntroBlur(project: import('./projectTypes').ProjectData): { duration: number; blur: number; brightness: number } | null {
  if (project.intro.enabled || (project.mainMedia?.fade.fadeInSec ?? 0) > 0 || project.intro.fallbackStyle !== 'blur') return null;
  const duration = Math.max(0, Math.min(30, project.intro.fallbackFadeInSec));
  return duration > 0 ? { duration, blur: project.intro.fallbackBlur ?? 12, brightness: project.intro.fallbackBrightness ?? -0.25 } : null;
}
