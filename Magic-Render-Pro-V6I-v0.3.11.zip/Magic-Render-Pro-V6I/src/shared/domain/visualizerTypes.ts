export type VisualizerKind = 'bars' | 'line' | 'dots' | 'wave' | 'mirror' | 'spectrum' | 'smoothBars' | 'waveLine' | 'wavePoints' | 'spectrumFire' | 'spectrumCool' | 'spectrumScroll' | 'solidBars' | 'sparkDots' | 'wavePeak' | 'spectrumViridis' | 'spectrumMagma';
export type VisualizerPalette = 'rainbow' | 'fire' | 'cool' | 'viridis' | 'magma' | 'custom';
export type VisualizerEffect = {
  id: string;
  kind: VisualizerKind;
  position: { x: number; y: number };
  size: { width: number; height: number };
  color: string;
  opacity: number;
  sensitivity: number;
  smoothing?: number;
  frequencyScale?: 'log' | 'linear';
  palette?: VisualizerPalette;
  peakPosition?: 'left' | 'center' | 'right';
  density?: 16 | 32 | 64 | 128;
  /** Fraction of each frequency band's width reserved for clear space. */
  bandSpacing?: number;
  roundedTop?: boolean;
  cornerRadius?: number;
  glow?: number;
};
export function defaultVisualizer(id: string): VisualizerEffect {
  return { id, kind: 'bars', position: { x: 280, y: 760 }, size: { width: 1360, height: 210 }, color: '#2cf9ff', opacity: 0.8, sensitivity: 1, smoothing: 0.7, frequencyScale: 'log', palette: 'rainbow', peakPosition:'left', density:64, bandSpacing:.15, roundedTop:false, cornerRadius:6, glow:0 };
}
