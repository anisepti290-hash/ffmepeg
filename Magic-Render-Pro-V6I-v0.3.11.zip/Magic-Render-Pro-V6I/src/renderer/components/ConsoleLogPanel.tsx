import type { JSX } from 'react';
import { ChevronIcon } from './LayerActionIcons';
import { useEffect, useMemo, useState } from 'react';
import type { RenderProgress, RenderStatus } from '../../shared/domain/renderTypes';
import type { ApplicationLogEntry } from '../../shared/ipc';

export type ConsoleLogEntry = {
  id: number;
  createdAt: string;
  kind: 'command' | 'activity' | 'progress' | 'error';
  message: string;
  detail?: string | null;
  status: RenderProgress['status'];
};

const descriptions: Record<string, string> = {
  'Bootstrapping Magic Render Pro.': 'Aplikasi sedang disiapkan.',
  'Application bootstrap failed.': 'Aplikasi gagal melakukan persiapan awal.',
  'Electron window initialized before renderer navigation.': 'Jendela aplikasi siap dimuat.',
  'Locked asset persistence initialized.': 'Daftar asset tersimpan berhasil dimuat.',
  'Stale render cache cleanup completed.': 'Cache render lama selesai dibersihkan.',
  'FFmpeg stage started.': 'Perintah tahap render mulai dijalankan.',
  'FFmpeg stage completed.': 'Tahap render selesai.',
  'FFmpeg stage failed.': 'Tahap render gagal. Periksa rincian kesalahan.',
  'Render job failed.': 'Pekerjaan render gagal.',
  'Renderer console error.': 'Terjadi kesalahan pada tampilan aplikasi.',
  'Renderer failed to load.': 'Tampilan aplikasi gagal dimuat.',
  'Renderer process exited unexpectedly.': 'Tampilan aplikasi berhenti tidak terduga.',
  'Media protocol request failed.': 'Media lokal gagal dimuat.',
  'Uncaught exception in Main Process.': 'Terjadi kesalahan aplikasi yang tidak tertangani.',
  'Unhandled promise rejection in Main Process.': 'Proses aplikasi gagal tanpa penanganan.',
  'Unhandled renderer error.': 'Terjadi kesalahan pada tampilan aplikasi.',
  'Unhandled renderer promise rejection.': 'Proses tampilan aplikasi gagal.',
  'Preview video playback failed.': 'Video tidak dapat diputar di preview.',
  'Main image preview failed.': 'Gambar utama tidak dapat dimuat di preview.',
  'Main media element failed to load.': 'Media utama gagal dimuat di preview.',
};

function userMessage(message: string): string {
  if (message.startsWith('FFmpeg command:')) return 'Perintah FFmpeg untuk tahap render telah disiapkan.';
  if (/no such file|enoent|file not found|cannot find/i.test(message)) return 'File atau program yang dibutuhkan tidak ditemukan. Periksa lokasi media dan FFmpeg.';
  if (/permission denied|access denied/i.test(message)) return 'Akses ke file ditolak. Periksa izin folder sumber dan output.';
  if (/unknown encoder|encoder not found/i.test(message)) return 'Encoder video tidak tersedia di FFmpeg yang dipilih.';
  if (/failed to load|fetch failed/i.test(message)) return 'Media atau layanan tidak dapat dimuat.';
  if (/^(?:Error:|TypeError:|RangeError:)|cannot read properties|is not a function|invalid argument/i.test(message)) return 'Terjadi kesalahan internal. Periksa pengaturan dan file yang digunakan.';
  return descriptions[message] ?? message
    .replace(/\[SISTEM\]/g, '[APLIKASI]')
    .replace(/\bRender single-pass\b/g, 'Render satu tahap')
    .replace(/\bStrategy=single-pass\b/g, 'Strategi=satu tahap')
    .replace(/\bStrategy=multi-stage\b/g, 'Strategi=beberapa tahap');
}

function userDetail(detail: string | null | undefined): string | null {
  if (!detail) return null;
  try {
    const value = JSON.parse(detail) as Record<string, unknown>;
    if (typeof value.stage === 'string') return `Tahap: ${value.stage.replaceAll('-', ' ')}.${value.code ? ` Kode: ${String(value.code)}.` : ''}`;
    if (typeof value.message === 'string') return userMessage(value.message);
    if (typeof value.reason === 'string') return userMessage(value.reason);
    if (typeof value.jobs === 'number') return `${value.jobs} pekerjaan sementara diproses.`;
    return null;
  } catch { return userMessage(detail); }
}

export function appendConsoleEntry(entries: ConsoleLogEntry[], progress: RenderProgress): ConsoleLogEntry[] {
  if (entries.some((entry) => entry.status === progress.status && entry.message === userMessage(progress.logLine) && entry.detail === userDetail(progress.errorMessage) && entry.kind !== 'command')) return entries;
  const kind = progress.errorMessage ? 'error' : /^(FFmpeg command:|Perintah FFmpeg:)/.test(progress.logLine) ? 'command' : /%|speed|Render (selesai|dijeda|dibatalkan)/i.test(progress.logLine) ? 'progress' : 'activity';
  const entry: ConsoleLogEntry = {
    id: Date.now() + entries.length,
    createdAt: new Date().toISOString(),
    kind,
    message: userMessage(progress.logLine),
    detail: userDetail(progress.errorMessage),
    status: progress.status,
  };
  const next = [...entries, entry];
  return next.length > 400 ? next.slice(-400) : next;
}


export function appendApplicationLog(entries: ConsoleLogEntry[], entry: ApplicationLogEntry): ConsoleLogEntry[] {
  if (!entry || typeof entry.message !== 'string' || typeof entry.createdAt !== 'string') return entries;
  if (entries.some((previous) => previous.createdAt === entry.createdAt && previous.message === userMessage(entry.message) && previous.detail === userDetail(entry.detail))) return entries;
  const kind: ConsoleLogEntry['kind'] = entry.level === 'ERROR' ? 'error' : /\[(RENDER|PROSES)\]/.test(entry.message) ? 'progress' : 'activity';
  const status: RenderStatus = entry.level === 'ERROR' || entry.level === 'WARN' ? 'error' : 'idle';
  const applicationEntry: ConsoleLogEntry = {
    id: Date.now() + entries.length,
    createdAt: entry.createdAt,
    kind,
    message: userMessage(entry.message),
    detail: userDetail(entry.detail),
    status,
  };
  const next: ConsoleLogEntry[] = [...entries, applicationEntry];
  return next.length > 400 ? next.slice(-400) : next;
}

export function ConsoleLogPanel({ entries }: { entries: ConsoleLogEntry[] }): JSX.Element {
  const [expanded, setExpanded] = useState(false);
  const [filter, setFilter] = useState<'all' | ConsoleLogEntry['kind']>('all');
  const visible = useMemo(() => filter === 'all' ? entries : entries.filter((entry) => entry.kind === filter), [entries, filter]);

  useEffect(() => {
    if (!expanded) return;
    const node = document.getElementById('magic-render-console-log');
    if (node) node.scrollTop = node.scrollHeight;
  }, [visible.length, expanded]);

  return <section className="mt-4 overflow-hidden rounded-xl border border-cyber-violet/25 bg-black/30">
    <header className="flex items-center justify-between gap-3 border-b border-white/5 px-4 py-3">
      <div><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-violet">Console Log</div><div className="text-[10px] text-white/35">Aktivitas, command FFmpeg, progress, dan error terjemahan</div></div>
      <div className="flex items-center gap-2"><select className="rounded border border-white/10 bg-black/30 px-2 py-1 text-[10px]" value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)}><option value="all">Semua</option><option value="command">Perintah</option><option value="activity">Aktivitas</option><option value="progress">Progres</option><option value="error">Kesalahan</option></select><button className="rounded border border-cyber-violet/30 px-2 py-1 text-[10px]" onClick={() => setExpanded((value) => !value)}><ChevronIcon expanded={expanded} /></button></div>
    </header>
    {expanded && <div id="magic-render-console-log" className="max-h-72 overflow-auto px-4 py-3 font-mono text-[10px]">{visible.length === 0 ? <div className="text-white/30">Belum ada log render.</div> : visible.map((entry) => <div key={entry.id} className="mb-2 border-b border-white/5 pb-2"><div className="flex gap-2 text-white/35"><span>{entry.createdAt.slice(11, 19)}</span><span className="uppercase">{{command:'Perintah', activity:'Aktivitas', progress:'Progres', error:'Kesalahan'}[entry.kind]}</span><span>{{idle:'Siap', compressing_video:'Memproses video', assembling_overlay:'Menyusun overlay', composing_text:'Menyusun konten', processing_audio:'Memproses audio', paused:'Dijeda', done:'Selesai', error:'Gagal', cancelled:'Dibatalkan'}[entry.status]}</span></div><div className="mt-1 whitespace-pre-wrap break-words text-white/65">{entry.message}</div>{entry.detail && <div className="mt-1 whitespace-pre-wrap break-words text-cyber-fuchsia/80">{entry.detail}</div>}</div>)}</div>}
  </section>;
}
