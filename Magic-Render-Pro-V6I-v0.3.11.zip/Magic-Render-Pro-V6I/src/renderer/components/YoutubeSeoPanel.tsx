import type { JSX } from 'react';
import { useEffect, useState } from 'react';
import type { ProjectData } from '../../shared/domain/projectTypes';
import type { AiCredentialsStatus, SeoContext, YoutubeSeoResult } from '../../shared/domain/aiTypes';
import type { GlobalSettings } from '../../shared/domain/settingsTypes';

type Goal = NonNullable<SeoContext['optimizationGoals']>[number];
type Style = NonNullable<SeoContext['titleStyle']>;
type Template = { id: string; keyword: string; context: SeoContext; analysisSource: 'main' | 'manual'; analysisMediaPath?: string | null };
const TEMPLATE_KEY = 'magic-render-pro:seo-templates:v2';
const PREVIOUS_KEY = 'magic-render-pro:seo-templates:v1';
const GOALS: Array<{ id: Goal; label: string }> = [
  { id: 'youtube-search', label: 'YouTube Search' }, { id: 'suggested-videos', label: 'Suggested Videos' },
  { id: 'browse-features', label: 'Browse Features' }, { id: 'brand-awareness', label: 'Brand Awareness' },
  { id: 'balanced', label: 'Seimbang' },
];
const STYLES: Array<{ id: Style; label: string }> = [
  { id: 'seo-friendly', label: 'SEO Friendly' }, { id: 'cinematic', label: 'Cinematic' },
  { id: 'informative', label: 'Informatif' }, { id: 'curiosity', label: 'Curiosity' },
  { id: 'natural', label: 'Natural' },
];
const CONTENT_TYPES = ['Musik', 'Musik instrumental', 'Nature ambience', 'Tutorial', 'Gaming', 'Travel', 'Podcast', 'Relaksasi'];
const COUNTRIES = [
  { value: 'Amerika Serikat (US)', language: 'English (US)' },
  { value: 'Indonesia', language: 'Bahasa Indonesia' },
  { value: 'Inggris (UK)', language: 'English (UK)' },
  { value: 'Kanada', language: 'English (CA)' },
  { value: 'Australia', language: 'English (AU)' },
];
const DEFAULT_GOALS = GOALS.map((item) => item.id);

function readTemplates(): Template[] {
  if (typeof localStorage === 'undefined') return [];
  try {
    const saved: unknown = JSON.parse(localStorage.getItem(TEMPLATE_KEY) ?? '[]');
    if (Array.isArray(saved) && saved.length) return saved.filter((item): item is Template => !!item && typeof item.id === 'string' && typeof item.keyword === 'string' && !!item.context && typeof item.context === 'object').slice(0, 20);
    const previous: unknown = JSON.parse(localStorage.getItem(PREVIOUS_KEY) ?? '[]');
    return Array.isArray(previous) ? previous.filter((item) => !!item && typeof item.keyword === 'string').slice(0, 20).map((item) => ({ id: String(item.id), keyword: item.keyword, context: { contentType: 'Musik', nicheGenre: item.nicheGenre, targetCountry: COUNTRIES[0]!.value, targetLanguage: COUNTRIES[0]!.language, optimizationGoals: [...DEFAULT_GOALS], titleStyle: 'seo-friendly' as const }, analysisSource: 'main' as const })) : [];
  } catch { return []; }
}

export function YoutubeSeoPanel({ project, onProjectChange, onMessage, onOpenSettings, statusLine = 'SEO belum dijalankan.', autoGenerating = false, latestResult = null, onStatus = () => undefined }: {
  project: ProjectData;
  onProjectChange: (project: ProjectData) => void;
  onMessage: (message: string) => void;
  onOpenSettings: () => void;
  statusLine?: string;
  autoGenerating?: boolean;
  latestResult?: YoutubeSeoResult | null;
  onStatus?: (message: string) => void;
}): JSX.Element {
  const [result, setResult] = useState<YoutubeSeoResult | null>(null);
  const [aiStatus, setAiStatus] = useState<AiCredentialsStatus | null>(null);
  const [aiSettings, setAiSettings] = useState<Pick<GlobalSettings, 'aiProvider' | 'aiModel'> | null>(null);
  const [busy, setBusy] = useState(false);
  const [templates, setTemplates] = useState<Template[]>(readTemplates);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const mode = project.youtubeSEO.mode ?? 'timestamp';
  const keyword = project.youtubeSEO.mainKeyword;
  const context = project.youtubeSEO.context ?? {};
  const contentType = context.contentType ?? 'Musik';
  const country = context.targetCountry ?? COUNTRIES[0]!.value;
  const goals = context.optimizationGoals ?? DEFAULT_GOALS;
  const style = context.titleStyle ?? 'seo-friendly';
  const analysisSource = project.youtubeSEO.analysisSource ?? 'main';
  const analysisMediaPath = analysisSource === 'manual' ? project.youtubeSEO.analysisMediaPath : project.mainMedia?.path;
  useEffect(() => { setResult(latestResult); }, [latestResult, project.projectId]);
  useEffect(() => {
    let active = true;
    void window.magicRender.getSettings().then(async (settings) => {
      if (!active) return;
      setAiSettings({ aiProvider: settings.aiProvider, aiModel: settings.aiModel });
      const status = await window.magicRender.getSettingsAiStatus(settings.aiProvider, settings.aiModel, undefined, true);
      if (active) setAiStatus(status);
    }).catch((error) => { if (active) onMessage(error instanceof Error ? error.message : 'Status AI tidak dapat dibaca.'); });
    return () => { active = false; };
  }, []);

  function update(patch: Partial<ProjectData['youtubeSEO']>): void { onProjectChange({ ...project, youtubeSEO: { ...project.youtubeSEO, ...patch } }); }
  function updateContext(patch: Partial<SeoContext>): void { update({ context: { ...context, ...patch } }); }
  function saveTemplates(value: Template[]): boolean {
    try { localStorage.setItem(TEMPLATE_KEY, JSON.stringify(value)); setTemplates(value); return true; }
    catch { onMessage('Template gagal disimpan. Periksa penyimpanan aplikasi.'); return false; }
  }
  function saveTemplate(): void {
    if (!keyword.split(',').some((item) => item.trim())) { onMessage('Isi topik atau keyword utama sebelum menyimpan template.'); return; }
    const id = `${contentType.toLocaleLowerCase()}|${keyword.trim().toLocaleLowerCase()}|${country.toLocaleLowerCase()}`;
    const next = [{ id, keyword: keyword.trim(), context: { ...context, contentType, targetCountry: country, targetLanguage: context.targetLanguage || COUNTRIES.find((item) => item.value === country)?.language || 'English (US)', optimizationGoals: [...goals], titleStyle: style }, analysisSource, analysisMediaPath: analysisSource === 'manual' ? analysisMediaPath : null }, ...templates.filter((item) => item.id !== id)].slice(0, 20);
    if (saveTemplates(next)) { setSelectedTemplate(id); onMessage('Template SEO disimpan untuk project berikutnya.'); }
  }
  function applyTemplate(id: string): void {
    setSelectedTemplate(id);
    const item = templates.find((value) => value.id === id);
    if (item) update({ mainKeyword: item.keyword, context: { ...context, ...item.context }, analysisSource: item.analysisSource, analysisMediaPath: item.analysisMediaPath ?? null });
  }
  function toggleGoal(goal: Goal): void {
    const next = goals.includes(goal) ? goals.filter((item) => item !== goal) : [...goals, goal];
    if (!next.length) { onMessage('Pilih setidaknya satu tujuan optimasi.'); return; }
    updateContext({ optimizationGoals: next });
  }
  async function chooseAnalysisMedia(): Promise<void> {
    try { const file = await window.magicRender.chooseSeoMedia(); if (file) update({ analysisSource: 'manual', analysisMediaPath: file }); }
    catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal memilih media untuk analisis.'); }
  }
  async function generate(): Promise<void> {
    if (mode !== 'timestamp-seo') return;
    if (!keyword.split(',').some((item) => item.trim())) { onMessage('Isi topik atau keyword utama.'); return; }
    if (!contentType.trim() || !country.trim()) { onMessage('Isi jenis konten dan negara target sebelum generate.'); return; }
    if (!COUNTRIES.some((item) => item.value === country) && !context.targetLanguage?.trim()) { onMessage('Isi bahasa metadata untuk negara target lainnya.'); return; }
    if (!analysisMediaPath) { onMessage(analysisSource === 'manual' ? 'Upload gambar atau video untuk analisis.' : 'Import media utama sebelum membuat YouTube SEO.'); return; }
    setBusy(true); onStatus('Menyiapkan prompt visual dan provider AI...');
    try {
      const settings = await window.magicRender.getSettings();
      setAiSettings({ aiProvider: settings.aiProvider, aiModel: settings.aiModel });
      const status = await window.magicRender.getSettingsAiStatus(settings.aiProvider, settings.aiModel, undefined, true);
      setAiStatus(status);
      if (!status.configured || !status.authenticated) { onStatus(status.message); onMessage(status.message); return; }
      const effectiveProject = { ...project, youtubeSEO: { ...project.youtubeSEO, provider: settings.aiProvider, model: settings.aiModel, context: { ...context, contentType, targetCountry: country, targetLanguage: context.targetLanguage || COUNTRIES.find((item) => item.value === country)?.language || 'English (US)', optimizationGoals: [...goals], titleStyle: style } } };
      const value = await window.magicRender.generateYoutubeSeo(effectiveProject);
      setResult(value);
      onStatus(`Selesai • ${value.titles.length} judul • ${value.outputFiles.seoTxt}`);
      onMessage(`YouTube SEO selesai. File: ${value.outputFiles.seoTxt}`);
    } catch (error) { const message = error instanceof Error ? error.message : 'AI SEO gagal.'; onStatus(`Gagal • ${message}`); onMessage(message); }
    finally { setBusy(false); }
  }
  return <div className="mt-4 rounded-xl border border-cyber-fuchsia/20 bg-black/20 p-4">
    <div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-fuchsia">YouTube SEO & Timestamp</div>
    <div className="mt-1 text-[10px] text-white/45">AI menjalankan prompt visual terlampir dengan model di Setting. Timestamp dibuat dari playlist sebenarnya.</div>
    <div className="mt-4 grid gap-2">
      <label className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 ${mode === 'timestamp' ? 'border-cyber-cyan/40 bg-cyber-cyan/5' : 'border-white/10'}`}><input type="radio" name="seo-mode" checked={mode === 'timestamp'} onChange={() => update({ mode: 'timestamp', enabled: false })}/><span><strong className="block text-xs">Opsi 1 — Timestamp saja</strong><small className="text-[10px] text-white/45">Render tanpa AI; menghasilkan youtubetimestamp.txt.</small></span></label>
      <label className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 ${mode === 'timestamp-seo' ? 'border-cyber-fuchsia/40 bg-cyber-fuchsia/5' : 'border-white/10'}`}><input type="radio" name="seo-mode" checked={mode === 'timestamp-seo'} onChange={() => update({ mode: 'timestamp-seo', enabled: true })}/><span><strong className="block text-xs">Opsi 2 — Timestamp + YouTube SEO</strong><small className="text-[10px] text-white/45">Analisis visual, sepuluh pilihan judul, deskripsi siap salin, dan tag.</small></span></label>
    </div>
    {mode === 'timestamp-seo' && <div className="mrp-seo-context mt-4 rounded-lg border border-white/10 bg-black/20 p-3 text-xs">
      <div className="mrp-seo-field"><span className="mrp-seo-caption">1. Gambar utama</span><div className="mrp-seo-source-options"><label className="mrp-seo-choice"><input type="radio" name="seo-source" checked={analysisSource === 'main'} onChange={() => update({ analysisSource: 'main' })}/>Ambil dari main content</label><label className="mrp-seo-choice"><input type="radio" name="seo-source" checked={analysisSource === 'manual'} onChange={() => update({ analysisSource: 'manual' })}/>Upload gambar/video</label></div>{analysisSource === 'manual' && <button type="button" className="mrp-btn mt-2" onClick={() => void chooseAnalysisMedia()}>Upload gambar / video</button>}<p className="mt-2 break-all text-[10px] text-white/45">{analysisMediaPath ?? 'Gambar analisis belum dipilih.'}</p></div>
      <div className="mrp-seo-form-grid mt-3">
        <label>2. Jenis konten video<select value={CONTENT_TYPES.includes(contentType) ? contentType : 'other'} onChange={(e) => updateContext({ contentType: e.target.value === 'other' ? '' : e.target.value })}>{CONTENT_TYPES.map((item) => <option key={item} value={item}>{item}</option>)}<option value="other">Lainnya...</option></select>{!CONTENT_TYPES.includes(contentType) && <input maxLength={120} value={contentType} onChange={(e) => updateContext({ contentType: e.target.value })} placeholder="Tulis jenis konten" />}</label>
        <label>3. Topik atau keyword utama<input maxLength={500} value={keyword} onChange={(e) => update({ mainKeyword: e.target.value })} placeholder="whiskey blues, late night blues" /><small className="text-white/45">Pisahkan beberapa keyword dengan koma.</small></label>
        <label>4. Bahasa & target penonton<select value={COUNTRIES.some((item) => item.value === country) ? country : 'other'} onChange={(e) => { const entry = COUNTRIES.find((item) => item.value === e.target.value); updateContext({ targetCountry: entry?.value ?? '', targetLanguage: entry?.language ?? '' }); }}>{COUNTRIES.map((item) => <option key={item.value} value={item.value}>{item.value} • {item.language}</option>)}<option value="other">Negara lain...</option></select>{!COUNTRIES.some((item) => item.value === country) && <><input maxLength={80} value={country} onChange={(e) => updateContext({ targetCountry: e.target.value })} placeholder="Tulis negara target" /><input maxLength={80} value={context.targetLanguage ?? ''} onChange={(e) => updateContext({ targetLanguage: e.target.value })} placeholder="Bahasa metadata (mis. Español)" /></>}</label>
      </div>
      <fieldset className="mrp-seo-field mt-3"><legend className="mrp-seo-caption">5. Tujuan Optimasi</legend><div className="mrp-seo-choice-grid">{GOALS.map(({ id, label }) => <label key={id} className="mrp-seo-choice"><input type="checkbox" checked={goals.includes(id)} onChange={() => toggleGoal(id)}/>{label}</label>)}</div></fieldset>
      <fieldset className="mrp-seo-field mt-3"><legend className="mrp-seo-caption">6. Gaya Judul</legend><div className="mrp-seo-choice-grid">{STYLES.map(({ id, label }) => <label key={id} className="mrp-seo-choice"><input type="radio" name="seo-title-style" checked={style === id} onChange={() => updateContext({ titleStyle: id })}/>{label}</label>)}</div></fieldset>
      <div className="mt-3 flex flex-wrap items-center gap-2"><select className="mrp-seo-template-select" aria-label="Template SEO tersimpan" value={selectedTemplate} onChange={(e) => applyTemplate(e.target.value)}><option value="">Pilih template tersimpan</option>{templates.map((item) => <option key={item.id} value={item.id}>{item.keyword} • {item.context.contentType ?? 'Musik'}</option>)}</select><button type="button" className="mrp-btn" onClick={saveTemplate}>Simpan sebagai template</button><button type="button" className="mrp-btn" disabled={!selectedTemplate} onClick={() => { saveTemplates(templates.filter((item) => item.id !== selectedTemplate)); setSelectedTemplate(''); }}>Hapus template</button></div>
      <p className="mt-2 text-[10px] text-white/45">Template menyimpan pilihan dan keyword untuk project berikutnya. AI membedakan fakta visual dan dugaan; data volume pencarian langsung tidak tersedia.</p>
    </div>}
    <div className="mt-3 rounded border border-white/10 bg-black/20 p-2 text-[10px] text-white/50">AI: {aiSettings ? `${aiSettings.aiProvider} • ${aiSettings.aiModel}` : 'memuat...'} — {aiStatus?.message ?? 'Memeriksa status...'}</div>
    <div className="mt-3 flex flex-wrap gap-2"><button className="mrp-btn mrp-btn--primary inline-flex items-center gap-2" onClick={() => void generate()} disabled={mode !== 'timestamp-seo' || busy || autoGenerating}>{(busy || autoGenerating) && <span role="status" aria-label="AI sedang memproses" className="h-3 w-3 animate-spin rounded-full border-2 border-white/30 border-t-white"/>}{busy || autoGenerating ? 'Menganalisis / menulis...' : 'Generate YouTube SEO'}</button><button className="mrp-btn" onClick={onOpenSettings}>Buka Setting AI</button></div>
    <div role="status" aria-live="polite" title={statusLine} className="mt-2 truncate rounded border border-cyber-fuchsia/20 bg-black/30 px-2 py-1.5 font-mono text-[10px] text-white/65">[SEO] {statusLine}</div>
    {result && <div className="mt-3 space-y-2 rounded-lg border border-white/5 p-3 text-[10px] text-white/70"><div className="font-semibold text-cyber-cyan">YouTube SEO — periksa sebelum publikasi</div><div>{result.titles.length} judul • {result.tags.length} tag • {result.hashtags.length} hashtag</div><ol className="list-decimal pl-4">{result.titles.map((title, index) => <li key={index} className="mb-1">{title}{result.titleNotes?.[index] && <span className="block text-white/40">{result.titleNotes[index]}</span>}</li>)}</ol>{result.readyDescription && <details open><summary className="cursor-pointer">Deskripsi siap tempel</summary><p className="mt-2 whitespace-pre-wrap select-text">{result.readyDescription}</p><button type="button" className="mrp-btn mt-2" onClick={() => void navigator.clipboard.writeText(result.readyDescription ?? '').then(() => onMessage('Deskripsi disalin.')).catch(() => onMessage('Gagal menyalin deskripsi.'))}>Salin deskripsi</button></details>}<details><summary className="cursor-pointer">Analisis visual dan keyword</summary><p className="mt-2">{result.visualAnalysis}</p><p className="mt-1">Teramati: {result.visualEvidence?.observed.join('; ')}</p><p className="mt-1">Perlu diperiksa: {result.visualEvidence?.uncertain.join('; ')}</p><p className="mt-2">Utama: {result.keywordsPrimary.join(', ')}</p><p className="mt-2">Sekunder: {result.keywordsSecondary.join(', ')}</p><p className="mt-2">Long-tail: {result.keywordsLongTail.join(', ')}</p></details><div>Tags: {result.tags.join(', ')}</div><div>Hashtags: {result.hashtags.join(' ')}</div><div className="break-all">{result.outputFiles.seoTxt}</div><div className="break-all">{result.outputFiles.timestampTxt}</div></div>}
  </div>;
}
