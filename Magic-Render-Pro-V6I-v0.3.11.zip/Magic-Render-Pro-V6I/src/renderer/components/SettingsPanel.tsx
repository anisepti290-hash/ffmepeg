import type { JSX } from 'react';
import { useEffect, useRef, useState } from 'react';
import type { AiCredentialsStatus, AiProvider } from '../../shared/domain/aiTypes';
import type { ProjectData } from '../../shared/domain/projectTypes';
import type { GlobalSettings, GpuInfo } from '../../shared/domain/settingsTypes';

type Props = { project: ProjectData | null; onProjectChange: (project: ProjectData, options?: { mode?: 'record' | 'replace'; label?: string }) => void; onMessage: (message: string) => void };
const providerDefaults: Record<AiProvider, string> = { openai: 'gpt-4o-mini', gemini: 'gemini-3.5-flash-lite', openrouter: 'openrouter/free', groq: 'qwen/qwen3.8-27b', mistral: 'pixtral-large-latest', ollama: 'gemma3:4b' };
const providerLabels: Record<AiProvider, string> = { openai: 'OpenAI (berbayar)', gemini: 'Gemini (free tier)', openrouter: 'OpenRouter (:free)', groq: 'Groq (free plan)', mistral: 'Mistral', ollama: 'Ollama lokal (tanpa API key)' };

export function SettingsPanel({ project, onProjectChange, onMessage }: Props): JSX.Element {
  const [settings, setSettings] = useState<GlobalSettings | null>(null);
  const [apiKey, setApiKey] = useState('');
  const [aiStatus, setAiStatus] = useState<AiCredentialsStatus | null>(null);
  const [aiModels, setAiModels] = useState<string[]>([]);
  const [modelMessage, setModelMessage] = useState('Simpan API key atau klik Muat Model.');
  const [loadingModels, setLoadingModels] = useState(false);
  const [freeOnly, setFreeOnly] = useState(true);
  const [busy, setBusy] = useState(false);
  const [cleaningCache, setCleaningCache] = useState(false);
  const [testingEngine, setTestingEngine] = useState(false);
  const [detectingGpu, setDetectingGpu] = useState(false);
  const [gpuInfo, setGpuInfo] = useState<GpuInfo | null>(null);
  const outputCommit = useRef<Promise<void> | null>(null);
  const [engineCheck, setEngineCheck] = useState<Awaited<ReturnType<typeof window.magicRender.testRenderEngine>> | null>(null);
  useEffect(() => { let mounted = true; void window.magicRender.getSettings().then(async (loaded) => {
    if (!mounted) return;
    setSettings(loaded);
    const result = await window.magicRender.testRenderEngine(loaded.ffmpegPath, loaded.ffprobePath);
    if (mounted) setEngineCheck(result);
  }).catch((error) => { if (mounted) onMessage(error instanceof Error ? error.message : 'Gagal memuat Settings.'); }); return () => { mounted = false; }; }, []);
  useEffect(() => { if (!settings) return; let active = true; const provider = settings.aiProvider; const model = settings.aiModel; setAiStatus(null); void window.magicRender.getSettingsAiStatus(provider, model, undefined, true).then((status) => { if (active) setAiStatus(status); }).catch(() => { if (active) setAiStatus(null); }); return () => { active = false; }; }, [settings?.aiProvider]);
  useEffect(() => { if (!settings) return; let active = true; setAiModels([]); if (settings.aiProvider !== 'ollama' && !aiStatus?.configured) { setLoadingModels(false); setModelMessage(aiStatus === null ? 'Memeriksa API key tersimpan...' : 'Masukkan dan simpan API key provider ini untuk memuat daftar model.'); return; } setModelMessage('Memuat model dari provider...'); setLoadingModels(true); void window.magicRender.listSettingsAiModels(settings.aiProvider, undefined, freeOnly).then((models) => { if (active) { setAiModels(models); setModelMessage(`${models.length} model ${freeOnly ? 'kandidat gratis dengan input gambar' : 'tersedia'} dari ${providerLabels[settings.aiProvider]}. Ketersediaan gratis tetap mengikuti batas akun/provider.`); } }).catch((error) => { if (active) setModelMessage(error instanceof Error ? error.message : 'Model belum dapat dimuat.'); }).finally(() => { if (active) setLoadingModels(false); }); return () => { active = false; }; }, [settings?.aiProvider, freeOnly, aiStatus?.configured]);
  if (!settings) return <div className="mrp-section-card text-xs text-white/45">Loading persistent settings...</div>;
  const currentSettings: GlobalSettings = settings;
  const patch = (value: Partial<GlobalSettings>) => {
    if (value.ffmpegPath !== undefined || value.ffprobePath !== undefined) { setEngineCheck(null); setGpuInfo(null); }
    setSettings((current) => current ? { ...current, ...value } : current);
  };
  async function persistOutputDir(folder: string): Promise<void> {
    if (!folder.trim()) return;
    if (outputCommit.current) await outputCommit.current;
    const pending = (async () => {
      try {
        const saved = await window.magicRender.updateSettings({ outputDir: folder });
        setSettings((current) => current ? { ...current, outputDir: saved.outputDir } : current);
        if (project) {
          const updated = await window.magicRender.saveProject({ ...project, settings: { ...project.settings, outputDir: saved.outputDir } });
          onProjectChange(updated.project, { mode: 'replace', label: 'Save output folder' });
        }
        onMessage('Output Export Folder tersimpan.');
      } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menyimpan folder output.'); }
    })();
    outputCommit.current = pending;
    await pending;
    if (outputCommit.current === pending) outputCommit.current = null;
  }
  async function browse(kind: 'ffmpeg'|'ffprobe'|'upload'|'output'|'asset'): Promise<void> { try { const chosen = kind === 'ffmpeg' ? await window.magicRender.chooseSettingsFfmpeg() : kind === 'ffprobe' ? await window.magicRender.chooseSettingsFfprobe() : kind === 'upload' ? await window.magicRender.chooseSettingsUploadDirectory() : kind === 'asset' ? await window.magicRender.chooseSettingsAssetDirectory() : await window.magicRender.chooseSettingsOutputDirectory(); if (!chosen) return; if (kind === 'output') { await persistOutputDir(chosen); } else patch(kind === 'ffmpeg' ? { ffmpegPath: chosen } : kind === 'ffprobe' ? { ffprobePath: chosen } : kind === 'asset' ? { assetDir: chosen } : { uploadDir: chosen }); } catch (error) { onMessage(error instanceof Error ? error.message : 'Dialog folder/file gagal.'); } }
  async function save(): Promise<void> { setBusy(true); try { await outputCommit.current; const saved = await window.magicRender.updateSettings(currentSettings); setSettings(saved); onMessage('Semua pengaturan tersimpan. API key boleh kosong; kunci yang sudah tersimpan tidak berubah.'); if (project) { const next = { ...project, settings: { ...project.settings, outputDir: saved.outputDir, resolution: saved.resolution, cpuLoadPercent: saved.cpuLoadPercent, bitrateKbps: saved.bitrateKbps, bitrateMode: saved.bitrateMode, fps: saved.fps, renderPreset: saved.renderPreset }, youtubeSEO: { ...project.youtubeSEO, provider: saved.aiProvider, model: saved.aiModel } }; try { const stored = await window.magicRender.saveProject(next); onProjectChange(stored.project, { mode: 'replace', label: 'Save global settings' }); } catch (error) { onMessage(`Pengaturan global tersimpan, tetapi project gagal disimpan: ${error instanceof Error ? error.message : String(error)}`); } } void window.magicRender.testRenderEngine(saved.ffmpegPath, saved.ffprobePath).then(setEngineCheck).catch(() => setEngineCheck(null)); } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menyimpan settings.'); } finally { setBusy(false); } }
  async function saveAi(): Promise<void> { if (currentSettings.aiProvider !== 'ollama' && !apiKey.trim()) return; setBusy(true); try { const result = await window.magicRender.configureSettingsAi(currentSettings.aiProvider, currentSettings.aiModel, currentSettings.aiProvider === 'ollama' ? '' : apiKey); setApiKey(''); setSettings(result.settings); const message = `${result.modelChangeNote ? `${result.modelChangeNote} ` : ''}${result.validationError ? `API key dan model dikenali, tetapi generasi belum siap. ${result.validationError}` : currentSettings.aiProvider === 'ollama' ? 'Ollama lokal siap digunakan.' : 'API key tersimpan dan siap digunakan.'}`; setAiStatus({ provider: result.settings.aiProvider, model: result.settings.aiModel, configured: true, valid: !result.validationError, authenticated: true, checkedAt: new Date().toISOString(), message }); void window.magicRender.listSettingsAiModels(result.settings.aiProvider, undefined, freeOnly).then((models) => { setAiModels(models); setModelMessage(`${models.length} model tersedia.`); }).catch(() => undefined); if (project) { const updated = await window.magicRender.saveProject({ ...project, youtubeSEO: { ...project.youtubeSEO, provider: result.settings.aiProvider, model: result.settings.aiModel } }); onProjectChange(updated.project, { mode: 'replace', label: 'Apply AI settings' }); } onMessage(message); } catch (error) { const detail = error instanceof Error ? error.message : 'Konfigurasi AI gagal.'; setAiStatus({ provider: currentSettings.aiProvider, model: currentSettings.aiModel, configured: !!aiStatus?.configured, valid: false, checkedAt: new Date().toISOString(), message: detail }); onMessage(detail); } finally { setBusy(false); } }
  async function saveAiUnverified(): Promise<void> { if (!apiKey.trim()) return; setBusy(true); try { const result = await window.magicRender.configureSettingsAi(currentSettings.aiProvider, currentSettings.aiModel, apiKey, false); setApiKey(''); setSettings(result.settings); if (project) { const updated = await window.magicRender.saveProject({ ...project, youtubeSEO: { ...project.youtubeSEO, provider: result.settings.aiProvider, model: result.settings.aiModel } }); onProjectChange(updated.project, { mode: 'replace', label: 'Save AI settings' }); } const message = 'Kunci disimpan terenkripsi, tetapi belum tervalidasi. Periksa Billing/Limits lalu klik Check API Key sebelum Generate YouTube SEO.'; setAiStatus({ provider: result.settings.aiProvider, model: result.settings.aiModel, configured: true, valid: false, checkedAt: null, message }); onMessage(message); } catch (error) { onMessage(error instanceof Error ? error.message : 'Kunci gagal disimpan.'); } finally { setBusy(false); } }
  async function loadModels(): Promise<void> { if (currentSettings.aiProvider !== 'ollama' && !apiKey.trim() && !aiStatus?.configured) { setModelMessage('Masukkan API key lalu klik Simpan & Validasi, atau gunakan kunci yang sudah tersimpan untuk provider ini.'); return; } setLoadingModels(true); try { const models = await window.magicRender.listSettingsAiModels(currentSettings.aiProvider, apiKey.trim() || undefined, freeOnly); setAiModels(models); setModelMessage(`${models.length} model ${freeOnly ? 'kandidat gratis dengan input gambar' : 'tersedia'} dari ${providerLabels[currentSettings.aiProvider]}.`); } catch (error) { setModelMessage(error instanceof Error ? error.message : 'Daftar model gagal dimuat.'); } finally { setLoadingModels(false); } }
  async function checkAi(): Promise<void> { setBusy(true); try { const status = await window.magicRender.getSettingsAiStatus(currentSettings.aiProvider, currentSettings.aiModel, apiKey.trim() || undefined); setAiStatus(status); if (status.valid && status.configured && !apiKey.trim()) { const saved = await window.magicRender.updateSettings({ aiProvider: status.provider, aiModel: status.model }); setSettings(saved); if (project) { const updated = await window.magicRender.saveProject({ ...project, youtubeSEO: { ...project.youtubeSEO, provider: status.provider, model: status.model } }); onProjectChange(updated.project, { mode: 'replace', label: 'Apply AI model' }); } } onMessage(status.message); } catch (error) { onMessage(error instanceof Error ? error.message : 'Pengecekan AI gagal.'); } finally { setBusy(false); } }
  async function clearAi(): Promise<void> { try { await window.magicRender.clearSettingsAi(currentSettings.aiProvider); setApiKey(''); setAiStatus({ provider: currentSettings.aiProvider, model: currentSettings.aiModel, configured: false, valid: false, checkedAt: null, message: 'API key belum dikonfigurasi.' }); onMessage('API key dihapus dari secure storage.'); } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menghapus API key.'); } }
  function chooseProvider(value: AiProvider): void { setApiKey(''); patch({ aiProvider: value, aiModel: providerDefaults[value] }); }
  async function clearCache(): Promise<void> {
    setCleaningCache(true);
    try {
      const result = await window.magicRender.clearApplicationCache();
      onMessage(`Cache dibersihkan: ${result.jobsRemoved} pekerjaan dan ${result.filesRemoved} file sementara. Asset tersimpan tetap aman.${result.failures.length ? ` ${result.failures.length} file gagal dibersihkan.` : ''}`);
    } catch (error) {
      onMessage(error instanceof Error ? error.message : 'Pembersihan cache gagal.');
    } finally { setCleaningCache(false); }
  }
  async function checkEngine(): Promise<void> {
    setTestingEngine(true);
    try { setEngineCheck(await window.magicRender.testRenderEngine(currentSettings.ffmpegPath, currentSettings.ffprobePath)); }
    catch (error) { onMessage(error instanceof Error ? error.message : 'Uji FFmpeg gagal.'); }
    finally { setTestingEngine(false); }
  }
  async function checkGpu(): Promise<void> {
    setDetectingGpu(true);
    try { setGpuInfo(await window.magicRender.detectGpu(currentSettings.ffmpegPath)); }
    catch (error) { onMessage(error instanceof Error ? error.message : 'Deteksi GPU gagal.'); }
    finally { setDetectingGpu(false); }
  }

  return <><div className="mrp-settings-toolbar"><button type="button" disabled={cleaningCache} className="mrp-btn mrp-btn--danger" onClick={() => void clearCache()}>{cleaningCache ? 'Membersihkan...' : 'Bersihkan Cache'}</button></div><div className="mrp-settings-grid">
    <section className="mrp-settings-card"><header><span className="mrp-kicker">01 • Engine & Folders</span><h2>Path & Export</h2></header>
      <label>FFmpeg Path<div className="mrp-field-row"><input value={settings.ffmpegPath} onChange={(e) => patch({ ffmpegPath: e.target.value })}/><button className="mrp-btn" onClick={() => void browse('ffmpeg')}>Pilih</button></div></label>
      <label>FFprobe Path<div className="mrp-field-row"><input value={settings.ffprobePath} onChange={(e) => patch({ ffprobePath: e.target.value })}/><button className="mrp-btn" onClick={() => void browse('ffprobe')}>Pilih</button></div></label>
      <button type="button" className="mrp-btn" disabled={testingEngine} onClick={() => void checkEngine()}>{testingEngine ? 'Menguji FFmpeg...' : 'Uji FFmpeg & Monitor'}</button>
      <div className={`mrp-ai-status ${!engineCheck ? '' : engineCheck.ffmpegReady && engineCheck.ffprobeReady && engineCheck.progressReady ? 'is-valid' : 'is-error'}`} role="status">
        {engineCheck ? <>{engineCheck.message}{engineCheck.ffmpegVersion && <div className="mt-1 text-white/45">{engineCheck.ffmpegVersion}</div>}</> : 'Klik Uji FFmpeg & Monitor untuk memeriksa path saat ini.'}
      </div>
      <label>Default Project Save Folder<div className="mrp-field-row"><input value={settings.uploadDir} onChange={(e) => patch({ uploadDir: e.target.value })}/><button className="mrp-btn" onClick={() => void browse('upload')}>Pilih</button></div><small className="text-white/45">Lokasi awal saat membuat project baru.</small></label>
      <label>Folder Asset Library<div className="mrp-field-row"><input value={settings.assetDir} onChange={(e) => patch({ assetDir: e.target.value })}/><button className="mrp-btn" onClick={() => void browse('asset')}>Pilih</button></div><small className="text-white/45">Asset dan folder tracklist baru disalin ke lokasi ini saat ditambahkan. Asset lama tetap di lokasi sebelumnya. Klik Simpan Setting setelah memilih.</small></label>
      <label>Output Export Folder<div className="mrp-field-row"><input value={settings.outputDir} onChange={(e) => patch({ outputDir: e.target.value })} onBlur={(e) => { void persistOutputDir(e.target.value); }}/><button className="mrp-btn" onClick={() => void browse('output')}>Pilih</button></div><small className="text-white/45">Folder tersimpan saat dipilih atau setelah selesai mengetik.</small></label>
    </section>
    <section className="mrp-settings-card"><header><span className="mrp-kicker">02 • Render Engine</span><h2>Quality & Speed</h2></header>
      <label>GPU Mode / Perangkat Render<select value={settings.renderDevice} onChange={(e) => patch({ renderDevice: e.target.value as GlobalSettings['renderDevice'] })}><option value="cpu">CPU — libx264</option><option value="gpu">GPU — H.264 hardware encoder</option></select></label>
      <div className="mrp-field-row"><button type="button" className="mrp-btn" disabled={detectingGpu} onClick={() => void checkGpu()}>{detectingGpu ? 'Mendeteksi...' : 'Detect GPU'}</button><div className="text-[10px] text-white/65" role="status">{gpuInfo?.message ?? 'Klik Detect GPU untuk melihat nama VGA, VRAM dan encoder FFmpeg.'}</div></div>
      <label>Resolution<select value={settings.resolution} onChange={(e) => patch({ resolution: e.target.value as GlobalSettings['resolution'] })}><option value="720p">720p — 1280×720</option><option value="1080p">1080p — 1920×1080</option><option value="2K">2K — 2560×1440</option><option value="4K">4K — 3840×2160</option></select></label>
      <label>FPS Output<select value={settings.fps} onChange={(e) => patch({ fps: Number(e.target.value) as GlobalSettings['fps'] })}>{[24,25,30,50,60].map(fps => <option key={fps} value={fps}>{fps} fps</option>)}</select></label>
      <label>CPU Load Control<div className="mrp-slider-row"><input type="range" min="1" max="100" value={settings.cpuLoadPercent} onChange={(e) => patch({ cpuLoadPercent: Number(e.target.value) })}/><b>{settings.cpuLoadPercent}%</b></div><small className="text-white/45">Batas inti FFmpeg (perkiraan). Pilih 100% jika prioritasnya waktu render dan perangkat mampu; simpan pengaturan sebelum render.</small></label>
      <label>FFmpeg Render Preset<select value={(settings as GlobalSettings & { renderPreset?: string }).renderPreset ?? 'standard'} onChange={(e) => patch({ renderPreset: e.target.value } as Partial<GlobalSettings>)}><option value="fast">Cepat — H.264 veryfast</option><option value="standard">Standar — H.264 veryfast / kualitas CRF 20</option><option value="slow">Pelan — H.264 slow, kompresi lebih baik</option></select></label>
      <label>Video Bitrate (kbps)<input type="number" min="1" max="1000000" value={settings.bitrateKbps} onChange={(e) => patch({ bitrateKbps: Number(e.target.value) })}/></label>
      <label>Mode Bitrate<select value={settings.bitrateMode} onChange={(e) => patch({ bitrateMode: e.target.value as GlobalSettings['bitrateMode'] })}><option value="vbr">VBR — ukuran efisien, batas bitrate</option><option value="cbr">CBR — target bitrate tetap</option></select></label>
      <div className="mrp-inline-note">Audio playlist digabung terlebih dulu; video, overlay, sticker, dan intro dikode satu kali dengan H.264. Sticker normal memakai jalur komposisi langsung untuk mengurangi pemrosesan alfa per frame. GPU Mode memakai hardware encoder yang cocok bila driver dan FFmpeg mendukungnya. Filter komposisi masih dapat memakai CPU.</div>
      <button disabled={busy} className="mrp-btn mrp-btn--primary w-full" data-shortcut-save onClick={() => void save()}>Simpan Semua Settings</button>
    </section>
    <section className="mrp-settings-card"><header><span className="mrp-kicker">03 • AI Configuration</span><h2>Provider & Credentials</h2></header>
      <label>AI Provider<select value={settings.aiProvider} onChange={(e) => chooseProvider(e.target.value as AiProvider)}>{(Object.keys(providerLabels) as AiProvider[]).map((provider) => <option key={provider} value={provider}>{providerLabels[provider]}</option>)}</select></label>
      <label className="mrp-ai-free-filter"><input type="checkbox" checked={freeOnly} onChange={(e) => setFreeOnly(e.target.checked)}/><span>Filter daftar model gratis yang mendukung gambar</span></label>
      <label>Model AI tersedia<div className="mrp-field-row"><select aria-label="Pilih model AI" value={aiModels.includes(settings.aiModel) ? settings.aiModel : '__custom__'} onChange={(e) => { if (e.target.value !== '__custom__') { setAiStatus(null); patch({ aiModel: e.target.value }); } }}><option value="__custom__">{aiModels.length ? 'Model manual / pilihan belum ada di daftar' : 'Daftar model belum dimuat'}</option>{aiModels.map((model) => <option key={model} value={model}>{model}</option>)}</select><button type="button" className="mrp-btn" disabled={loadingModels} onClick={() => void loadModels()}>{loadingModels ? '...' : 'Muat Model'}</button></div><small className="text-white/45">{modelMessage}</small></label>
      <label>ID model terpilih / manual<input value={settings.aiModel} onChange={(e) => { setAiStatus(null); patch({ aiModel: e.target.value }); }}/><small className="text-white/45">OpenAI: gpt-4o-mini mendukung gambar untuk YouTube SEO dengan biaya lebih rendah. Ganti model lalu klik Check API Key.</small></label>
      {settings.aiProvider !== 'ollama' ? <label>API Key<input type="password" autoComplete="off" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder={aiStatus?.configured ? '•••••••••••• (kunci tersimpan)' : 'Masukkan API key'}/><small className="text-white/45">{aiStatus?.configured ? 'Kunci tersimpan secara terenkripsi. Masukkan kunci baru untuk mengganti; nilai asli tidak ditampilkan lagi.' : 'Kunci belum tersimpan untuk provider ini.'}</small></label> : <div className="mrp-provider-note">Instal Ollama, jalankan <code>ollama pull gemma3:4b</code>, lalu pastikan Ollama aktif di 127.0.0.1:11434. Proses AI memakai CPU/GPU komputer Anda.</div>}
      <div className="flex flex-wrap gap-2"><button disabled={busy || (settings.aiProvider !== 'ollama' && !apiKey.trim())} className="mrp-btn mrp-btn--primary" onClick={() => void saveAi()}>{settings.aiProvider === 'ollama' ? 'Uji & Simpan Model Lokal' : 'Simpan & Validasi'}</button>{settings.aiProvider !== 'ollama' && <button disabled={busy || !apiKey.trim()} className="mrp-btn" onClick={() => void saveAiUnverified()}>Simpan Key Saja</button>}<button disabled={busy} className="mrp-btn" onClick={() => void checkAi()}>{busy ? 'Memeriksa...' : settings.aiProvider === 'ollama' ? 'Uji Ollama' : 'Check API Key'}</button>{settings.aiProvider !== 'ollama' && <button disabled={busy} className="mrp-btn mrp-btn--danger" onClick={() => void clearAi()}>Hapus Key</button>}</div>
      <div className={`mrp-ai-status ${aiStatus?.valid ? 'is-valid' : aiStatus?.authenticated ? '' : aiStatus?.configured ? 'is-error' : ''}`}>{aiStatus?.message ?? 'Belum diperiksa.'}</div>
      <div className="mrp-provider-note">Filter hanya berlaku pada daftar model. ID model manual dan pilihan provider berbayar dapat dikenai biaya. Free tier mengikuti batas akun/provider; Ollama lokal tanpa API key memakai CPU/GPU komputer. Model harus menerima gambar untuk analisis keyframe.</div>
    </section>
  </div></>;
}
