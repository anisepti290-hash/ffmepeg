import type { JSX } from 'react';
import { useEffect, useState } from 'react';
import type { ProjectData } from '../../shared/domain/projectTypes';
import type { IntroLibraryItem } from '../../shared/domain/introTypes';

export function IntroPanel({ project, onProjectChange }: { project: ProjectData; onProjectChange: (project: ProjectData) => void }): JSX.Element {
  const [library, setLibrary] = useState<IntroLibraryItem[]>([]);
  const [message, setMessage] = useState('');
  async function refresh(): Promise<void> {
    try { setLibrary(await window.magicRender.getIntroLibrary()); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal memuat Intro Library.'); }
  }
  useEffect(() => { void refresh(); }, [project.projectId]);
  async function importIntro(): Promise<void> {
    try {
      const result = await window.magicRender.importIntro(project);
      if (result) { onProjectChange(result.project); await refresh(); setMessage('Intro media berhasil diimpor dan diaktifkan.'); }
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal import Intro.'); }
  }
  async function toggle(enabled: boolean): Promise<void> {
    try {
      const result = await window.magicRender.setIntro(project, enabled, project.intro.path, project.intro.fallbackFadeInSec);
      onProjectChange(result.project);
      setMessage(enabled ? 'Intro aktif. Fade fallback nonaktif.' : 'Intro nonaktif. Fade fallback aktif jika Fade-In Media Utama 0.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal memperbarui Intro.'); }
  }
  async function select(assetId: string): Promise<void> {
    try { const result = await window.magicRender.selectIntro(project, assetId); onProjectChange(result.project); setMessage('Intro dipilih dan diaktifkan.'); }
    catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal memilih Intro.'); }
  }
  function patch(values: Partial<ProjectData['intro']>): void {
    onProjectChange({ ...project, intro: { ...project.intro, ...values } });
  }
  const disabled = project.intro.enabled;
  const isBokeh = project.intro.fallbackStyle === 'blur';
  return <section className="mt-4 rounded-xl border border-cyber-violet/20 bg-black/20 p-4">
    <header className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><h3 className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-violet">Intro System</h3><p className="mt-1 text-[10px] text-white/45">Pilih video intro atau gunakan fade pembuka pada media utama.</p></div><div className="flex gap-2"><button type="button" onClick={() => void importIntro()} className="rounded border border-cyber-cyan/30 px-2 py-1 text-[10px] text-cyber-cyan">Upload Intro</button><button type="button" onClick={() => void refresh()} className="rounded border border-white/10 px-2 py-1 text-[10px]">Refresh</button></div></header>
    <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
      <div className="min-w-0 rounded-lg border border-white/10 bg-black/15 p-3"><h4 className="text-[10px] font-bold uppercase tracking-widest text-white/60">01 • Media Intro</h4><label className="mt-3 flex items-center gap-2 text-xs"><input type="checkbox" checked={project.intro.enabled} disabled={!project.intro.path} onChange={(e) => void toggle(e.target.checked)}/>Aktifkan intro</label><div className="mt-3 max-h-60 space-y-2 overflow-y-auto">{library.length === 0 ? <p className="text-xs text-white/35">Belum ada intro. Import atau tambah aset Intro di Asset Library.</p> : library.map((item) => <button type="button" key={item.assetId} onClick={() => void select(item.assetId)} className={`w-full rounded-lg border px-3 py-2 text-left text-xs ${project.intro.path === item.path ? 'border-cyber-cyan/50 bg-cyber-cyan/10' : 'border-white/10'}`}><span className="block truncate font-semibold">{item.name}</span><small className="block truncate text-white/40">{item.path}</small></button>)}</div></div>
      <div className="min-w-0 rounded-lg border border-white/10 bg-black/15 p-3"><h4 className="text-[10px] font-bold uppercase tracking-widest text-white/60">02 • Fade tanpa Intro</h4><p className="mt-1 text-[10px] text-white/40">Berlaku saat Intro nonaktif dan Fade-In Media Utama bernilai 0. Bokeh mengikuti titik cahaya yang benar-benar terlihat pada media utama.</p><div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <label className="min-w-0 text-xs">Gaya<select disabled={disabled} className="mt-1 w-full rounded bg-black/40 p-2 disabled:opacity-35" value={project.intro.fallbackStyle ?? 'dark'} onChange={(e) => patch({ fallbackStyle: e.target.value as 'dark' | 'blur' })}><option value="dark">Fade gelap</option><option value="blur">Fade bokeh</option></select></label>
        <label className="min-w-0 text-xs">Durasi: {project.intro.fallbackFadeInSec.toFixed(1)} detik<input disabled={disabled} className="mt-2 w-full disabled:opacity-35" type="range" min="0" max="30" step="0.1" value={project.intro.fallbackFadeInSec} onChange={(e) => patch({ fallbackFadeInSec: Number(e.target.value) })}/></label>
        {isBokeh && <><label className="min-w-0 text-xs">Defokus bokeh: {project.intro.fallbackBlur ?? 12}<input disabled={disabled} className="mt-2 w-full disabled:opacity-35" type="range" min="0" max="30" step="1" value={project.intro.fallbackBlur ?? 12} onChange={(e) => patch({ fallbackBlur: Number(e.target.value) })}/></label><label className="min-w-0 text-xs">Kecerahan awal: {Math.round((project.intro.fallbackBrightness ?? -0.25)*100)}%<input disabled={disabled} className="mt-2 w-full disabled:opacity-35" type="range" min="-0.7" max="0.7" step="0.01" value={project.intro.fallbackBrightness ?? -0.25} onChange={(e) => patch({ fallbackBrightness: Number(e.target.value) })}/></label></>}
      </div>{disabled && <p className="mt-3 text-[10px] text-cyber-cyan/70">Fade fallback nonaktif selama Intro aktif. Fade-In Media Utama dapat diatur terpisah.</p>}</div>
    </div>
    {message && <div className="mt-3 rounded border border-cyber-cyan/15 p-2 text-[10px] text-cyber-cyan/80">{message}</div>}
  </section>;
}
