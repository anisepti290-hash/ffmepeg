import type { JSX } from 'react';
import { useState } from 'react';
import type { ProjectData } from '../../shared/domain/projectTypes';
import type { PlaylistTrack } from '../../shared/domain/playlistTypes';
import { orderedPlaylistTracks } from '../../shared/domain/playlistOrder';

type Props = { project: ProjectData; onProjectChange: (project: ProjectData) => void };

function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function PlaylistPanel({ project, onProjectChange }: Props): JSX.Element {
  const storedTracks = project.playlistTracks?.length ? project.playlistTracks : project.playlist.files.map((filePath, order): PlaylistTrack => ({ path: filePath, durationSeconds: null, order }));
  const tracks = orderedPlaylistTracks(storedTracks, project.playlist.playbackOrder);
  const totalDuration = tracks.reduce((seconds, track) => seconds + (track.durationSeconds ?? 0), 0);
  const [message, setMessage] = useState('Ready');
  const [cleaning, setCleaning] = useState(false);
  const [busy, setBusy] = useState(false);

  async function importTracks(): Promise<void> {
    setBusy(true);
    try {
      const next = await window.magicRender.importPlaylist(project);
      if (!next) return;
      onProjectChange(next);
      setMessage('Playlist berhasil diimpor dan durasi setiap MP3 telah diprobe.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal import playlist.'); }
    finally { setBusy(false); }
  }
  async function cleanMetadata(): Promise<void> {
    setCleaning(true);
    setMessage('Menghapus metadata dari salinan MP3. Audio asli tidak diubah.');
    try {
      onProjectChange(await window.magicRender.resetPlaylistMetadata(project));
      setMessage('Metadata seluruh MP3 playlist dihapus dari salinan tanpa mengubah kualitas audio.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membersihkan metadata MP3.'); }
    finally { setCleaning(false); }
  }

  async function move(index: number, direction: -1 | 1): Promise<void> {
    const target = index + direction;
    if (target < 0 || target >= tracks.length) return;
    setBusy(true);
    try { onProjectChange(await window.magicRender.reorderPlaylist(project, index, target)); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal reorder playlist.'); }
    finally { setBusy(false); }
  }

  async function remove(index: number): Promise<void> {
    setBusy(true);
    try { onProjectChange(await window.magicRender.removePlaylistTrack(project, index)); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menghapus track.'); }
    finally { setBusy(false); }
  }

  async function setShuffle(value: boolean): Promise<void> {
    setBusy(true);
    try { onProjectChange(await window.magicRender.setPlaylistShuffle(project, value)); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal mengubah shuffle.'); }
    finally { setBusy(false); }
  }

  return <div className="mt-4 rounded-xl border border-cyber-cyan/20 bg-black/20 p-4">
    <div className="mb-3 flex items-center justify-between">
      <div><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-cyan">Playlist & Audio Engine</div><div className="mt-1 text-[10px] text-white/40">MP3 • reorder • shuffle • playlist duration</div></div>
      <button disabled={busy || cleaning} className="rounded border border-cyber-cyan/30 px-3 py-1 text-[10px] disabled:opacity-40" onClick={() => void importTracks()}>+ Import MP3</button>
    </div>
    <div className="mb-3 grid grid-cols-2 gap-2 text-xs">
      <div className="rounded-lg border border-white/5 p-3"><div className="text-[10px] uppercase tracking-widest text-white/35">Tracks</div><div className="mt-1 text-lg font-bold text-white">{tracks.length}</div></div>
      <div className="rounded-lg border border-white/5 p-3"><div className="text-[10px] uppercase tracking-widest text-white/35">Total Duration</div><div className="mt-1 text-lg font-bold text-cyber-cyan">{formatDuration(totalDuration)}</div></div>
    </div>
    {tracks.length > 0 && <button type="button" disabled={cleaning || busy} className="mb-3 w-full rounded-lg border border-cyber-cyan/30 px-3 py-2 text-xs text-cyber-cyan disabled:opacity-40" onClick={() => void cleanMetadata()}>{cleaning ? 'Membersihkan metadata…' : 'Reset semua metadata MP3'}</button>}
    <button type="button" disabled={busy || cleaning} className="mb-3 w-full rounded-lg border border-cyber-violet/30 px-3 py-2 text-xs text-cyber-violet disabled:opacity-40" onClick={() => void setShuffle(true)}>Shuffle</button><div className="mb-3 text-[10px] text-white/40">Urutan yang terlihat adalah urutan audio saat preview, render, dan timestamp. Menggeser lagu mengunci urutan manual.</div>
    <div className="space-y-2">
      {tracks.length === 0 ? <div className="rounded-lg border border-dashed border-white/10 p-4 text-xs text-white/35">Belum ada MP3 di playlist.</div> : tracks.map((track, index) => <div key={`${track.path}-${index}`} className="rounded-lg border border-white/5 p-3"><div className="flex items-center gap-2"><div className="min-w-0 flex-1"><div className="truncate text-xs font-semibold">{index + 1}. {track.path.split(/[\\/]/).pop()}</div><div className="mt-1 text-[10px] text-cyber-cyan/70">{track.durationSeconds == null ? 'duration unknown' : formatDuration(track.durationSeconds)}</div></div><button className="text-[10px] text-white/50 disabled:opacity-30" disabled={busy || cleaning || index === 0} onClick={() => void move(index, -1)}>↑</button><button className="text-[10px] text-white/50 disabled:opacity-30" disabled={busy || cleaning || index === tracks.length - 1} onClick={() => void move(index, 1)}>↓</button><button className="text-[10px] text-cyber-fuchsia disabled:opacity-30" disabled={busy || cleaning} onClick={() => void remove(index)}>Remove</button></div></div>)}
    </div>
    {tracks.length > 0 && <div className="mt-3 rounded-lg border border-cyber-violet/20 p-3"><div className="text-[10px] font-bold uppercase tracking-widest text-cyber-violet">Render Duration</div><div className="mt-1 text-[10px] leading-relaxed text-white/45">Total durasi playlist menjadi durasi content video. Jika intro aktif, intro ditambahkan di depan content.</div></div>}
    <div className="mt-3 text-[10px] text-white/35">{message}</div>
  </div>;
}
