import type { JSX } from 'react';
import { useEffect, useRef, useState } from 'react';
import type { ProjectData } from '../../shared/domain/projectTypes';
import type { HistoryOptions } from '../context';
import type { LockedAsset } from '../../shared/domain/lockedAssetTypes';
import { defaultStickerConfig, type ProjectSticker, type StickerMediaType, type StickerScheduleMode, type StickerBackgroundRemoval, type StickerBlendMode } from '../../shared/domain/stickerTypes';
import { PreviewEyeIcon } from './PreviewEyeIcon';
import { PreviewLockIcon } from './PreviewLockIcon';
import { DeleteLayerIcon, ChevronIcon, ResetLayerIcon } from './LayerActionIcons';
import { stickerAssetPreset } from '../../shared/domain/assetPreset';

const mediaKind = (extension: string): StickerMediaType => /\.(mp4|mov|mkv|webm|avi)$/i.test(extension) ? 'video' : /\.gif$/i.test(extension) ? 'gif' : 'image';

export function secondsFromTimestamp(value: string): number {
  if (/^\d+(?:\.\d+)?$/.test(value)) return Number(value);
  const parts = value.split(':').map(Number);
  return parts.length === 2 && parts.every(Number.isFinite) && parts[0]! >= 0 && parts[1]! >= 0 && parts[1]! < 60 ? parts[0]! * 60 + parts[1]! : 30;
}

function StickerScheduleEditor({ stickerId, value, onChange }: { stickerId: string; value: string; onChange: (seconds: number) => void }): JSX.Element {
  const current = Math.max(0, Math.floor(secondsFromTimestamp(value)));
  const [minuteText, setMinuteText] = useState(String(Math.floor(current / 60)));
  const [secondText, setSecondText] = useState(String(current % 60));
  const [timeText, setTimeText] = useState(`${String(Math.floor(current / 60)).padStart(2, '0')}:${String(current % 60).padStart(2, '0')}`);
  useEffect(() => {
    const seconds = Math.max(0, Math.floor(secondsFromTimestamp(value)));
    setMinuteText(String(Math.floor(seconds / 60)));
    setSecondText(String(seconds % 60));
    setTimeText(`${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`);
  }, [stickerId, value]);
  const restore = () => { setMinuteText(String(Math.floor(current / 60))); setSecondText(String(current % 60)); setTimeText(`${String(Math.floor(current / 60)).padStart(2, '0')}:${String(current % 60).padStart(2, '0')}`); };
  const commit = (minute: string, second: string) => {
    const m = Number(minute), s = Number(second);
    if (minute.trim() && second.trim() && Number.isInteger(m) && Number.isInteger(s) && m >= 0 && s >= 0 && s < 60) onChange(m * 60 + s);
    else restore();
  };
  const commitTime = () => {
    const match = /^(\d+):([0-5]?\d)$/.exec(timeText.trim());
    if (match) onChange(Number(match[1]) * 60 + Number(match[2])); else restore();
  };
  return <div className="col-span-2 rounded-lg border border-cyber-cyan/15 bg-black/20 p-3">
    <div className="grid grid-cols-3 gap-2">
      <label>Menit<input className="mrp-sticker-time-input" type="number" min="0" step="1" value={minuteText} onChange={(e) => setMinuteText(e.target.value)} onBlur={() => commit(minuteText, secondText)} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} /></label>
      <label>Detik<input className="mrp-sticker-time-input" type="number" min="0" max="59" step="1" value={secondText} onChange={(e) => setSecondText(e.target.value)} onBlur={() => commit(minuteText, secondText)} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} /></label>
      <label>Waktu (mm:ss)<input className="mrp-sticker-time-input" type="text" inputMode="numeric" value={timeText} onChange={(e) => setTimeText(e.target.value)} onBlur={commitTime} onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }} /></label>
    </div>
    <input className="mt-3 w-full" aria-label="Waktu kemunculan sticker" type="range" min="0" max={Math.max(3600, current)} step="1" value={current} onChange={(e) => onChange(Number(e.target.value))} />
    <div className="mt-1 text-[9px] text-white/40">Tulis menit dan detik, lalu klik di luar kolom atau tekan Enter.</div>
  </div>;
}

export function StickerPanel({ project, onProjectChange, hiddenLayers, onToggleLayer }: { project: ProjectData; onProjectChange: (project: ProjectData, options?: HistoryOptions) => void; hiddenLayers: Set<string>; onToggleLayer: (key: string) => void }): JSX.Element {
  const latest = useRef(project);
  latest.current = project;
  const [type, setType] = useState<StickerMediaType>(() => {
    const saved = sessionStorage.getItem('mrp-sticker-media-type');
    return saved === 'video' || saved === 'gif' ? saved : 'image';
  });
  const [library, setLibrary] = useState<LockedAsset[]>([]);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  function toggleCollapsed(id: string): void { setCollapsed((current) => { const next = new Set(current); if (next.has(id)) next.delete(id); else next.add(id); return next; }); }
  const stickers = project.stickerSubscribes?.length ? project.stickerSubscribes : (project.stickerSubscribe ? [project.stickerSubscribe] : []);
  useEffect(() => { void window.magicRender.listLockedAssets().then((items) => setLibrary(items.filter((item) => item.menu === 'stickerSubscribe'))).catch(() => setLibrary([])); }, []);
  useEffect(() => { sessionStorage.setItem('mrp-sticker-media-type', type); }, [type]);
  async function add(filePath?: string, selectedType = type, asset?: LockedAsset): Promise<void> { try { const result = await window.magicRender.addSticker(project, selectedType, filePath); if (result) { const saved = result.project.stickerSubscribes ?? [];
    const next = saved.map((item, index) => index === saved.length - 1 && asset ? { ...item, config: { ...item.config, ...stickerAssetPreset(asset), schedule: item.config.schedule, durationSec: item.config.durationSec, fade: item.config.fade } } : item);
    onProjectChange({ ...result.project, stickerSubscribes: next, stickerSubscribe: next[0] ?? null }); }
  } catch (error) { void window.magicRender.logActivity('ERROR', 'Sticker import gagal.', error instanceof Error ? error.message : String(error)); } }
  async function update(sticker: ProjectSticker): Promise<void> { try { onProjectChange((await window.magicRender.updateSticker(project, sticker)).project); } catch (error) { void window.magicRender.logActivity('ERROR', 'Sticker update gagal.', error instanceof Error ? error.message : String(error)); } }
  async function remove(id: string): Promise<void> { try { onProjectChange((await window.magicRender.removeSticker(project, id)).project); } catch (error) { void window.magicRender.logActivity('ERROR', 'Sticker remove gagal.', error instanceof Error ? error.message : String(error)); } }
  function getDraft(sticker: ProjectSticker): ProjectSticker { return sticker; }
  function patch(sticker: ProjectSticker, patchValue: Partial<ProjectSticker['config']>): void {
    const base = latest.current;
    const current = base.stickerSubscribes?.length ? base.stickerSubscribes : base.stickerSubscribe ? [base.stickerSubscribe] : [];
    const updated = current.map((item) => item.id === sticker.id ? { ...item, config: { ...item.config, ...patchValue } } : item);
    // The panel unmounts when menus change. Keep edits in project state immediately.
    const result = { ...base, stickerSubscribes: updated, stickerSubscribe: updated[0] ?? null };
    latest.current = result;
    onProjectChange(result, { mode: 'coalesce', label: 'Sticker controls' });
    if (patchValue.schedule) window.dispatchEvent(new Event('mrp:sticker-schedule-changed'));
  }
  function commit(): void { onProjectChange(latest.current, { mode: 'commit-coalesced', label: 'Sticker controls' }); }
  function toggleLock(id: string): void { const next = stickers.map((item) => item.id === id ? { ...item, locked: !item.locked } : item); onProjectChange({ ...project, stickerSubscribes: next, stickerSubscribe: next[0] ?? null }); }
  function setTimestamp(sticker: ProjectSticker, seconds: number): void { if (Number.isInteger(seconds) && seconds >= 0) patch(sticker, { schedule: { ...getDraft(sticker).config.schedule, timestamps: [String(seconds)] } }); }
  function reset(sticker: ProjectSticker): void { patch(sticker, { ...defaultStickerConfig(), durationSec: sticker.type === 'video' ? sticker.config.durationSec : 3 }); }
  return <div className="mt-4 rounded-xl border border-cyber-violet/20 bg-black/20 p-4" onPointerUp={commit} onKeyUp={commit} onBlur={commit}>
    <div className="mb-4"><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-violet/80">Sticker Subscribe</div><div className="mt-1 text-[10px] text-white/40">Semua perubahan langsung tersinkron dengan Canvas Preview. Drag/resize/rotate juga tersedia di canvas.</div><div className="mrp-sticker-toolbar"><label htmlFor="sticker-media-type">Jenis media</label><select id="sticker-media-type" value={type} onChange={(e) => setType(e.target.value as StickerMediaType)} className="mrp-dark-select"><option value="image">Gambar</option><option value="video">Video</option><option value="gif">GIF</option></select><button type="button" onClick={() => void add()} className="mrp-btn mrp-btn--primary"><span aria-hidden="true">＋</span> Import Sticker</button></div></div>
    <div className="mb-3 rounded-lg border border-white/5 p-3"><div className="mb-2 text-[10px] uppercase tracking-widest text-white/45">Sticker Subscribe Library</div>{library.length === 0 ? <div className="text-[10px] text-white/30">Belum ada sticker tersimpan.</div> : <div className="grid grid-cols-2 gap-2">{library.map((item) => <button key={item.assetId} type="button" className="truncate rounded border border-white/10 px-2 py-2 text-left text-[10px] hover:border-cyber-cyan/30" onClick={() => void add(item.path, mediaKind(item.metadata.extension), item)}>{item.metadata.originalName}</button>)}</div>}</div>
    {stickers.length === 0 ? <div className="rounded-lg border border-dashed border-white/10 p-4 text-xs text-white/35">Sticker Subscribe opsional. Tidak ada sticker = tidak ada layer sticker.</div> : <div className="space-y-3">{stickers.map((sticker, index) => { const draft = getDraft(sticker); const config = draft.config; const mode = config.backgroundRemoval; return <div key={sticker.id} className="rounded-lg border border-white/5 bg-black/10 p-3">
      <div className="flex items-center justify-between gap-2"><span className="truncate text-xs font-semibold">Sticker #{index + 1} • {sticker.type}</span><div className="flex items-center gap-3">{JSON.stringify({ ...config, durationSec: 3 }) !== JSON.stringify(defaultStickerConfig()) && <button type="button" aria-label="Reset pengaturan sticker" title="Reset pengaturan sticker" onClick={() => reset(sticker)}><ResetLayerIcon /></button>}<button type="button" aria-label={hiddenLayers.has(`sticker:${sticker.id}`) ? 'Tampilkan sticker' : 'Sembunyikan sticker'} title={hiddenLayers.has(`sticker:${sticker.id}`) ? 'Tampilkan di preview' : 'Sembunyikan dari preview'} onClick={() => onToggleLayer(`sticker:${sticker.id}`)}><PreviewEyeIcon hidden={hiddenLayers.has(`sticker:${sticker.id}`)} /></button><button type="button" aria-pressed={!!sticker.locked} aria-label={sticker.locked ? "Buka kunci sticker" : "Kunci sticker"} title={sticker.locked ? "Buka kunci posisi di preview" : "Kunci posisi di preview"} onClick={() => toggleLock(sticker.id)}><PreviewLockIcon locked={!!sticker.locked} /></button><button type="button" aria-label="Hapus sticker" title="Hapus sticker" onClick={() => void remove(sticker.id)} className="text-cyber-fuchsia"><DeleteLayerIcon /></button><button type="button" aria-label={collapsed.has(sticker.id) ? "Tampilkan setting sticker" : "Sembunyikan setting sticker"} aria-expanded={!collapsed.has(sticker.id)} title="Tampilkan/sembunyikan setting" onClick={() => toggleCollapsed(sticker.id)}><ChevronIcon expanded={!collapsed.has(sticker.id)} /></button></div></div><div className="mt-1 truncate text-[9px] text-white/35">{sticker.path}</div>
      {!collapsed.has(sticker.id) && <><div className="mt-3 grid grid-cols-2 gap-2 text-[10px]">
        <label className="flex items-center gap-2"><input type="checkbox" checked={config.audioMuted} onChange={(e) => patch(sticker, { audioMuted: e.target.checked })}/> Mute Audio</label>
        <label>Opacity<input className="mt-1 w-full" type="range" min="0" max="1" step="0.01" value={config.opacity} onChange={(e) => patch(sticker, { opacity: Number(e.target.value) })}/><span className="text-white/55">{Math.round(config.opacity*100)}%</span></label>
        <label>Blend<select className="mrp-dark-select" value={config.blendMode} onChange={(e) => patch(sticker, { blendMode: e.target.value as StickerBlendMode })}><option value="normal">Normal</option><option value="multiply">Multiply</option><option value="screen">Screen</option><option value="overlay">Overlay</option></select></label>
        <label>Speed<input className="mt-1 w-full rounded bg-black p-2 text-white" type="number" min="0.1" max="8" step="0.1" value={config.speed ?? 1} onChange={(e) => patch(sticker, { speed: Number(e.target.value) })}/></label>
        <div className="col-span-2 rounded border border-cyber-cyan/10 bg-black/30 p-2 text-[10px] text-white/50">Sticker mengikuti jadwal render pada timeline video final (intro termasuk). Mode edit canvas dapat menampilkannya di luar jadwal. Durasi sekali tampil: <b className="text-cyber-cyan">{config.durationSec.toFixed(2)} detik</b></div>
        <label>Background Keying<select className="mrp-dark-select" value={mode} onChange={(e) => { const value = e.target.value as StickerBackgroundRemoval; patch(sticker, { backgroundRemoval: value, chromaKey: { ...config.chromaKey, enabled: value === 'chroma' }, colorKey: { ...config.colorKey, enabled: value === 'color' } }); }}><option value="none">None</option><option value="chroma">Chroma Key</option><option value="color">Color Key</option></select></label>
        <label>Scale<input className="mt-1 w-full rounded bg-black p-2 text-white" type="number" min="0.1" max="20" step="0.1" value={config.scale} onChange={(e) => patch(sticker, { scale: Number(e.target.value) })}/></label>
        <label>Fade In<input className="mt-1 w-full" type="range" min="0" max="30" step="0.1" value={config.fade.fadeInSec} onChange={(e) => patch(sticker, { fade: { ...config.fade, fadeInSec: Number(e.target.value) } })}/></label>
        <label>Fade Out<input className="mt-1 w-full" type="range" min="0" max="30" step="0.1" value={config.fade.fadeOutSec} onChange={(e) => patch(sticker, { fade: { ...config.fade, fadeOutSec: Number(e.target.value) } })}/></label>
        <label>Durasi sekali tampil (detik)<input className="mt-1 w-full rounded bg-black p-2 text-white" type="number" min="0.1" max="3600" step="0.1" value={config.durationSec} onChange={(e) => { const durationSec = Number(e.target.value); if (durationSec > 0) patch(sticker, { durationSec }); }}/></label>
        <label>Schedule<select className="mrp-dark-select" value={config.schedule.mode} onChange={(e) => { const mode = e.target.value as StickerScheduleMode; patch(sticker, { schedule: { ...config.schedule, mode, iterativeCount: mode === 'iterative' ? (config.schedule.iterativeCount ?? 3) : config.schedule.iterativeCount, timestamps: mode === 'timestamp' && !config.schedule.timestamps.length ? ['30'] : config.schedule.timestamps } }); }}><option value="iterative">Berulang setiap N menit</option><option value="timestamp">Menit / Timestamp tertentu</option><option value="full-duration">Sepanjang durasi video</option></select></label>
        {config.schedule.mode === 'iterative' && <label>Interval berulang (menit)<input className="mt-1 w-full rounded bg-black p-2 text-white" type="number" min="1" max="100" value={config.schedule.iterativeCount ?? 3} onChange={(e) => patch(sticker, { schedule: { ...config.schedule, iterativeCount: Number(e.target.value) } })}/></label>}
        {config.schedule.mode === 'iterative' && <div className="col-span-2 text-[10px] text-white/50">Mulai pada 00:00, lalu tampil lagi setiap {config.schedule.iterativeCount ?? 3} menit sampai video selesai.</div>}
        {config.schedule.mode === 'timestamp' && <StickerScheduleEditor stickerId={sticker.id} value={config.schedule.timestamps[0] ?? '30'} onChange={(seconds) => setTimestamp(sticker, seconds)} />}
      </div>
      {mode === 'chroma' && <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]"><label>Chroma Key Level<input className="w-full" type="range" min="0" max="1" step="0.01" value={config.chromaKey.similarity} onChange={(e) => patch(sticker, { chromaKey: { ...config.chromaKey, enabled: true, similarity: Number(e.target.value) } })}/></label><label>Key Blend<input className="w-full" type="range" min="0" max="1" step="0.01" value={config.chromaKey.blend} onChange={(e) => patch(sticker, { chromaKey: { ...config.chromaKey, enabled: true, blend: Number(e.target.value) } })}/></label></div>}
      {mode === 'color' && <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]"><label>Color Key Level<input className="w-full" type="range" min="0" max="1" step="0.01" value={config.colorKey.similarity} onChange={(e) => patch(sticker, { colorKey: { ...config.colorKey, enabled: true, similarity: Number(e.target.value) } })}/></label><label>Key Blend<input className="w-full" type="range" min="0" max="1" step="0.01" value={config.colorKey.blend} onChange={(e) => patch(sticker, { colorKey: { ...config.colorKey, enabled: true, blend: Number(e.target.value) } })}/></label></div>}
      </>}
    </div>; })}</div>}
  </div>;
}
