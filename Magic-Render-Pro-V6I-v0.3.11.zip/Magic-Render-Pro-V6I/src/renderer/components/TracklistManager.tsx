import { useEffect, useState, type JSX } from 'react';
import type { TracklistFolder } from '../../shared/domain/bulkTypes';

export function TracklistManager({onMessage}:{onMessage:(message:string)=>void}):JSX.Element {
  const [folders,setFolders]=useState<TracklistFolder[]>([]);
  const [busy,setBusy]=useState(false);
  useEffect(()=>{ void window.magicRender.listTracklists().then(setFolders).catch((error)=>onMessage(error instanceof Error?error.message:String(error))); },[]);
  async function add():Promise<void> { setBusy(true); try { const added=await window.magicRender.addTracklist(); if (added) { setFolders(await window.magicRender.listTracklists()); onMessage(`Tracklist ${added.name} berisi ${added.mp3Paths.length} MP3.`); } } catch(error) { onMessage(error instanceof Error?error.message:String(error)); } finally { setBusy(false); } }
  async function remove(id:string):Promise<void> { try { await window.magicRender.removeTracklist(id); setFolders((previous)=>previous.filter((folder)=>folder.id!==id)); } catch(error) { onMessage(error instanceof Error?error.message:String(error)); } }
  return <article className="mrp-asset-card mrp-tracklist-manager"><header><div><span className="mrp-kicker">Tracklist Manager</span><h2>Folder MP3 untuk Bulk Render</h2></div><button type="button" className="mrp-btn mrp-btn--primary" disabled={busy} onClick={()=>void add()}>＋ Tambah Folder</button></header><div className="mrp-asset-list">{folders.length===0?<div className="mrp-inline-note">Belum ada folder tracklist.</div>:folders.map((folder)=><div key={folder.id} className="mrp-tracklist-row"><div><strong>▰ {folder.name}</strong><small>{folder.mp3Paths.length} MP3 · {folder.path}</small><details><summary>Lihat lagu</summary><ul>{folder.mp3Paths.map((file)=><li key={file}>{file.split(/[\\/]/).at(-1)}</li>)}</ul></details></div><button type="button" className="mrp-btn mrp-btn--danger" aria-label={`Hapus tracklist ${folder.name}`} onClick={()=>void remove(folder.id)}>×</button></div>)}</div></article>;
}
