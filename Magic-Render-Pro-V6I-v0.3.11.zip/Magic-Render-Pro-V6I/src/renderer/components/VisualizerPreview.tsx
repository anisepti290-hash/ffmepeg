import { useEffect, useRef, type JSX } from 'react';
import type { VisualizerEffect } from '../../shared/domain/visualizerTypes';
import { frequencyFraction, visualizerColors } from '../../shared/domain/visualizerPalette';

const waveKinds = new Set(['wave', 'mirror', 'waveLine', 'wavePoints', 'wavePeak']);
const spectrumKinds = new Set(['spectrum', 'spectrumFire', 'spectrumCool', 'spectrumScroll', 'spectrumViridis', 'spectrumMagma']);

type Props = { items: VisualizerEffect[]; audio: HTMLAudioElement | null; playing: boolean; onError?: (message: string) => void };
// A media element can be connected to a MediaElementAudioSourceNode only once.
// Retain its audio routing while tracks change, effects are removed, or React
// replays an effect in development. The element itself is replaced on playlist reset.
type AudioRouting = { context: AudioContext; analyser: AnalyserNode; users: number; closing?: number };
const analysers = new WeakMap<HTMLAudioElement, AudioRouting>();
export function VisualizerPreview({ items, audio, playing, onError }: Props): JSX.Element {
  const canvases = useRef(new Map<string, HTMLCanvasElement>());
  const effects = useRef(items);
  const playingRef = useRef(playing);
  const contextRef = useRef<AudioContext | null>(null);
  const levelsRef = useRef(new Map<string, number[]>());
  const waveLevelsRef = useRef(new Map<string, Float32Array>());
  effects.current = items;
  playingRef.current = playing;
  useEffect(() => {
    const element = audio;
    if (!element) return;
    let frame = 0;
    let active = true;
    try {
      let routing = analysers.get(element);
      if (!routing) {
        const context = new AudioContext();
        const analyser = context.createAnalyser(); analyser.fftSize = 2048; analyser.smoothingTimeConstant = 0;
        const source = context.createMediaElementSource(element);
        source.connect(analyser); analyser.connect(context.destination);
        routing = { context, analyser, users: 0 };
        analysers.set(element, routing);
      }
      if (routing.closing !== undefined) window.clearTimeout(routing.closing);
      routing.closing = undefined;
      routing.users++;
      const { context, analyser } = routing;
      contextRef.current = context;
      if (playing) void context.resume().catch(() => undefined);
      const frequencies = new Uint8Array(analyser.frequencyBinCount);
      const waveform = new Uint8Array(analyser.fftSize);
      let lastPaint = 0;
      const paint = (now: number) => {
        if (!active) return;
        if (now - lastPaint < (playingRef.current ? 32 : 120)) { frame = requestAnimationFrame(paint); return; }
        lastPaint = now;
        analyser.getByteFrequencyData(frequencies); analyser.getByteTimeDomainData(waveform);
        for (const visual of effects.current) {
          const canvas = canvases.current.get(visual.id), ctx = canvas?.getContext('2d');
          if (!canvas || !ctx) continue;
          const w = canvas.width, h = canvas.height;
          const bands = visual.density ?? 64;
          let levels = levelsRef.current.get(visual.id);
          if (!levels || levels.length !== bands) { levels = Array(bands).fill(0); levelsRef.current.set(visual.id, levels); }
          const smoothing = 1-(1-(visual.smoothing??.7))*Math.min(1,visual.sensitivity);
          const spacing=Math.max(0,Math.min(.8,visual.bandSpacing??.15));
          const silent = !playingRef.current || !frequencies.some((value) => value > 0);
          for (let i = 0; i < bands; i++) {
            const fraction = frequencyFraction(i / Math.max(1, bands - 1),visual.peakPosition);
            const bin = visual.frequencyScale === 'linear' ? 2 + fraction * (frequencies.length - 3) : 2 * ((frequencies.length - 1) / 2) ** fraction;
            const magnitude = silent ? 0.07 + 0.035 * Math.sin(i * 0.42) ** 2 : Math.min(1, (frequencies[Math.min(frequencies.length - 1, Math.round(bin))] ?? 0) / 255 * visual.sensitivity);
            levels[i] = (levels[i] ?? 0) * smoothing + magnitude * (1 - smoothing);
          }
          ctx.clearRect(0, 0, w, h); ctx.strokeStyle = visual.color; ctx.fillStyle = visual.color; ctx.lineWidth = Math.max(1, w / 600); ctx.shadowColor=visual.color; ctx.shadowBlur=(visual.glow??0)*2;
          if (waveKinds.has(visual.kind)) {
            let previousWave=waveLevelsRef.current.get(visual.id);
            if(!previousWave||previousWave.length!==w){previousWave=new Float32Array(w);waveLevelsRef.current.set(visual.id,previousWave);}
            if (visual.kind !== 'wavePoints') ctx.beginPath();
            for (let i = 0; i < w; i += visual.kind === 'wavePoints' ? 5 : 2) {
              const nextSample = silent ? 0.075 * Math.sin(i / w * Math.PI * 8) : ((waveform[Math.floor(i / w * (waveform.length - 1))] ?? 128) - 128) / 128 * visual.sensitivity;
              const sample=previousWave[i]!+(nextSample-previousWave[i]!)*Math.min(1,visual.sensitivity);
              previousWave[i]=sample;
              const y = h / 2 + sample * h * 0.43;
              if (visual.kind === 'mirror') { ctx.moveTo(i, h / 2 - Math.abs(sample) * h * 0.43); ctx.lineTo(i, h / 2 + Math.abs(sample) * h * 0.43); }
              else if (visual.kind === 'wavePoints') ctx.fillRect(i, y, 2, 2);
              else if (visual.kind === 'wavePeak') { ctx.moveTo(i, h); ctx.lineTo(i,h-Math.abs(sample)*h*.43); }
              else if (i === 0) ctx.moveTo(i, y); else ctx.lineTo(i, y);
            }
            if (visual.kind !== 'wavePoints') ctx.stroke();
          } else if (spectrumKinds.has(visual.kind)) {
            const colors = visualizerColors(visual);
            if(visual.kind==='spectrumScroll'){ctx.beginPath();for(let i=0;i<bands;i++){const x=i/Math.max(1,bands-1)*w,y=h-Math.max(1,(levels[i]??0)*h);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.strokeStyle=colors[0]!;ctx.stroke();continue;}
            for (let i=0;i<bands;i++) {
              const x=i/bands*w;
              const height=Math.max(1,(levels[i]??0)*h);
              ctx.fillStyle=colors[Math.min(2,Math.floor(i/bands*3))]!;
              const slot=w/bands,gap=slot*spacing;
              if(visual.roundedTop) {const radius=Math.min(visual.cornerRadius??6,(slot-gap)/2,height);ctx.beginPath();ctx.moveTo(x+gap,h);ctx.lineTo(x+gap,h-height+radius);ctx.quadraticCurveTo(x+gap,h-height,x+gap+radius,h-height);ctx.lineTo(x+slot-radius,h-height);ctx.quadraticCurveTo(x+slot,h-height,x+slot,h-height+radius);ctx.lineTo(x+slot,h);ctx.closePath();ctx.fill();}
              else ctx.fillRect(x+gap,h-height,Math.max(1,slot-gap),height);
            }
          } else {
            if (visual.kind === 'line') ctx.beginPath();
            for (let i = 0; i < bands; i++) {
              const x = i / bands * w, y = h - Math.max(1, levels[i]! * h);
              if (visual.kind === 'line') { if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
              else if (visual.kind === 'dots' || visual.kind === 'sparkDots') { ctx.shadowBlur=visual.kind==='sparkDots'?Math.max(3,(visual.glow??0)*2):0;ctx.beginPath(); ctx.arc(x + w / bands / 2, y, Math.max(visual.kind==='sparkDots'?2:1, w / (visual.kind==='sparkDots'?240:400)), 0, Math.PI * 2); ctx.fill(); }
              else { ctx.shadowBlur = Math.max(visual.kind === 'smoothBars' ? 3 : 0,(visual.glow??0)*2);const slot=w/bands,gap=visual.kind==='solidBars'&&visual.bandSpacing===undefined?0:slot*spacing,barWidth=Math.max(1,slot-gap);if(visual.roundedTop){const radius=Math.min(visual.cornerRadius??6,barWidth/2,h-y);ctx.beginPath();ctx.moveTo(x+gap,h);ctx.lineTo(x+gap,y+radius);ctx.quadraticCurveTo(x+gap,y,x+gap+radius,y);ctx.lineTo(x+slot-radius,y);ctx.quadraticCurveTo(x+slot,y,x+slot,y+radius);ctx.lineTo(x+slot,h);ctx.closePath();ctx.fill();}else ctx.fillRect(x+gap,y,barWidth,h-y); }
            }
            ctx.shadowBlur = 0; if (visual.kind === 'line') ctx.stroke();
          }
          ctx.shadowBlur=0;
        }
        frame = requestAnimationFrame(paint);
      };
      frame = requestAnimationFrame(paint);
      return () => {
        active = false;
        cancelAnimationFrame(frame);
        contextRef.current = null;
        routing.users--;
        if (routing.users === 0) routing.closing = window.setTimeout(() => {
          if (routing.users === 0) { analysers.delete(element); void routing.context.close().catch(() => undefined); }
        }, 500);
      };
    } catch (error) { contextRef.current = null; onError?.(`Visualizer tidak dapat membaca audio preview: ${error instanceof Error ? error.message : String(error)}`); }
    return undefined;
  }, [audio]);
  useEffect(() => { if (playing) void contextRef.current?.resume().catch(() => undefined); }, [playing]);
  useEffect(() => {
    if (audio) return;
    // An audio element is attached after the first render. Never leave a blank
    // canvas while its metadata loads or when playback is paused.
    for (const visual of items) {
      const canvas = canvases.current.get(visual.id), ctx = canvas?.getContext('2d');
      if (!canvas || !ctx) continue;
      const w=canvas.width,h=canvas.height,bands=visual.density??64,slot=w/bands,gap=slot*(visual.bandSpacing??(visual.kind==='solidBars'?0:.15));
      ctx.clearRect(0,0,w,h);ctx.fillStyle=visualizerColors(visual)[0]!;ctx.strokeStyle=visual.color;
      if(waveKinds.has(visual.kind)) {ctx.beginPath();for(let x=0;x<w;x+=2){const sample=Math.sin(x*.05)*h*.07,y=visual.kind==='wavePeak'?h-Math.abs(sample):h/2+sample;if(visual.kind==='wavePoints')ctx.fillRect(x,y,2,2);else if(visual.kind==='mirror'){ctx.moveTo(x,h/2-Math.abs(sample));ctx.lineTo(x,h/2+Math.abs(sample));}else if(visual.kind==='wavePeak'){ctx.moveTo(x,h);ctx.lineTo(x,y);}else if(x===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.stroke();continue;}
      if(visual.kind==='line'||visual.kind==='spectrumScroll')ctx.beginPath();
      for(let i=0;i<bands;i++){
        const x=i*slot,y=h*(.7-.23*Math.sin(i*.43)**2),top=Math.max(1,y),barWidth=Math.max(1,slot-gap);
        if(spectrumKinds.has(visual.kind))ctx.fillStyle=visualizerColors(visual)[Math.min(2,Math.floor(i/bands*3))]!;
        if(visual.kind==='line'||visual.kind==='spectrumScroll'){if(i===0)ctx.moveTo(x,top);else ctx.lineTo(x,top);}
        else if(visual.kind==='dots'||visual.kind==='sparkDots'){ctx.beginPath();ctx.arc(x+slot/2,top,visual.kind==='sparkDots'?2:1,0,Math.PI*2);ctx.fill();}
        else if(visual.roundedTop){const radius=Math.min(visual.cornerRadius??6,barWidth/2,h-top);ctx.beginPath();ctx.moveTo(x+gap,h);ctx.lineTo(x+gap,top+radius);ctx.quadraticCurveTo(x+gap,top,x+gap+radius,top);ctx.lineTo(x+slot-radius,top);ctx.quadraticCurveTo(x+slot,top,x+slot,top+radius);ctx.lineTo(x+slot,h);ctx.closePath();ctx.fill();}
        else ctx.fillRect(x+gap,top,barWidth,h-top);
      }
      if(visual.kind==='line'||visual.kind==='spectrumScroll')ctx.stroke();
    }
  },[audio,items]);
  return <>{items.map((visual) => { const width = Math.max(32, Math.min(960, Math.round(visual.size.width))); const height = Math.max(16, Math.round(width * visual.size.height / visual.size.width)); return <canvas key={visual.id} ref={(node) => { if (node) canvases.current.set(visual.id, node); else { canvases.current.delete(visual.id); levelsRef.current.delete(visual.id); waveLevelsRef.current.delete(visual.id); } }} width={width} height={height} className="mrp-preview-visualizer" style={{ left: visual.position.x, top: visual.position.y, width: visual.size.width, height: visual.size.height, opacity: visual.opacity }} />; })}</>;
}
