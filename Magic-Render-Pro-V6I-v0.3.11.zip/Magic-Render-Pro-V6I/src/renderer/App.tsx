import { useEffect, useRef, useState } from 'react';
import type { JSX } from 'react';
import type { ProjectData, RecentProject } from '../shared/domain/projectTypes';
import type { LockedAsset, LockedAssetMenu } from '../shared/domain/lockedAssetTypes';
import type { BulkItemResult, BulkMediaItem, BulkRenderOptions } from '../shared/domain/bulkTypes';
import type { RenderProgress } from '../shared/domain/renderTypes';
import type { YoutubeSeoResult } from '../shared/domain/aiTypes';
import { ConsoleLogPanel, appendConsoleEntry, appendApplicationLog, type ConsoleLogEntry } from './components/ConsoleLogPanel';
import { MainNav } from './components/MainNav';
import { WindowChrome } from './components/WindowChrome';
import { StickerPanel } from './components/StickerPanel';
import { PlaylistPanel } from './components/PlaylistPanel';
import { IntroPanel } from './components/IntroPanel';
import { CanvasPreview } from './components/CanvasPreview';
import { PreviewEyeIcon } from './components/PreviewEyeIcon';
import { PreviewLockIcon } from './components/PreviewLockIcon';
import { DeleteLayerIcon, ChevronIcon, ResetLayerIcon } from './components/LayerActionIcons';
import { YoutubeSeoPanel } from './components/YoutubeSeoPanel';
import { HelpPage } from './components/HelpPage';
import { SettingsPanel } from './components/SettingsPanel';
import { MainMediaEffectsPanel, ParticleEffectsPanel, VisualizerPanel } from './components/EffectsPanels';
import { BulkRenderPage } from './components/BulkRenderPage';
import { TracklistManager } from './components/TracklistManager';
import { AssetVisualEditor } from './components/AssetVisualEditor';
import { overlayAssetPreset } from '../shared/domain/assetPreset';
import { HistoryProvider, useProjectHistory, type HistoryOptions } from './context';
import { countdownEta, type EtaSnapshot } from './utils/renderEta';
import { editorShortcut, isEditingField } from './utils/editorShortcuts';

type MainPage = 'Home' | 'Render' | 'Bulk Render' | 'Asset' | 'Setting' | 'Help';
type RenderTab = 'Media' | 'Intro' | 'Overlay' | 'Playlist' | 'Sticker Subscribe' | 'Youtube SEO';
const renderTabs: RenderTab[] = ['Media', 'Intro', 'Overlay', 'Playlist', 'Sticker Subscribe', 'Youtube SEO'];
type RenderCompletion = { outputPath: string; durationSec: number; elapsedSec: number; resolution: string; fps: number; bitrateKbps: number; fileSizeBytes: number | null; overlays: number; intro: boolean; stickers: number; renderDevice: 'cpu' | 'gpu'; gpu: { name: string; vramMb: number | null; encoder: string | null } };

function estimatedVideoDuration(project: ProjectData | null): number {
  if (!project) return 0;
  const tracks = project.playlistTracks ?? [];
  const playlist = tracks.length && tracks.every((track) => (track.durationSeconds ?? 0) > 0) ? tracks.reduce((sum, track) => sum + (track.durationSeconds ?? 0), 0) : 0;
  return playlist || project.mainMedia?.durationSeconds || 0;
}

function mergeRenderProgress(previous: RenderProgress | null, next: RenderProgress): RenderProgress {
  if (!previous || previous.projectId !== next.projectId) return next;
  if (['done', 'error', 'cancelled'].includes(previous.status) && !['done', 'error', 'cancelled'].includes(next.status)) return previous;
  return { ...next, elapsedRenderSec: Math.max(previous.elapsedRenderSec, next.elapsedRenderSec) };
}

function MainMediaControlsPanel({ project, onProjectChange, onReplaceMedia }: { project: ProjectData; onProjectChange: (project: ProjectData, options?: HistoryOptions) => void; onReplaceMedia: () => Promise<void> }): JSX.Element {
  const media = project.mainMedia;
  const [controlsCollapsed, setControlsCollapsed] = useState(true);
  const latest = useRef(project);
  latest.current = project;
  if (!media) return <></>;
  const fadeIn = media.fade.fadeInSec, fadeOut = media.fade.fadeOutSec;
  const zoom = Math.round((media.resize?.width ?? 1920) / 1920 * 100);
  function patch(change: Partial<NonNullable<ProjectData['mainMedia']>>): void {
    const current = latest.current;
    if (!current.mainMedia) return;
    const next = { ...current, mainMedia: { ...current.mainMedia, ...change } };
    latest.current = next;
    onProjectChange(next, { mode: 'coalesce', label: 'Main media controls' });
  }
  function commit(): void { onProjectChange(latest.current, { mode: 'commit-coalesced', label: 'Main media controls' }); }
  function resetControls(): void {
    const current = latest.current;
    if (!current.mainMedia) return;
    const next = { ...current, mainMedia: { ...current.mainMedia, fade: { fadeInSec: 0, fadeOutSec: 0 }, resize: { width: 1920, height: 1080 }, position: { x: 0, y: 0 }, rotation: 0, autoMute: !!current.mainMedia.metadata?.hasAudioTrack } };
    latest.current = next; onProjectChange(next);
  }
  const slider = (label: string, value: number, change: (n: number) => void, min: number, max: number, unit: string) => <label className="block">{label}<input className="w-full" type="range" min={min} max={max} step="1" value={value} onChange={(event) => change(Number(event.target.value))}/><span className="text-white/45">{value > 0 ? '+' : ''}{value}{unit}</span></label>;
  const changed = fadeIn !== 0 || fadeOut !== 0 || media.rotation !== 0 || media.position.x !== 0 || media.position.y !== 0 || zoom !== 100 || media.autoMute !== !!media.metadata?.hasAudioTrack;
  return <div className="mt-4 rounded-xl border border-cyber-violet/20 bg-black/20 p-4"><div className="mb-3 flex items-center justify-between"><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-violet">Main Media Controls</div><div className="flex gap-3">{changed && <button type="button" aria-label="Reset Main Media Controls" title="Reset Main Media Controls" onClick={resetControls}><ResetLayerIcon /></button>}<button type="button" aria-label={controlsCollapsed ? "Buka Main Media Controls" : "Tutup Main Media Controls"} onClick={() => setControlsCollapsed((value) => !value)}><ChevronIcon expanded={!controlsCollapsed} /></button></div></div>{!controlsCollapsed && <><div className="grid grid-cols-2 gap-3 text-xs" onPointerUp={commit} onKeyUp={(event) => { if (event.target instanceof HTMLInputElement && event.target.type === 'range') commit(); }}>
    <label>Fade In<input className="w-full" type="range" min="0" max="30" step="0.1" value={fadeIn} onChange={(event) => patch({ fade: { ...media.fade, fadeInSec: Number(event.target.value) } })}/><span className="text-white/45">{fadeIn.toFixed(1)} detik</span></label>
    <label>Fade Out<input className="w-full" type="range" min="0" max="30" step="0.1" value={fadeOut} onChange={(event) => patch({ fade: { ...media.fade, fadeOutSec: Number(event.target.value) } })}/><span className="text-white/45">{fadeOut.toFixed(1)} detik</span></label>
    {slider('Position X', media.position.x, (x) => patch({ position: { ...latest.current.mainMedia!.position, x } }), -1920, 1920, ' px')}{slider('Position Y', media.position.y, (y) => patch({ position: { ...latest.current.mainMedia!.position, y } }), -1080, 1080, ' px')}
    {slider('Rotation', media.rotation, (rotation) => patch({ rotation }), -180, 180, '°')}{slider('Zoom Out / In', zoom, (value) => patch({ resize: { width: Math.round(1920 * value / 100 / 2) * 2, height: Math.round(1080 * value / 100 / 2) * 2 } }), 25, 300, '%')}
    <label className="col-span-2 flex items-center gap-2"><input type="checkbox" checked={media.autoMute} onChange={(event) => { const next = { ...latest.current, mainMedia: { ...latest.current.mainMedia!, autoMute: event.target.checked } }; latest.current = next; onProjectChange(next); }}/> Auto Mute</label>
  </div><button className="mrp-btn mt-3 w-full" type="button" onClick={() => void onReplaceMedia()}>Ubah Media</button></>}</div>;
}

function formatStorage(bytes: number | null): string {
  if (bytes === null) return 'N/A';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let index = 0;
  while (value >= 1024 && index < units.length - 1) { value /= 1024; index += 1; }
  return `${value.toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

function OutputSettingsPanel({ project, onProjectChange, onMessage }: { project: ProjectData; onProjectChange: (project: ProjectData) => void; onMessage: (message: string) => void }): JSX.Element {
  const [outputDir, setOutputDir] = useState(project.settings.outputDir);
  const [resolution, setResolution] = useState(project.settings.resolution);
  const [bitrate, setBitrate] = useState(project.settings.bitrateKbps);
  const [validation, setValidation] = useState<Awaited<ReturnType<typeof window.magicRender.validateOutput>> | null>(null);
  useEffect(() => { setOutputDir(project.settings.outputDir); setResolution(project.settings.resolution); setBitrate(project.settings.bitrateKbps); }, [project.projectId, project.settings.outputDir, project.settings.resolution, project.settings.bitrateKbps]);

  async function chooseDirectory(): Promise<void> {
    try { const chosen = await window.magicRender.chooseOutputDirectory(); if (chosen) setOutputDir(chosen); }
    catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal memilih output directory.'); }
  }
  async function validate(): Promise<void> {
    try {
      const next = { ...project, settings: { ...project.settings, outputDir, resolution, bitrateKbps: bitrate } };
      const result = await window.magicRender.validateOutput(next);
      setValidation(result);
      onMessage(result.valid ? 'Output configuration valid.' : `Output belum valid: ${result.errors.join(' ')}`);
    } catch (error) { onMessage(error instanceof Error ? error.message : 'Validasi output gagal.'); }
  }
  async function apply(): Promise<void> {
    try {
      const result = await window.magicRender.updateOutputSettings(project, outputDir, resolution, bitrate);
      await window.magicRender.updateSettings({ outputDir: result.project.settings.outputDir });
      const saved = await window.magicRender.saveProject(result.project);
      onProjectChange(saved.project); setValidation(null);
      onMessage('Folder output dan pengaturan video tersimpan untuk penggunaan berikutnya.');
    } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menerapkan output settings.'); }
  }

  return <div className="mt-3 rounded-xl border border-cyber-cyan/20 bg-black/20 p-4">
    <div className="mb-3 flex items-start justify-between gap-3">
      <div><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-cyan">Output & Encoding</div><div className="mt-1 text-[10px] text-white/40">MP4 • H.264 • AAC • CBR approximation</div></div>
      <span className="rounded-full border border-cyber-fuchsia/20 px-2 py-1 text-[9px] uppercase tracking-widest text-cyber-fuchsia">safe output</span>
    </div>
    <div className="space-y-3 text-xs">
      <label className="block">Output Directory<div className="mt-1 flex gap-2"><input className="min-w-0 flex-1 rounded-lg border border-white/10 bg-white/5 p-2 text-xs" value={outputDir} onChange={(e)=>setOutputDir(e.target.value)} /><button className="rounded-lg border border-cyber-cyan/30 px-3 py-2 text-[10px] uppercase tracking-wider hover:bg-cyber-cyan/10" onClick={()=>void chooseDirectory()}>Browse</button></div></label>
      <div className="grid grid-cols-2 gap-2">
        <label>Resolution<select className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 p-2 text-xs" value={resolution} onChange={(e)=>setResolution(e.target.value as ProjectData['settings']['resolution'])}><option value="720p">720p — 1280×720</option><option value="1080p">1080p — 1920×1080</option><option value="2K">2K — 2560×1440</option><option value="4K">4K — 3840×2160</option></select></label>
        <label>Video Bitrate (kbps)<input className="mt-1 w-full rounded-lg border border-white/10 bg-white/5 p-2 text-xs" type="number" min="1" max="1000000" step="1" value={bitrate} onChange={(e)=>setBitrate(Number(e.target.value))}/></label>
      </div>
      <div className="grid grid-cols-2 gap-2 text-[9px] uppercase tracking-widest text-white/45"><span>Video: H.264 / libx264</span><span>FPS: {project.settings.fps ?? 30}</span><span>Preset: {project.settings.renderPreset ?? 'standard'}</span><span>Audio: AAC</span></div>
      <div className="rounded-lg border border-white/5 bg-black/20 px-3 py-2 text-[10px] text-white/45">Satu encoding visual dengan CRF dan batas bitrate dari Settings. Playlist digabung lebih dulu; audio hasilnya disalin ke MP4.</div>
      <div className="flex flex-wrap gap-2"><button className="rounded-lg border border-cyber-cyan/30 px-3 py-2 text-xs hover:bg-cyber-cyan/10" onClick={()=>void validate()}>Validate Output</button><button className="rounded-lg border border-cyber-violet/30 px-3 py-2 text-xs hover:bg-cyber-violet/10" onClick={()=>void apply()}>Apply Output Settings</button></div>
      {validation && <div className="rounded-lg border border-white/5 p-3 text-[10px]"><div className="flex items-center justify-between"><span className="uppercase tracking-widest text-white/40">Validation</span><span className={validation.valid ? 'text-cyber-cyan' : 'text-cyber-fuchsia'}>{validation.valid ? 'VALID' : 'INVALID'}</span></div><div className="mt-2 grid grid-cols-2 gap-1 text-white/45"><span>Extension: {validation.extension}</span><span>Writable: {validation.writable ? 'yes' : 'no'}</span><span>Free: {formatStorage(validation.availableBytes)}</span><span>Storage: {validation.sufficientStorage === null ? 'unknown' : validation.sufficientStorage ? 'sufficient' : 'low'}</span></div>{validation.warnings.length > 0 && <div className="mt-2 text-cyber-violet">{validation.warnings.join(' ')}</div>}{validation.errors.length > 0 && <div className="mt-2 text-cyber-fuchsia">{validation.errors.join(' ')}</div>}</div>}
      <div className="text-[10px] text-white/35">Overwrite handling: output collision tidak menimpa file lama; sistem memilih nama file berikutnya secara otomatis.</div>
    </div>
  </div>;
}

function TextOverlayPanel({ project, onProjectChange }: { project: ProjectData; onProjectChange: (project: ProjectData) => void }): JSX.Element {
  const [text, setText] = useState('MAGIC RENDER PRO');
  const [font, setFont] = useState('Arial');
  const [installedFonts, setInstalledFonts] = useState<string[]>(['Arial']);
  const [color, setColor] = useState('#2cf9ff');
  const [glowColor, setGlowColor] = useState('#2cf9ff');
  const [strokeColor, setStrokeColor] = useState('#05050d');
  const [textError, setTextError] = useState('');
  const [size, setSize] = useState(64);
  const [opacity, setOpacity] = useState(1);
  const [bold, setBold] = useState(true);
  const [italic, setItalic] = useState(false);
  const [underline, setUnderline] = useState(false);
  const [stroke, setStroke] = useState(2);
  const [glow, setGlow] = useState(true);
  const [animation, setAnimation] = useState<'none'|'fade-in'|'fade-out'|'pulse'|'running-left'|'running-right'>('none');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [collapsedTextId, setCollapsedTextId] = useState<string | null>(null);
  const [textSystemCollapsed, setTextSystemCollapsed] = useState(true);
  const overlays = project.textOverlays ?? [];
  useEffect(() => { let mounted = true; void window.magicRender.listDeviceFonts().then((fonts) => { if (mounted) setInstalledFonts(fonts); }).catch(() => undefined); return () => { mounted = false; }; }, []);
  const style = { text, fontFamily: font, fontStyle: italic ? 'italic' as const : 'normal' as const, fontColor: color, fontSize: size, bold, italic, underline, strokeColor, strokeWidth: stroke, opacity, neonGlow: glow, glowColor, glowBlur: 18, effect: glow ? 'glow' as const : 'none' as const, animation };
  const config = { ...style, position: { x: 40, y: 40 }, scale: 1, rotation: 0, speed: 1 };
  const textChanged = JSON.stringify(style) !== JSON.stringify({ text:'MAGIC RENDER PRO',fontFamily:'Arial',fontStyle:'normal',fontColor:'#2cf9ff',fontSize:64,bold:true,italic:false,underline:false,strokeColor:'#05050d',strokeWidth:2,opacity:1,neonGlow:true,glowColor:'#2cf9ff',glowBlur:18,effect:'glow',animation:'none' }) || !!overlays.find((item)=>item.id===selectedId && (item.config.position.x!==40 || item.config.position.y!==40 || item.config.rotation!==0 || item.config.scale!==1));
  function loadOverlay(id: string): void { const found = overlays.find((item) => item.id === id); if (!found) return; setSelectedId(id); setCollapsedTextId(null); setTextSystemCollapsed(false); setTextError(''); const c = found.config; setText(c.text); setFont(c.fontFamily); setColor(c.fontColor.startsWith('#') ? c.fontColor : `#${c.fontColor}`); setGlowColor(c.glowColor.startsWith('#') ? c.glowColor : `#${c.glowColor}`); setSize(c.fontSize); setOpacity(c.opacity); setBold(c.bold); setItalic(c.italic); setUnderline(c.underline); setStroke(c.strokeWidth); setStrokeColor(c.strokeColor.startsWith('#') ? c.strokeColor : `#${c.strokeColor}`); setGlow(c.neonGlow); setAnimation(c.animation); }
  async function add(): Promise<void> { try { const r = await window.magicRender.addTextOverlay(project, config); onProjectChange(r.project); setSelectedId(r.project.textOverlays?.at(-1)?.id ?? null); setTextError(''); } catch (error) { setTextError(error instanceof Error ? error.message : 'Gagal menambah teks.'); } }
  async function applyEdit(): Promise<void> { if (!selectedId) { setTextError('Pilih teks yang ingin diedit dari daftar di bawah, atau gunakan Tambahkan Text Overlay Baru.'); return; } const current = overlays.find((item) => item.id === selectedId); if (!current) { setTextError('Teks pilihan tidak ditemukan. Pilih lagi dari daftar.'); return; } try { const r = await window.magicRender.updateTextOverlay(project, { ...current, config: { ...current.config, ...style } }); onProjectChange(r.project); setTextError(''); } catch (error) { setTextError(error instanceof Error ? error.message : 'Gagal menerapkan perubahan warna teks.'); } }
  function resetText(): void { setText('MAGIC RENDER PRO'); setFont('Arial'); setColor('#2cf9ff'); setGlowColor('#2cf9ff'); setStrokeColor('#05050d'); setSize(64); setOpacity(1); setBold(true); setItalic(false); setUnderline(false); setStroke(2); setGlow(true); setAnimation('none'); setTextError(''); if (selectedId) onProjectChange({ ...project, textOverlays: overlays.map((item) => item.id === selectedId ? { ...item, config: { ...item.config, fontFamily:'Arial', fontColor:'#2cf9ff', glowColor:'#2cf9ff', strokeColor:'#05050d', fontSize:64, opacity:1, bold:true, italic:false, underline:false, strokeWidth:2, neonGlow:true, effect:'glow', animation:'none', position:{x:40,y:40}, rotation:0, scale:1, speed:1 } } : item) }); }
  async function remove(id: string): Promise<void> { const r = await window.magicRender.removeTextOverlay(project, id); onProjectChange(r.project); if (id === selectedId) setSelectedId(null); }
  return <div className="mt-4 rounded-xl border border-cyber-fuchsia/20 bg-black/20 p-4">
    <div className="mb-3 flex items-center justify-between"><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-fuchsia">Text Overlay System</div><div className="flex items-center gap-3">{textChanged && <button type="button" aria-label="Reset Text Overlay System" title="Reset Text Overlay System" onClick={resetText}><ResetLayerIcon /></button>}<button type="button" disabled={!selectedId} aria-label="Tampilkan atau sembunyikan text overlay terpilih" title="Tampilkan/sembunyikan teks terpilih" onClick={() => onProjectChange({ ...project, textOverlays: overlays.map((item) => item.id === selectedId ? { ...item, hiddenInPreview: !item.hiddenInPreview } : item) })}><PreviewEyeIcon hidden={!!overlays.find((item) => item.id === selectedId)?.hiddenInPreview} /></button><button type="button" disabled={!selectedId} aria-label="Kunci atau buka text overlay terpilih" title="Kunci/buka teks terpilih" onClick={() => onProjectChange({ ...project, textOverlays: overlays.map((item) => item.id === selectedId ? { ...item, locked: !item.locked } : item) })}><PreviewLockIcon locked={!!overlays.find((item) => item.id === selectedId)?.locked} /></button><button type="button" disabled={!selectedId} aria-label="Hapus text overlay terpilih" title="Hapus teks terpilih" className="text-cyber-fuchsia" onClick={() => { if (selectedId) void remove(selectedId); }}><DeleteLayerIcon /></button><button type="button" aria-label={textSystemCollapsed ? 'Tampilkan setting Text Overlay System' : 'Sembunyikan setting Text Overlay System'} aria-expanded={!textSystemCollapsed} title="Tampilkan/sembunyikan kontrol teks" onClick={() => setTextSystemCollapsed((value) => !value)}><ChevronIcon expanded={!textSystemCollapsed} /></button></div></div>
    {!textSystemCollapsed && (!selectedId || collapsedTextId !== selectedId) && <>
    <div className="grid grid-cols-2 gap-2 text-xs">
      <label className="col-span-2">Text<input className="w-full rounded bg-black p-2 text-white" value={text} onChange={e=>setText(e.target.value)}/></label>
      <label>Font perangkat<select className="mrp-dark-select w-full" value={font} onChange={e=>setFont(e.target.value)}>{![...installedFonts].includes(font) && <option value={font}>{font}</option>}{installedFonts.map((name) => <option key={name} value={name}>{name}</option>)}</select></label>
      <div className="col-span-2 grid grid-cols-3 gap-2"><label>Warna Teks<input aria-label="Warna Teks" className="h-9 w-full rounded bg-black p-1" type="color" value={color} onChange={e=>setColor(e.target.value)}/><span className="text-white/45">{color}</span></label><label>Warna Stroke<input aria-label="Warna Stroke" className="h-9 w-full rounded bg-black p-1" type="color" value={strokeColor} onChange={e=>setStrokeColor(e.target.value)}/><span className="text-white/45">{strokeColor}</span></label><label>Warna Neon Glow<input aria-label="Warna Neon Glow" className="h-9 w-full rounded bg-black p-1" type="color" value={glowColor} onChange={e=>setGlowColor(e.target.value)}/><span className="text-white/45">{glowColor}</span></label></div>
      <label>Size<input className="w-full rounded bg-black p-2 text-white" type="number" min="8" max="512" value={size} onChange={e=>setSize(Number(e.target.value))}/></label>
      <label>Opacity<input className="w-full" type="range" min="0" max="1" step="0.01" value={opacity} onChange={e=>setOpacity(Number(e.target.value))}/></label>
      <label>Stroke<input className="w-full rounded bg-black p-2 text-white" type="number" min="0" max="64" value={stroke} onChange={e=>setStroke(Number(e.target.value))}/></label>
      <label>Animation<select className="mrp-dark-select" value={animation} onChange={e=>setAnimation(e.target.value as typeof animation)}><option value="none">None</option><option value="fade-in">Fade In</option><option value="fade-out">Fade Out</option><option value="pulse">Pulse</option><option value="running-left">Running Left</option><option value="running-right">Running Right</option></select></label>
      <div className="col-span-2 grid grid-cols-4 gap-1"><label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={bold} onChange={e=>setBold(e.target.checked)}/> Bold</label><label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={italic} onChange={e=>setItalic(e.target.checked)}/> Italic</label><label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={underline} onChange={e=>setUnderline(e.target.checked)}/> Underline</label><label className="flex items-center gap-1 whitespace-nowrap"><input type="checkbox" checked={glow} onChange={e=>setGlow(e.target.checked)}/> Neon Glow</label></div>
    </div>
    <div className="mt-3 rounded border border-white/10 bg-black p-2 text-center text-xl" style={{ color, WebkitTextFillColor: color, WebkitTextStroke: `${stroke}px ${strokeColor}`, textShadow: glow ? `0 0 12px ${glowColor}` : 'none' }}>Pratinjau warna teks</div>
    {textError && <div className="mt-2 text-xs text-cyber-fuchsia" role="alert">{textError}</div>}
    <div className="mt-3 grid grid-cols-2 gap-2"><button className="rounded-lg border border-cyber-cyan/30 px-3 py-2 text-xs text-cyber-cyan" onClick={()=>void applyEdit()}>Terapkan Edit Text ke Canvas Preview</button><button className="rounded-lg border border-cyber-fuchsia/30 px-3 py-2 text-xs" onClick={()=>void add()}>Tambahkan Text Overlay Baru</button></div>
    </>}
    <div className="mt-3 space-y-2">{overlays.map(o=><div key={o.id} className="flex items-center justify-between rounded border border-white/5 p-2 text-[10px]"><button type="button" className={`truncate text-left ${selectedId === o.id ? 'text-cyber-cyan' : 'text-white'}`} onClick={()=>loadOverlay(o.id)}>{o.config.text}</button><div className="flex items-center gap-2"><button type="button" aria-label={o.hiddenInPreview ? 'Tampilkan text overlay' : 'Sembunyikan text overlay'} title={o.hiddenInPreview ? 'Tampilkan di preview' : 'Sembunyikan dari preview'} onClick={()=>onProjectChange({...project,textOverlays:overlays.map((item)=>item.id===o.id?{...item,hiddenInPreview:!item.hiddenInPreview}:item)})}><PreviewEyeIcon hidden={!!o.hiddenInPreview}/></button><button type="button" aria-label={o.locked ? 'Buka kunci text overlay' : 'Kunci text overlay'} title="Kunci posisi text pada preview" onClick={()=>onProjectChange({...project,textOverlays:overlays.map((item)=>item.id===o.id?{...item,locked:!item.locked}:item)})}><PreviewLockIcon locked={!!o.locked}/></button><button type="button" className="text-cyber-fuchsia" aria-label="Hapus text overlay" title="Hapus text overlay" onClick={()=>void remove(o.id)}><DeleteLayerIcon /></button><button type="button" aria-label={collapsedTextId === o.id ? "Tampilkan setting text" : "Sembunyikan setting text"} aria-expanded={selectedId === o.id && collapsedTextId !== o.id} title="Tampilkan/sembunyikan setting" onClick={()=>{if (selectedId !== o.id) loadOverlay(o.id); else setCollapsedTextId((previous)=>previous === o.id ? null : o.id);}}><ChevronIcon expanded={selectedId === o.id && collapsedTextId !== o.id} /></button></div></div>)}</div>
  </div>;
}

function OverlayPanel({ project, onProjectChange, hiddenLayers, onToggleLayer }: { project: ProjectData; onProjectChange: (project: ProjectData, options?: HistoryOptions) => void; hiddenLayers: Set<string>; onToggleLayer: (key: string) => void }): JSX.Element {
  const latest = useRef(project);
  latest.current = project;
  const [library, setLibrary] = useState<LockedAsset[]>([]);
  const [libraryBusy, setLibraryBusy] = useState(false);
  async function refreshLibrary(): Promise<void> { setLibraryBusy(true); try { setLibrary((await window.magicRender.listLockedAssets()).filter((item) => item.menu === 'overlay')); } catch (error) { void window.magicRender.logActivity('ERROR', 'Gagal memuat overlay dari Asset Library.', error instanceof Error ? error.message : String(error)); } finally { setLibraryBusy(false); } }
  useEffect(() => { void refreshLibrary(); }, []);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  function toggleCollapsed(id: string): void { setCollapsed((current) => { const next = new Set(current); if (next.has(id)) next.delete(id); else next.add(id); return next; }); }
  function getConfig(overlay: ProjectData['overlays'][number]): ProjectData['overlays'][number]['config'] { return overlay.config; }
  function patchDraft(id: string, patch: Partial<ProjectData['overlays'][number]['config']>): void { const base = latest.current; const next = { ...base, overlays: base.overlays.map((item) => item.id === id ? { ...item, config: { ...item.config, ...patch } } : item) }; latest.current = next; onProjectChange(next, { mode: 'coalesce', label: 'Overlay controls' }); }
  function commit(): void { onProjectChange(latest.current, { mode: 'commit-coalesced', label: 'Overlay controls' }); }
  function patchNested(id: string, key: 'position' | 'resize' | 'chromaKey' | 'colorKey', value: unknown): void { patchDraft(id, { [key]: value } as Partial<ProjectData['overlays'][number]['config']>); }
  const centeredSlider = (label: string, value: number, min: number, max: number, onChange: (value: number) => void, display: string) => <label className="mrp-overlay-slider">{label}<input type="range" min={min} max={max} step="1" value={Math.max(min, Math.min(max, value))} onChange={(event) => onChange(Number(event.target.value))}/><span>{value > 0 ? '+' : ''}{value} {display}</span></label>;
  const scaleOffset = (value: number, base: number): number => Math.round(33.333 * Math.log2(Math.max(1, value) / base));
  const scaledValue = (offset: number, base: number): number => Math.max(1, Math.round(base * (2 ** (offset / 33.333))));
  function resetOverlay(overlay: ProjectData['overlays'][number]): void { const next = { opacity:1, position:{x:0,y:0}, resize:null, rotation:0, speed:1, blendMode:'normal' as const, chromaKey:{enabled:false,color:'0x00FF00',similarity:0.3,blend:0.1}, colorKey:{enabled:false,color:'0x000000',similarity:0.3,blend:0.1} }; onProjectChange({ ...project, overlays: project.overlays.map((item) => item.id === overlay.id ? { ...item, config:next } : item) }); }
  function toggleLock(id: string): void { onProjectChange({ ...project, overlays: project.overlays.map((item) => item.id === id ? { ...item, locked: !item.locked } : item) }); }
  async function add(type: 'image' | 'video', asset?: LockedAsset): Promise<void> { try { const result = await window.magicRender.addOverlay(project, type, asset?.path); if (result) { const overlays = result.project.overlays.map((item, index) => index === result.project.overlays.length - 1 && asset ? { ...item, config: overlayAssetPreset(asset) } : item); onProjectChange({ ...result.project, overlays }); } } catch (error) { void window.magicRender.logActivity('ERROR', 'Overlay import gagal.', error instanceof Error ? error.message : String(error)); } }
  async function remove(id: string): Promise<void> { try { onProjectChange((await window.magicRender.removeOverlay(project, id)).project); } catch (error) { void window.magicRender.logActivity('ERROR', 'Overlay remove gagal.', error instanceof Error ? error.message : String(error)); } }
  return <div className="mt-4 rounded-xl border border-cyber-cyan/20 bg-black/20 p-4" onPointerUp={commit} onKeyUp={commit} onBlur={commit}>
    <div className="mb-3 flex items-center justify-between gap-2"><div><div className="text-xs font-bold uppercase tracking-[0.2em] text-cyber-cyan">Overlay System</div><div className="mt-1 text-[10px] text-white/40">Perubahan langsung muncul di Canvas Preview. Resize/rotasi juga tersedia melalui canvas.</div></div><div className="flex gap-2"><button className="mrp-btn" onClick={() => void add('image')}>+ Image</button><button className="mrp-btn" onClick={() => void add('video')}>+ Video</button></div></div>
    <div className="mb-3 rounded-lg border border-white/5 p-3"><div className="flex items-center justify-between gap-2"><span className="text-[10px] uppercase tracking-widest text-white/50">Overlay di Asset Library</span><button type="button" className="mrp-btn" disabled={libraryBusy} onClick={() => void refreshLibrary()}>{libraryBusy ? 'Memuat...' : '↻ Refresh'}</button></div><div className="mt-2 flex flex-wrap gap-2">{library.length ? library.map((asset) => <button key={asset.assetId} type="button" className="mrp-btn" onClick={() => void add(/\.(mp4|mov|mkv|webm|gif)$/i.test(asset.path) ? 'video' : 'image', asset)}>{asset.metadata.originalName}</button>) : <span className="text-[10px] text-white/40">Belum ada overlay tersimpan. Klik Refresh setelah menambahkan di Asset Library.</span>}</div></div>
    <div className="space-y-3">{project.overlays.length === 0 ? <div className="text-xs text-white/35">Belum ada overlay.</div> : project.overlays.map((overlay, index) => { const disabled = false; const config = getConfig(overlay); const keyMode = config.chromaKey.enabled ? 'chroma' : config.colorKey.enabled ? 'color' : 'none'; return <div key={overlay.id} className="rounded-lg border border-white/5 bg-black/10 p-3"><div className="flex items-center justify-between"><span className="text-xs font-semibold">Layer {index + 1} • {overlay.type}</span><div className="flex items-center gap-3"><button type="button" aria-label="Reset pengaturan overlay" title="Reset pengaturan overlay" onClick={() => resetOverlay(overlay)}><ResetLayerIcon /></button><button type="button" aria-label={hiddenLayers.has(`overlay:${overlay.id}`) ? "Tampilkan overlay" : "Sembunyikan overlay"} title={hiddenLayers.has(`overlay:${overlay.id}`) ? "Tampilkan di preview" : "Sembunyikan dari preview"} onClick={() => onToggleLayer(`overlay:${overlay.id}`)}><PreviewEyeIcon hidden={hiddenLayers.has(`overlay:${overlay.id}`)} /></button><button type="button" aria-pressed={!!overlay.locked} aria-label={overlay.locked ? "Buka kunci overlay" : "Kunci overlay"} title={overlay.locked ? "Buka kunci posisi di preview" : "Kunci posisi di preview"} onClick={() => toggleLock(overlay.id)}><PreviewLockIcon locked={!!overlay.locked} /></button><button type="button" className="text-cyber-fuchsia" aria-label="Hapus overlay" title="Hapus overlay" onClick={() => void remove(overlay.id)}><DeleteLayerIcon /></button><button type="button" aria-label={collapsed.has(overlay.id) ? "Tampilkan setting overlay" : "Sembunyikan setting overlay"} aria-expanded={!collapsed.has(overlay.id)} title="Tampilkan/sembunyikan setting" onClick={() => toggleCollapsed(overlay.id)}><ChevronIcon expanded={!collapsed.has(overlay.id)} /></button></div></div>{!collapsed.has(overlay.id) && <><div className="mt-3 grid grid-cols-2 gap-2 text-[10px]">
      <label>Opacity<input disabled={disabled} className="w-full" type="range" min="0" max="1" step="0.01" value={config.opacity} onChange={(e) => patchDraft(overlay.id, { opacity: Number(e.target.value) })}/><span className="text-white/45">{config.opacity.toFixed(2)}</span></label>
      <fieldset disabled={disabled}>{centeredSlider('Speed', scaleOffset(config.speed, 1), -100, 100, (offset) => patchDraft(overlay.id, { speed: Number((2 ** (offset / 33.333)).toFixed(3)) }), `(${config.speed.toFixed(2)}×)`)}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Posisi X', config.position.x, -1920, 1920, (x) => patchNested(overlay.id, 'position', { ...config.position, x }), 'px')}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Posisi Y', config.position.y, -1080, 1080, (y) => patchNested(overlay.id, 'position', { ...config.position, y }), 'px')}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Lebar', scaleOffset(config.resize?.width ?? 320, 320), -100, 100, (offset) => patchNested(overlay.id, 'resize', { width: scaledValue(offset, 320), height: config.resize?.height ?? 180 }), `(${config.resize?.width ?? 320} px)`)}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Tinggi', scaleOffset(config.resize?.height ?? 180, 180), -100, 100, (offset) => patchNested(overlay.id, 'resize', { width: config.resize?.width ?? 320, height: scaledValue(offset, 180) }), `(${config.resize?.height ?? 180} px)`)}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Rotasi', config.rotation, -180, 180, (rotation) => patchDraft(overlay.id, { rotation }), '°')}</fieldset>
      <fieldset disabled={disabled}>{centeredSlider('Zoom', scaleOffset(config.resize?.width ?? 320, 320), -100, 100, (offset) => patchNested(overlay.id, 'resize', { width: scaledValue(offset, 320), height: scaledValue(offset, 180) }), `(${Math.round((config.resize?.width ?? 320) / 320 * 100)}%)`)}</fieldset>
      <label>Blend<select disabled={disabled} className="mrp-dark-select" value={config.blendMode} onChange={(e) => patchDraft(overlay.id, { blendMode: e.target.value as typeof config.blendMode })}><option value="normal">Normal</option><option value="multiply">Multiply</option><option value="screen">Screen</option><option value="overlay">Overlay</option></select></label>
      <label>Keying<select disabled={disabled} className="mrp-dark-select" value={keyMode} onChange={(e) => { const value = e.target.value as 'none' | 'chroma' | 'color'; patchDraft(overlay.id, { chromaKey: { ...config.chromaKey, enabled: value === 'chroma' }, colorKey: { ...config.colorKey, enabled: value === 'color' } }); }}><option value="none">Off</option><option value="chroma">Chroma Key</option><option value="color">Color Key</option></select></label>
      </div>{keyMode === 'chroma' && <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]"><label>Chroma Key Level<input disabled={disabled} className="w-full" type="range" min="0" max="1" step="0.01" value={config.chromaKey.similarity} onChange={(e) => patchNested(overlay.id, 'chromaKey', { ...config.chromaKey, similarity: Number(e.target.value) })}/><span className="text-white/45">{config.chromaKey.similarity.toFixed(2)}</span></label><label>Blend<input disabled={disabled} className="w-full" type="range" min="0" max="1" step="0.01" value={config.chromaKey.blend} onChange={(e) => patchNested(overlay.id, 'chromaKey', { ...config.chromaKey, blend: Number(e.target.value) })}/><span className="text-white/45">{config.chromaKey.blend.toFixed(2)}</span></label></div>}{keyMode === 'color' && <div className="mt-2 grid grid-cols-2 gap-2 text-[10px]"><label>Color Key Level<input disabled={disabled} className="w-full" type="range" min="0" max="1" step="0.01" value={config.colorKey.similarity} onChange={(e) => patchNested(overlay.id, 'colorKey', { ...config.colorKey, similarity: Number(e.target.value) })}/></label><label>Blend<input disabled={disabled} className="w-full" type="range" min="0" max="1" step="0.01" value={config.colorKey.blend} onChange={(e) => patchNested(overlay.id, 'colorKey', { ...config.colorKey, blend: Number(e.target.value) })}/></label></div>}</>}</div>; })}</div>
  </div>;
}

function SuperpowerIcon({ type }: { type: 'video' | 'audio' | 'asset' | 'speed' }): JSX.Element {
  const common = { width: 30, height: 30, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };
  if (type === 'video') return <svg {...common}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m9 5 2 3h2l2-3M9 19l2-3h2l2 3"/><path d="m10 9 5 3-5 3z" fill="currentColor" stroke="none"/></svg>;
  if (type === 'audio') return <svg {...common}><path d="M4 10v4M8 7v10M12 4v16M16 7v10M20 10v4"/></svg>;
  if (type === 'asset') return <svg {...common}><path d="m12 3 8 4-8 4-8-4 8-4Z"/><path d="m4 12 8 4 8-4M4 17l8 4 8-4"/></svg>;
  return <svg {...common}><path d="m13 2-9 12h6l-1 8 9-13h-6l1-7Z" fill="currentColor" stroke="none"/></svg>;
}

function HomePage({ onStart }: { onStart: () => void }): JSX.Element {
  const features = [
    { type: 'video' as const, title: 'Video Rendering', text: 'High quality output' },
    { type: 'audio' as const, title: 'Audio Support', text: 'Professional audio' },
    { type: 'asset' as const, title: 'Asset Library', text: 'Manage your assets' },
    { type: 'speed' as const, title: 'Fast & Stable', text: 'Optimized performance' },
  ];
  return <section className="mrp-home-page">
    <div className="mrp-home-hero">
      <img className="mrp-home-logo" src="./assets/magic-render-pro-logo.png" alt="Magic Render Pro" />
      <h1>Magic Render <span>Pro</span></h1>
      <div className="mrp-home-tagline">CREATE <b>•</b> RENDER <b>•</b> INSPIRE</div>
      <button type="button" className="mrp-home-start" onClick={onStart}><span className="mrp-home-start__play">▶</span>Start New Project</button>
      <div className="mrp-superpowers">{features.map((feature) => <article key={feature.title} className="mrp-superpower"><div className="mrp-superpower__icon"><SuperpowerIcon type={feature.type} /></div><strong>{feature.title}</strong><span>{feature.text}</span></article>)}</div>
    </div>
  </section>;
}


function mediaUrl(filePath: string): string { return `mrp-media://local?path=${encodeURIComponent(filePath)}`; }
function isVideoPath(filePath: string): boolean { return /\.(mp4|mov|mkv|webm|avi)$/i.test(filePath); }
function assetIsVisual(asset: LockedAsset): boolean { return /\.(png|jpe?g|webp|gif|mp4|mov|mkv|webm|avi)$/i.test(asset.metadata.extension || asset.path); }
function AssetLibraryPage({ assets, project, onRefresh, onMessage }: { assets: LockedAsset[]; project: ProjectData | null; onRefresh: () => Promise<void>; onMessage: (message: string) => void }): JSX.Element {
  const [editing, setEditing] = useState<LockedAsset | null>(null);
  const groups: Array<{ menu: LockedAssetMenu; title: string; subtitle: string }> = [
    { menu: 'intro', title: 'Intro', subtitle: 'Opening media tersimpan' },
    { menu: 'overlay', title: 'Overlay', subtitle: 'Layer visual tersimpan' },
    { menu: 'stickerSubscribe', title: 'Sticker Subscribe', subtitle: 'Sticker tersimpan' },
  ];
  async function add(menu: LockedAssetMenu): Promise<void> { try { const asset = await window.magicRender.lockAsset(menu); if (!asset) return; onMessage(`Asset ${asset.metadata.originalName} ditambahkan.`); await onRefresh(); } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menambahkan asset.'); } }
  async function togglePin(asset: LockedAsset): Promise<void> { try { await window.magicRender.updateLockedAsset(asset.assetId, { pinned: asset.pinned === false }); await onRefresh(); } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal mengubah kunci asset.'); } }
  async function remove(asset: LockedAsset): Promise<void> { try { await window.magicRender.unlockAsset(asset.assetId); onMessage(`${asset.metadata.originalName} di-unlock dan dihapus dari library.`); await onRefresh(); } catch (error) { onMessage(error instanceof Error ? error.message : 'Gagal menghapus asset.'); } }
  return <section className="mrp-simple-page"><div className="mrp-simple-page__hero"><span className="mrp-kicker">Library</span><h1>Asset Library</h1><p>Atur tampilan overlay dan sticker sekali di sini. Gembok dapat dibuka tanpa menghapus asset; tombol × menghapusnya dari daftar.</p></div><div className="mrp-asset-grid">{groups.map((group) => { const groupAssets = assets.filter((asset) => asset.menu === group.menu); return <article key={group.menu} className="mrp-asset-card"><header><div><span className="mrp-kicker">{group.title}</span><h2>{group.subtitle}</h2></div><button type="button" className="mrp-btn mrp-btn--primary" onClick={() => void add(group.menu)}>＋ Tambah {group.title}</button></header><div className="mrp-asset-list">{groupAssets.length === 0 ? <div className="mrp-inline-note">Belum ada asset tersimpan.</div> : groupAssets.map((asset) => <div key={asset.assetId} className="mrp-asset-item mrp-asset-item--visual"><div className="mrp-asset-thumb">{assetIsVisual(asset) ? (/\.(mp4|mov|mkv|webm|avi)$/i.test(asset.metadata.extension) ? <video src={mediaUrl(asset.path)} muted playsInline preload="metadata" /> : <img src={mediaUrl(asset.path)} alt={asset.metadata.originalName} />) : <span>MEDIA</span>}</div><div className="mrp-asset-item__copy"><strong>{asset.metadata.originalName}</strong><span>{asset.path}</span></div><div className="mrp-asset-item__actions">{asset.menu !== 'intro' && <button type="button" className="mrp-lock-button" aria-label={`Edit preset ${asset.metadata.originalName}`} title="Edit ukuran dan tampilan" onClick={() => setEditing(asset)}>✎</button>}<button type="button" className={`mrp-lock-button${asset.pinned !== false ? ' is-locked' : ''}`} aria-label={asset.pinned === false ? 'Kunci asset' : 'Buka kunci asset'} title={asset.pinned === false ? 'Kunci asset' : 'Buka kunci asset'} onClick={() => void togglePin(asset)}><PreviewLockIcon locked={asset.pinned !== false} /></button><button type="button" className="mrp-lock-button mrp-lock-button--delete" aria-label={`Hapus asset ${asset.metadata.originalName}`} title="Hapus dari library" onClick={() => void remove(asset)}>×</button></div></div>)}</div></article>; })}<TracklistManager onMessage={onMessage}/></div>{editing && <AssetVisualEditor key={editing.assetId} asset={editing} mainMedia={project?.mainMedia ?? null} onSaved={onRefresh} onClose={() => setEditing(null)} onMessage={onMessage} />}</section>;
}

function RenderPage({ project, setProject, renderTab, setRenderTab, recent, setRecent, onRemoveRecent, onCreateProject, onRenameProject, onLoadProject, onSaveProject, onImportMedia, onOpenFolder, renderProgress, etaRemaining, renderInFlight, bulkBusy, consoleEntries, lastRenderOutputPath, seoStatus, seoInFlight, seoResult, onSeoStatus, onMessage, onOpenSettings, startRender, controlRender, resetCompletedRender, resetting }: {
  project: ProjectData | null;
  setProject: (project: ProjectData, options?: HistoryOptions) => void;
  renderTab: RenderTab;
  setRenderTab: (tab: RenderTab) => void;
  recent: RecentProject[];
  setRecent: (items: RecentProject[]) => void;
  onRemoveRecent: (projectId: string) => Promise<void>;
  onCreateProject: () => void;
  onRenameProject: () => void;
  onLoadProject: () => Promise<void>;
  onSaveProject: () => Promise<void>;
  onImportMedia: () => Promise<void>;
  onOpenFolder: () => Promise<void>;
  renderProgress: RenderProgress | null;
  etaRemaining: number | null;
  renderInFlight: boolean;
  bulkBusy: boolean;
  consoleEntries: ConsoleLogEntry[];
  lastRenderOutputPath: string | null;
  seoStatus: string;
  seoInFlight: boolean;
  seoResult: YoutubeSeoResult | null;
  onSeoStatus: (status: string) => void;
  onMessage: (message: string) => void;
  onOpenSettings: () => void;
  startRender: () => Promise<void>;
  controlRender: (action: 'pause' | 'resume' | 'cancel') => Promise<void>;
  resetCompletedRender: () => void;
  resetting: boolean;
}): JSX.Element {
  const hiddenLayers = new Set<string>([
    ...(project?.overlays ?? []).filter((item) => item.hiddenInPreview).map((item) => `overlay:${item.id}`),
    ...(project?.stickerSubscribes?.length ? project.stickerSubscribes : project?.stickerSubscribe ? [project.stickerSubscribe] : []).filter((item) => item.hiddenInPreview).map((item) => `sticker:${item.id}`),
  ]);
  const toggleLayer = (key: string) => {
    if (!project) return;
    const [kind, id] = key.split(':');
    if (kind === 'overlay') setProject({ ...project, overlays: project.overlays.map((item) => item.id === id ? { ...item, hiddenInPreview: !item.hiddenInPreview } : item) });
    if (kind === 'sticker') {
      const stickers = project.stickerSubscribes?.length ? project.stickerSubscribes : project.stickerSubscribe ? [project.stickerSubscribe] : [];
      const next = stickers.map((item) => item.id === id ? { ...item, hiddenInPreview: !item.hiddenInPreview } : item);
      setProject({ ...project, stickerSubscribe: next[0] ?? null, stickerSubscribes: next });
    }
  };
  const noProject = <div className="mrp-empty-state"><div className="mrp-empty-state__icon">+</div><h3>Project belum dibuka</h3><p>Buat project baru atau buka kembali project yang pernah digunakan.</p><div className="mrp-empty-state__actions"><button type="button" className="mrp-btn mrp-btn--primary" onClick={onCreateProject}>New Project</button><button type="button" className="mrp-btn" onClick={() => void onLoadProject()}>Open Project</button></div><div className="mrp-recent-empty-list"><div className="mrp-kicker">Recent Projects</div>{recent.length === 0 ? <div className="mrp-inline-note">Belum ada project tersimpan.</div> : recent.map((item) => <div key={item.projectId} className="mrp-recent-item"><div className="mrp-recent-thumb">{item.mainMediaPath ? (isVideoPath(item.mainMediaPath) ? <video src={mediaUrl(item.mainMediaPath)} muted playsInline preload="metadata" /> : <img src={mediaUrl(item.mainMediaPath)} alt="" />) : <span>PROJECT</span>}</div><button type="button" className="mrp-recent-open" onClick={() => void window.magicRender.loadProject(item.projectFilePath).then((result) => { if (result) { setProject(result.project, { mode: 'replace', label: 'Load recent project' }); setRecent(result.recentProjects); onMessage(`Loaded: ${result.project.name}`); } }).catch((error) => onMessage(error instanceof Error ? error.message : 'Gagal membuka project.'))}><strong>{item.name}</strong><span>{item.projectFilePath}</span></button><button type="button" className="mrp-btn mrp-btn--danger" onClick={() => void onRemoveRecent(item.projectId)}>Hapus</button></div>)}</div></div>;
  const mediaPage = project ? <div className="space-y-3"><div className="mrp-section-card"><div className="mrp-card-title-row"><div><span className="mrp-kicker">Project</span><h3>{project.name}</h3></div><span className="mrp-status-pill">READY</span></div><div className="mrp-action-grid mrp-action-grid--media"><button type="button" className="mrp-btn mrp-btn--primary" onClick={onCreateProject}>New</button><button type="button" className="mrp-btn" onClick={() => void onLoadProject()}>Open</button><button type="button" className="mrp-btn" onClick={onRenameProject}>Rename</button><button type="button" className="mrp-btn" onClick={() => void onSaveProject()}>Save</button><button type="button" className="mrp-btn" onClick={() => void onImportMedia()}>Import Media</button><button type="button" className="mrp-btn" onClick={() => void onOpenFolder()}>Open Folder</button></div>{project.mainMedia ? <div className="mrp-media-summary"><div className="mrp-media-summary__name">{project.mainMedia.path}</div><div className="mrp-media-summary__meta"><span>{project.mainMedia.type}</span><span>{project.mainMedia.metadata?.resolution?.width ?? '?'}×{project.mainMedia.metadata?.resolution?.height ?? '?'}</span><span>{project.mainMedia.durationSeconds?.toFixed(2) ?? '0.00'}s</span></div><label className="mt-3 block text-xs">Nama file video setelah export<input className="mt-1 w-full rounded-lg border border-white/10 bg-black/30 p-2" maxLength={120} value={project.exportFileName ?? ''} onChange={(e) => setProject({ ...project, exportFileName: e.target.value })} placeholder={`Kosong = ${project.name}.mp4`} /></label></div> : <div className="mrp-inline-note">Import gambar atau video untuk menampilkannya di Canvas Preview.</div>}</div>{project.mainMedia && <MainMediaControlsPanel project={project} onProjectChange={setProject} onReplaceMedia={onImportMedia} />}{project.mainMedia && <MainMediaEffectsPanel project={project} onProjectChange={setProject} />}<div className="mrp-section-card"><div className="mrp-card-title-row"><div><span className="mrp-kicker">Recent</span><h3>Recent Projects</h3></div></div>{recent.length === 0 ? <div className="mrp-inline-note">Belum ada recent project.</div> : <div className="mrp-recent-list">{recent.map((item) => <div key={item.projectId} className="mrp-recent-item"><div className="mrp-recent-thumb">{item.mainMediaPath ? (isVideoPath(item.mainMediaPath) ? <video src={mediaUrl(item.mainMediaPath)} muted playsInline preload="metadata" /> : <img src={mediaUrl(item.mainMediaPath)} alt="" />) : <span>PROJECT</span>}</div><button type="button" className="mrp-recent-open" onClick={() => void window.magicRender.loadProject(item.projectFilePath).then((result) => { if (result) { setProject(result.project, { mode: 'replace', label: 'Load recent project' }); setRecent(result.recentProjects); onMessage(`Loaded: ${result.project.name}`); } }).catch((error) => onMessage(error instanceof Error ? error.message : 'Gagal membuka project.'))}><strong>{item.name}</strong><span>{item.projectFilePath}</span></button><button type="button" className="mrp-btn mrp-btn--danger" onClick={() => void onRemoveRecent(item.projectId)}>Hapus</button></div>)}</div>}</div></div> : noProject;
  let control: JSX.Element;
  if (renderTab === 'Media') control = mediaPage;
  else if (!project) control = noProject;
  else if (renderTab === 'Intro') control = <IntroPanel project={project} onProjectChange={setProject} />;
  else if (renderTab === 'Overlay') control = <><OverlayPanel project={project} onProjectChange={setProject} hiddenLayers={hiddenLayers} onToggleLayer={toggleLayer} /><TextOverlayPanel project={project} onProjectChange={setProject} /><ParticleEffectsPanel project={project} onProjectChange={setProject} /><VisualizerPanel project={project} onProjectChange={setProject} /></>;
  else if (renderTab === 'Playlist') control = <PlaylistPanel project={project} onProjectChange={setProject} />;
  else if (renderTab === 'Sticker Subscribe') control = <StickerPanel project={project} onProjectChange={setProject} hiddenLayers={hiddenLayers} onToggleLayer={toggleLayer} />;
  else control = <YoutubeSeoPanel project={project} onProjectChange={setProject} onMessage={onMessage} onOpenSettings={onOpenSettings} statusLine={seoStatus} autoGenerating={seoInFlight} latestResult={seoResult} onStatus={onSeoStatus} />;
  if (renderInFlight && renderTab !== 'Youtube SEO') control = <div className="mrp-inline-note">Kontrol media dijeda sementara FFmpeg bekerja. Panel YouTube SEO tetap tersedia untuk memantau analisis.</div>;

  return <section className="mrp-render-page"><aside className="mrp-render-nav"><div className="mrp-render-nav__title">RENDER WORKSPACE</div>{renderTabs.map((tab) => <button key={tab} type="button" className={`mrp-render-nav__item${renderTab === tab ? ' is-active' : ''}`} onClick={() => setRenderTab(tab)}><span>{({ Media: '▣', Intro: '▶', Overlay: '◈', Playlist: '≋', 'Sticker Subscribe': '☆', 'Youtube SEO': '⌕' } as Record<RenderTab,string>)[tab]}</span><strong>{tab}</strong></button>)}</aside><section className="mrp-render-controls"><div className="mrp-panel-title"><div><span className="mrp-panel-title__eyebrow">{renderTab}</span><h2>{project?.name ?? 'Workspace'}</h2></div>{project && <span className="mrp-panel-title__project">{project.mainMedia ? 'Media loaded' : 'No media'}</span>}</div>{control}</section><section className="mrp-render-right"><div className="mrp-canvas-head"><div><span className="mrp-kicker">Preview</span><h2>Canvas Preview</h2></div><span className="mrp-preview-badge">16:9</span></div><div className="mrp-canvas-body">{project ? renderInFlight ? <div className="mrp-preview-placeholder"><strong>Preview dijeda selama render</strong><span>Komposisi akan tampil kembali setelah render selesai.</span></div> : <CanvasPreview project={project} onProjectChange={setProject} onInfo={onMessage} hiddenLayers={hiddenLayers} /> : <div className="mrp-preview-placeholder"><img src="./assets/magic-render-pro-logo.png" alt="Magic Render Pro"/><strong>Start a project</strong><span>Buka menu Media untuk membuat project.</span></div>}</div><div className="mrp-below-canvas"><div className="mrp-section-card mrp-render-monitor"><div className="mrp-card-title-row"><div><span className="mrp-kicker">Render</span><h3>Render Monitor</h3></div><div className="flex flex-wrap items-center gap-2"><span className="mrp-status-pill">{renderInFlight && renderProgress?.status === 'idle' ? 'menyiapkan' : renderProgress?.status ?? 'idle'}</span>{renderProgress?.status === 'done' && lastRenderOutputPath && <><button type="button" className="mrp-btn" onClick={() => void window.magicRender.openProjectFolder(lastRenderOutputPath.replace(/[\\/][^\\/]+$/, '')).catch((error) => onMessage(error instanceof Error ? error.message : String(error)))}>Buka Folder</button><button type="button" className="mrp-btn" onClick={() => void window.magicRender.openOutputVideo(lastRenderOutputPath).catch((error) => onMessage(error instanceof Error ? error.message : String(error)))}>▶ Buka Video</button><button type="button" className="mrp-btn" title="Reset tugas render selesai; file video tetap tersimpan" onClick={resetCompletedRender}>↺ Reset</button></>}</div></div><div className="mrp-progress" role="progressbar" aria-valuenow={renderProgress?.percent ?? 0} aria-valuemin={0} aria-valuemax={100}><div style={{ width: `${renderProgress?.percent ?? 0}%` }} /></div><div className="mrp-stats"><span><b>{(renderProgress?.percent ?? 0).toFixed(1)}%</b><small>Progress</small></span><span><b>{formatSeconds(renderProgress?.totalDurationSec || estimatedVideoDuration(project))}</b><small>Total Durasi Video</small></span><span><b>{formatSeconds(renderProgress?.elapsedRenderSec ?? 0)}</b><small>Waktu Render</small></span><span><b>{renderProgress?.speedMultiplier ? `${renderProgress.speedMultiplier.toFixed(2)}×` : '—'}</b><small>Speed</small></span><span><b>{renderProgress?.status === 'done' ? 'Selesai' : renderInFlight && renderProgress?.status === 'compressing_video' && (renderProgress.percent >= 95 || renderProgress.currentTimeSec >= renderProgress.totalDurationSec * .995) ? 'Finalisasi' : etaRemaining === null ? '—' : formatSeconds(etaRemaining)}</b><small>Estimasi tersisa</small></span></div><div className="mrp-monitor-actions"><button type="button" className="mrp-btn mrp-btn--primary" onClick={() => void startRender()} disabled={!project || renderInFlight || bulkBusy || resetting || (!!renderProgress && !['idle','done','error','cancelled'].includes(renderProgress.status))}>Render</button><button type="button" className="mrp-btn" onClick={() => void controlRender(renderProgress?.status === 'paused' ? 'resume' : 'pause')} disabled={!project || !renderInFlight || resetting}>{renderProgress?.status === 'paused' ? 'Lanjutkan' : 'Pause'}</button><button type="button" className="mrp-btn mrp-btn--danger" onClick={() => void controlRender('cancel')} disabled={!project || !renderInFlight || resetting}>{resetting ? 'Membatalkan...' : 'Cancel'}</button></div>{renderProgress?.logLine && <div className="mrp-inline-note">{renderProgress.logLine}</div>}</div><ConsoleLogPanel entries={consoleEntries} /></div></section></section>;
}

function AppContent(): JSX.Element {
  const [mainPage, setMainPage] = useState<MainPage>('Home');
  const [renderTab, setRenderTab] = useState<RenderTab>('Media');
  const { project, setProject: recordProject, replaceProject } = useProjectHistory();
  const setProject = (next: ProjectData, options?: HistoryOptions): void => recordProject(next, options);
  const [recent, setRecent] = useState<RecentProject[]>([]);
  const [message, setMessage] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const [lockedAssets, setLockedAssets] = useState<LockedAsset[]>([]);
  const [renderProgress, setRenderProgress] = useState<RenderProgress | null>(null);
  const [renderInFlight, setRenderInFlight] = useState(false);
  const [resetting, setResetting] = useState(false);
  const renderSession = useRef(0);
  const renderStartedAt = useRef(0);
  const renderPausedAt = useRef(0);
  const renderPausedMs = useRef(0);
  const lastProgressUiAt = useRef(0);
  const lastBulkUiAt = useRef(0);
  const lastConsoleProgressAt = useRef(0);
  const completionAudio = useRef<AudioContext | null>(null);
  const latestProgress = useRef<RenderProgress | null>(null);
  const etaSnapshot = useRef<EtaSnapshot | null>(null);
  const [completion, setCompletion] = useState<RenderCompletion | null>(null);
  const [consoleEntries, setConsoleEntries] = useState<ConsoleLogEntry[]>([]);
  const [lastRenderOutputPath, setLastRenderOutputPath] = useState<string | null>(null);
  const [seoStatus, setSeoStatus] = useState('SEO belum dijalankan.');
  const [seoInFlight, setSeoInFlight] = useState(false);
  const [seoResult, setSeoResult] = useState<YoutubeSeoResult | null>(null);
  const [showCreateProjectDialog, setShowCreateProjectDialog] = useState(false);
  const [showImportPrompt, setShowImportPrompt] = useState(false);
  const [pendingResolutionProject, setPendingResolutionProject] = useState<ProjectData | null>(null);
  const [showRenameProjectDialog, setShowRenameProjectDialog] = useState(false);
  const [newProjectName, setNewProjectName] = useState('My Render Project');
  const [bulkMedia,setBulkMedia]=useState<BulkMediaItem[]>([]);
  const [bulkTracklistId,setBulkTracklistId]=useState('');
  const [bulkMp3Count,setBulkMp3Count]=useState(3);
  const [bulkOptions,setBulkOptions]=useState<BulkRenderOptions>({overlay:false,intro:false,fadeIn:false,fadeInSec:1,fadeInStyle:'dark',fadeInBlur:12,fadeInBrightness:-0.25,fadeOut:false,fadeOutSec:1,sticker:false,stickerDurationSec:null,stickerSchedule:{mode:'full-duration',iterativeCount:null,timestamps:[]}});
  const [bulkBusy,setBulkBusy]=useState(false);
  const [bulkResults,setBulkResults]=useState<BulkItemResult[]>([]);
  const bulkCancelled=useRef(false);
  const bulkRunRef=useRef(false);
  const currentBulkProject=useRef<string|null>(null);
  const bulkProjectToMedia=useRef<Map<string,string>>(new Map());
  const activeProjectId=useRef<string|null>(null);
  activeProjectId.current=project?.projectId??null;
  useEffect(() => { setSeoResult(null); setSeoStatus('SEO belum dijalankan.'); }, [project?.projectId]);

  useEffect(() => {
    if (!message) return;
    setToastVisible(true);
    const timer = window.setTimeout(() => setToastVisible(false), 5000);
    return () => window.clearTimeout(timer);
  }, [message]);
  useEffect(() => { if (!completion) return; const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') setCompletion(null); }; window.addEventListener('keydown', escape); return () => window.removeEventListener('keydown', escape); }, [completion]);

  async function refreshAssets(): Promise<void> {
    try { setLockedAssets(await window.magicRender.listLockedAssets()); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal memuat asset library.'); }
  }

  useEffect(() => {
    void window.magicRender.getRecentProjects().then(setRecent).catch(() => setRecent([]));
    void refreshAssets();
    const unsubscribeProgress = window.magicRender.onRenderProgress((progress) => {
      const terminal = ['done', 'error', 'cancelled', 'paused'].includes(progress.status);
      const now = Date.now();
      if (progress.projectId === activeProjectId.current) {
        latestProgress.current = progress;
        if (terminal || now - lastProgressUiAt.current >= 300 || progress.status === 'idle') {
          lastProgressUiAt.current = now;
          setRenderProgress((previous) => mergeRenderProgress(previous, progress));
        }
      }
      const mediaId = bulkProjectToMedia.current.get(progress.projectId);
      if (mediaId && (terminal || now - lastBulkUiAt.current > 500)) { lastBulkUiAt.current = now; setBulkResults((items) => items.map((item) => item.id === mediaId ? { ...item, percent: progress.percent, currentTimeSec:progress.currentTimeSec, totalDurationSec:progress.totalDurationSec, speedMultiplier:progress.speedMultiplier, status: progress.status === 'error' ? 'error' : progress.status === 'cancelled' ? 'cancelled' : progress.status === 'done' ? 'done' : 'rendering', error: progress.errorMessage ?? item.error } : item)); }
      const routineProgress = /%.*×/.test(progress.logLine);
      if (terminal || !routineProgress || now - lastConsoleProgressAt.current > 3000) {
        if (routineProgress) lastConsoleProgressAt.current = now;
        setConsoleEntries((entries) => appendConsoleEntry(entries, progress));
      }
    });
    const unsubscribeLogs = window.magicRender.onApplicationLog((entry) => {
      setConsoleEntries((entries) => appendApplicationLog(entries, entry));
      if (entry.message.startsWith('[AI SEO]')) setSeoStatus(entry.message.replace(/^\[AI SEO\]\s*/, ''));
    });
    const unsubscribeSeo = window.magicRender.onSeoResult((value) => {
      if (value.projectId !== activeProjectId.current) return;
      setSeoResult(value);
      setSeoStatus(`Selesai • ${value.titles.length} judul • ${value.outputFiles.seoTxt}`);
    });
    void window.magicRender.getRecentApplicationLogs().then((logs) => setConsoleEntries((entries) => logs.reduce(appendApplicationLog, entries))).catch(() => undefined);
    const onWindowError = (event: ErrorEvent): void => { void window.magicRender.logActivity('ERROR', 'Unhandled renderer error.', event.error instanceof Error ? event.error.stack ?? event.error.message : event.message); };
    const onUnhandledRejection = (event: PromiseRejectionEvent): void => { const detail = event.reason instanceof Error ? event.reason.stack ?? event.reason.message : String(event.reason); void window.magicRender.logActivity('ERROR', 'Unhandled renderer promise rejection.', detail); };
    window.addEventListener('error', onWindowError); window.addEventListener('unhandledrejection', onUnhandledRejection);
    return () => { unsubscribeProgress(); unsubscribeLogs(); unsubscribeSeo(); window.removeEventListener('error', onWindowError); window.removeEventListener('unhandledrejection', onUnhandledRejection); };
  }, []);

  useEffect(() => {
    if (!project || !renderInFlight) return;
    let disposed = false;
    const refresh = () => void window.magicRender.getRenderProgress(project.projectId).then((progress) => {
      if (disposed || !progress || progress.projectId !== activeProjectId.current) return;
      latestProgress.current = progress;
      setRenderProgress((previous) => mergeRenderProgress(previous, progress));
    }).catch(() => undefined);
    const poll = window.setInterval(refresh, 3000);
    const clock = window.setInterval(() => setRenderProgress((previous) => {
      if (!previous || previous.projectId !== project.projectId || ['done', 'error', 'cancelled', 'paused'].includes(previous.status)) return previous;
      const elapsed = Math.floor((Date.now() - renderStartedAt.current - renderPausedMs.current) / 1000);
      return Math.floor(previous.elapsedRenderSec) === elapsed ? previous : { ...previous, elapsedRenderSec: Math.max(previous.elapsedRenderSec, elapsed) };
    }), 1000);
    return () => { disposed = true; window.clearInterval(poll); window.clearInterval(clock); };
  }, [project?.projectId, renderInFlight]);

  function createProject(): void { setNewProjectName('My Render Project'); setShowCreateProjectDialog(true); }
  async function confirmCreateProject(): Promise<void> { const name = newProjectName.trim(); if (!name) { setMessage('Nama project wajib diisi.'); return; } try { const result = await window.magicRender.createProject(name); if (!result) return; replaceProject(result.project); setRecent(result.recentProjects); setShowCreateProjectDialog(false); setShowImportPrompt(true); setMainPage('Render'); setRenderTab('Media'); setMessage(`Project dibuat. Export akan disimpan di ${result.project.settings.outputDir}`); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membuat project.'); } }
  function renameProject(): void { if (!project) return; setNewProjectName(project.name); setShowRenameProjectDialog(true); }
  async function confirmRenameProject(): Promise<void> { if (!project || !newProjectName.trim()) return; try { const result = await window.magicRender.saveProject({ ...project, name: newProjectName.trim() }); setProject(result.project, { label: 'Rename project' }); setRecent(result.recentProjects); setShowRenameProjectDialog(false); setMessage(`Nama project: ${result.project.name}`); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal mengganti nama project.'); } }
  async function loadProject(): Promise<void> { try { const result = await window.magicRender.loadProject(); if (!result) return; replaceProject(result.project); setRecent(result.recentProjects); setMainPage('Render'); setRenderTab('Media'); setMessage(`Loaded: ${result.project.name}`); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membuka project.'); } }
  async function removeRecentProject(projectId: string): Promise<void> {
    if (project?.projectId === projectId && (renderInFlight || bulkBusy)) { setMessage('Hentikan render sebelum menghapus project aktif.'); return; }
    try {
      const next = await window.magicRender.removeRecentProject(projectId);
      setRecent(next);
      if (project?.projectId === projectId) replaceProject(null);
      setMessage('Project dan berkas kerja dihapus. Asset serta hasil export tetap tersimpan.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menghapus project.'); }
  }
  async function saveProject(): Promise<void> { if (!project) { setMessage('Belum ada project aktif.'); return; } try { const result = await window.magicRender.saveProject(project); setProject(result.project, { mode: 'replace', label: 'Save project' }); setRecent(result.recentProjects); setMessage('Project saved.'); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menyimpan project.'); } }
  async function importMedia(): Promise<void> { if (!project) { setMessage('Buat atau buka project terlebih dahulu.'); return; } try { const result = await window.magicRender.importMainMedia(project); if (!result) return; setProject(result.project, { label: 'Import main media' }); setRecent(result.recentProjects); setPendingResolutionProject(result.project); setMessage('Media utama diimpor. Pilih resolusi output dan canvas.'); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal import media.'); } }
  async function chooseImportedResolution(resolution: '720p' | '1080p'): Promise<void> { const pending = pendingResolutionProject; if (!pending) return; try { const updated = { ...pending, settings: { ...pending.settings, resolution } }; const stored = await window.magicRender.saveProject(updated); const saved = await window.magicRender.updateSettings({ resolution }); setProject({ ...stored.project, settings: { ...stored.project.settings, resolution: saved.resolution } }, { label: 'Choose canvas resolution' }); setRecent(stored.recentProjects); setPendingResolutionProject(null); setMessage(`Canvas dan output dipilih: ${resolution}.`); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal menyimpan resolusi.'); } }
  async function openFolder(): Promise<void> { if (!project) { setMessage('Belum ada project aktif.'); return; } try { await window.magicRender.openProjectFolder(project.projectDir); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membuka folder.'); } }
  function playCompletionSound(): void {
    const context = completionAudio.current;
    if (!context) return;
    void context.resume().then(() => {
      for (const [index, frequency] of [660, 880].entries()) {
        const oscillator = context.createOscillator(); const gain = context.createGain();
        const start = context.currentTime + index * 0.18;
        oscillator.type = 'sine'; oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.12, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.16);
        oscillator.connect(gain); gain.connect(context.destination);
        oscillator.start(start); oscillator.stop(start + 0.17);
      }
    }).catch(() => undefined);
  }
  async function startRender(): Promise<void> {
    if (bulkRunRef.current) { setMessage('Bulk Render sedang berjalan. Tunggu hingga antrean selesai.'); return; }
    if (!project) { setMessage('Buka project terlebih dahulu.'); return; }
    try { completionAudio.current ??= new AudioContext(); void completionAudio.current.resume(); } catch { /* Playback policy may block sounds. */ }
    const session = ++renderSession.current;
    renderStartedAt.current = Date.now(); renderPausedAt.current = 0; renderPausedMs.current = 0;
    etaSnapshot.current = null; latestProgress.current = null; setCompletion(null); setLastRenderOutputPath(null); setRenderInFlight(true);
    const starting: RenderProgress = { projectId: project.projectId, status: 'idle', percent: 0, currentTimeSec: 0, totalDurationSec: estimatedVideoDuration(project), speedMultiplier: 0, elapsedRenderSec: 0, logLine: '[SISTEM] Permintaan render dikirim. Menyiapkan media dan output...', errorMessage: null };
    setRenderProgress(starting); setConsoleEntries((entries) => appendConsoleEntry(entries, starting));
    window.setTimeout(() => {
      if (renderSession.current !== session) return;
      setRenderProgress((previous) => previous?.projectId === project.projectId && previous.logLine === starting.logLine
        ? { ...previous, logLine: '[PERSIAPAN] Belum ada jawaban dari proses utama. Periksa Console Log dan Path FFmpeg/FFprobe di Settings. Cancel tetap tersedia.' } : previous);
    }, 12_000);
    try {
      const renderTask = window.magicRender.startRender(project);
      if ((project.youtubeSEO.mode ?? 'timestamp') === 'timestamp-seo') {
        setSeoResult(null);
        setSeoInFlight(true);
        setSeoStatus('Render dimulai • menyiapkan analisis visual AI...');
        void window.magicRender.generateYoutubeSeo(project).then((value) => {
          if (session !== renderSession.current) return;
          setSeoResult(value);
          setSeoStatus(`Selesai • ${value.titles.length} judul • ${value.outputFiles.seoTxt}`);
        }).catch((error) => {
          if (session !== renderSession.current) return;
          const detail = error instanceof Error ? error.message : String(error);
          setSeoStatus(`Gagal • ${detail}`);
          setMessage(`SEO AI gagal: ${detail}`);
        }).finally(() => { if (session === renderSession.current) setSeoInFlight(false); });
      }
      const result = await renderTask;
      if (session !== renderSession.current) return;
      const progress = latestProgress.current as RenderProgress | null;
      setLastRenderOutputPath(result.outputPath);
      setCompletion({ outputPath: result.outputPath, durationSec: progress?.totalDurationSec || estimatedVideoDuration(project), elapsedSec: Math.max(0, (Date.now() - renderStartedAt.current - renderPausedMs.current) / 1000),
        resolution: project.settings.resolution, fps: project.settings.fps ?? 30, bitrateKbps: project.settings.bitrateKbps, fileSizeBytes: result.fileSizeBytes ?? null, overlays: project.overlays.length,
        intro: !!(project.intro.enabled && project.intro.path), stickers: project.stickerSubscribes?.length || (project.stickerSubscribe ? 1 : 0),
        renderDevice: result.renderDevice ?? 'cpu', gpu: result.gpu ?? { name: 'GPU tidak terdeteksi', vramMb: null, encoder: null } });
      playCompletionSound();
      setMessage((project.youtubeSEO.mode ?? 'timestamp') === 'timestamp-seo' ? 'Render selesai. Timestamp + YouTube SEO diproses.' : 'Render selesai. Timestamp dibuat tanpa konfigurasi AI.');
    } catch (error) {
      if (session !== renderSession.current) return;
      const detail = error instanceof Error ? error.message : 'Render gagal.';
      const cancelled = /dibatalkan|direset/i.test(detail);
      setMessage(detail);
      const failure: RenderProgress = { projectId: project.projectId, status: cancelled ? 'cancelled' : 'error', percent: 0, currentTimeSec: 0, totalDurationSec: 0, speedMultiplier: 0, elapsedRenderSec: 0, logLine: detail, errorMessage: cancelled ? null : detail };
      setRenderProgress((previous) => ({ ...failure, percent: previous?.percent ?? 0, currentTimeSec: previous?.currentTimeSec ?? 0, totalDurationSec: previous?.totalDurationSec ?? 0, elapsedRenderSec: previous?.elapsedRenderSec ?? 0 }));
      setConsoleEntries((entries) => appendConsoleEntry(entries, failure));
    } finally { if (session === renderSession.current) setRenderInFlight(false); }
  }
  async function controlRender(action: 'pause' | 'resume' | 'cancel'): Promise<void> {
    if (!project) return;
    if (action === 'cancel') {
      ++renderSession.current;
      etaSnapshot.current = null; setCompletion(null); setResetting(true); setRenderInFlight(false); setSeoInFlight(false);
      setRenderProgress({ projectId: project.projectId, status: 'cancelled', percent: 0, currentTimeSec: 0,
        totalDurationSec: estimatedVideoDuration(project), speedMultiplier: 0, elapsedRenderSec: 0,
        logLine: 'Membatalkan dan mengosongkan proses render...', errorMessage: null });
      try {
        const result = await window.magicRender.controlRender({ projectId: project.projectId, action: 'cancel' });
        if (!result.accepted) throw new Error('Pembatalan render tidak diterima.');
        setMessage('Render dibatalkan. Monitor siap untuk render baru.');
      } catch (error) { setMessage(error instanceof Error ? error.message : 'Pembatalan render gagal.'); }
      finally { setResetting(false); }
      return;
    }
    try {
      const result = await window.magicRender.controlRender({ projectId: project.projectId, action });
      if (result.accepted) {
        if (action === 'pause') renderPausedAt.current = Date.now();
        if (action === 'resume' && renderPausedAt.current) { renderPausedMs.current += Date.now() - renderPausedAt.current; renderPausedAt.current = 0; }
        setRenderProgress((previous) => previous?.projectId === project.projectId ? { ...previous, status: result.status, speedMultiplier: 0 } : previous);
      }
      setMessage(result.accepted ? action === 'pause' ? 'Render dijeda.' : 'Render dilanjutkan.' : 'Aksi render tidak diterima.');
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Kontrol render gagal.'); }
  }

  function resetCompletedRender(): void { if (renderInFlight || renderProgress?.status !== 'done') return; setRenderProgress(null); setLastRenderOutputPath(null); setCompletion(null); setConsoleEntries([]); etaSnapshot.current = null; setMessage('Tugas render selesai direset. File hasil tetap tersimpan.'); }
  async function openCompletedVideo(): Promise<void> { if (!completion) return; try { await window.magicRender.openOutputVideo(completion.outputPath); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membuka video.'); } }
  async function openCompletedFolder(): Promise<void> { if (!completion) return; try { await window.magicRender.openProjectFolder(completion.outputPath.replace(/[\\/][^\\/]+$/, '')); } catch (error) { setMessage(error instanceof Error ? error.message : 'Gagal membuka folder output.'); } }

  async function startBulk():Promise<void> {
    if (renderInFlight || bulkRunRef.current) { setMessage('Selesaikan proses render saat ini terlebih dahulu.'); return; }
    bulkRunRef.current=true;bulkCancelled.current=false;setBulkBusy(true);
    try {
      setMessage('Memeriksa media, MP3 dan asset untuk antrean...');
      const plans=await window.magicRender.prepareBulkRender({media:bulkMedia,tracklistId:bulkTracklistId,mp3Count:bulkMp3Count,options:bulkOptions});
      setBulkResults(plans.map((plan)=>({id:plan.media.id,name:plan.media.path.split(/[\\/]/).at(-1)??plan.media.path,status:'queued',percent:0})));
      bulkProjectToMedia.current=new Map(plans.map((plan)=>[plan.project.projectId,plan.media.id]));
      for (const plan of plans) {
        if (bulkCancelled.current) break;
        currentBulkProject.current=plan.project.projectId;
        setBulkResults((items)=>items.map((item)=>item.id===plan.media.id?{...item,status:'rendering',percent:0,currentTimeSec:0,totalDurationSec:plan.project.playlistTracks?.reduce((sum,track)=>sum+(track.durationSeconds??0),0)??0,speedMultiplier:0}:item));
        try {
          const result=await window.magicRender.startRender(plan.project);
          setBulkResults((items)=>items.map((item)=>item.id===plan.media.id?{...item,status:'done',percent:100,outputPath:result.outputPath,timestampPath:result.timestampPath}:item));
        } catch(error) {
          const message=error instanceof Error?error.message:String(error);
          setBulkResults((items)=>items.map((item)=>item.id===plan.media.id?{...item,status:bulkCancelled.current?'cancelled':'error',error:message}:item));
          if (!bulkCancelled.current) setMessage(`Bulk ${plan.media.path.split(/[\\/]/).at(-1)} gagal: ${message}`);
        } finally { currentBulkProject.current=null; }
      }
      if (bulkCancelled.current) setBulkResults((items)=>items.map((item)=>item.status==='queued'?{...item,status:'cancelled'}:item));
      setMessage(bulkCancelled.current?'Antrean Bulk Render dibatalkan.':'Antrean Bulk Render selesai. Periksa daftar hasil.');
    } catch(error) { setMessage(error instanceof Error?error.message:'Persiapan Bulk Render gagal.'); }
    finally {currentBulkProject.current=null;bulkRunRef.current=false;setBulkBusy(false);}
  }
  async function cancelBulk():Promise<void> { bulkCancelled.current=true; const id=currentBulkProject.current; if (id) { try { await window.magicRender.controlRender({projectId:id,action:'cancel'}); } catch(error) { setMessage(error instanceof Error?error.message:'Gagal membatalkan render saat ini.'); } } else setMessage('Antrean berhenti setelah persiapan selesai.'); }

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent): void => {
      const modal = !!document.querySelector('[role="dialog"]');
      const interactive = event.target instanceof HTMLElement && !!event.target.closest('button, a, [role="button"]');
      const action = editorShortcut(event, isEditingField(event.target) || interactive, modal);
      if (!action) return;
      if (action === 'escape') {
        if (!modal) return;
        event.preventDefault();
        if (completion) setCompletion(null);
        else if (showCreateProjectDialog) setShowCreateProjectDialog(false);
        else if (showRenameProjectDialog) setShowRenameProjectDialog(false);
        else window.dispatchEvent(new Event('mrp:close-modal'));
        return;
      }
      event.preventDefault();
      if (action === 'save') {
        const formSave = document.querySelector<HTMLButtonElement>('[role="dialog"] [data-shortcut-save], .mrp-settings-grid [data-shortcut-save]');
        if (formSave && !formSave.disabled) formSave.click();
        else if (!modal) void saveProject();
        return;
      }
      if (action === 'help') { setMainPage('Help'); return; }
      if (action.startsWith('page-')) { const pages: MainPage[] = ['Home','Render','Bulk Render','Asset','Setting','Help']; setMainPage(pages[Number(action.slice(5)) - 1]!); return; }
      if (action.startsWith('tab-')) { setMainPage('Render'); setRenderTab(renderTabs[Number(action.slice(4)) - 1]!); return; }
      if (action === 'new') { createProject(); return; }
      if (action === 'open') { void loadProject(); return; }
      if (action === 'import') { void importMedia(); return; }
      if (action === 'render') { if (mainPage === 'Bulk Render') void startBulk(); else if (mainPage === 'Render') void startRender(); return; }
      if (action === 'pause') { if (renderInFlight) void controlRender(renderProgress?.status === 'paused' ? 'resume' : 'pause'); return; }
      if (action === 'cancel') { if (bulkBusy) void cancelBulk(); else if (renderInFlight) void controlRender('cancel'); return; }
      if (mainPage === 'Render' && !renderInFlight) window.dispatchEvent(new CustomEvent('mrp:preview-action', { detail: { action, step: event.shiftKey ? 10 : 1 } }));
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const eta = countdownEta(renderProgress, etaSnapshot.current);
  etaSnapshot.current = eta.snapshot;

  const mainNav = <MainNav activeTab={mainPage} onSelect={(page) => { setMainPage(page); if (page === 'Render') setRenderTab('Media'); }} />;
  const page = mainPage === 'Home'
    ? <HomePage onStart={createProject} />
    : mainPage === 'Render'
      ? <RenderPage project={project} setProject={setProject} renderTab={renderTab} setRenderTab={setRenderTab} recent={recent} setRecent={setRecent} onRemoveRecent={removeRecentProject} onCreateProject={createProject} onRenameProject={renameProject} onLoadProject={loadProject} onSaveProject={saveProject} onImportMedia={importMedia} onOpenFolder={openFolder} renderProgress={renderProgress} etaRemaining={eta.seconds} renderInFlight={renderInFlight} bulkBusy={bulkBusy} consoleEntries={consoleEntries} lastRenderOutputPath={lastRenderOutputPath} seoStatus={seoStatus} seoInFlight={seoInFlight} seoResult={seoResult} onSeoStatus={setSeoStatus} onMessage={setMessage} onOpenSettings={() => setMainPage('Setting')} startRender={startRender} controlRender={controlRender} resetCompletedRender={resetCompletedRender} resetting={resetting} />
      : mainPage === 'Bulk Render'
        ? <BulkRenderPage media={bulkMedia} setMedia={setBulkMedia} options={bulkOptions} setOptions={setBulkOptions} tracklistId={bulkTracklistId} setTracklistId={setBulkTracklistId} mp3Count={bulkMp3Count} setMp3Count={setBulkMp3Count} busy={bulkBusy} results={bulkResults} onStart={startBulk} onCancel={cancelBulk} onResetResult={(id) => setBulkResults((items) => items.map((item) => item.id === id ? { ...item, status: 'queued', percent: 0, outputPath: undefined, timestampPath: undefined, error: undefined } : item))} onCloseResult={(id) => setBulkResults((items) => items.filter((item) => item.id !== id))} onMessage={setMessage}/>
      : mainPage === 'Asset'
        ? <AssetLibraryPage assets={lockedAssets} project={project} onRefresh={refreshAssets} onMessage={setMessage} />
        : mainPage === 'Setting'
          ? <section className="mrp-simple-page"><div className="mrp-simple-page__hero"><span className="mrp-kicker">Configuration</span><h1>Settings</h1><p>Pengaturan global FFmpeg, folder project, output, CPU/GPU, dan AI.</p></div><SettingsPanel project={project} onProjectChange={(next, options) => setProject(next, options)} onMessage={setMessage} /></section>
          : <HelpPage />;

  return <>
    {toastVisible && <div className="mrp-toast" role="status" aria-live="polite"><div className="mrp-toast__body">{message}</div><button type="button" className="mrp-toast__close" aria-label="Close notification" onClick={() => setToastVisible(false)}>×</button></div>}
    {showCreateProjectDialog && <div className="mrp-dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowCreateProjectDialog(false); }}><div className="mrp-dialog" role="dialog" aria-modal="true" aria-labelledby="create-project-title"><div id="create-project-title" className="mrp-dialog__title">New Project</div><p>Masukkan nama project baru.</p><input autoFocus maxLength={120} value={newProjectName} onChange={(event) => setNewProjectName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') void confirmCreateProject(); if (event.key === 'Escape') setShowCreateProjectDialog(false); }} /><div className="mrp-dialog__actions"><button type="button" className="mrp-btn" onClick={() => setShowCreateProjectDialog(false)}>Cancel</button><button type="button" className="mrp-btn mrp-btn--primary" onClick={() => void confirmCreateProject()}>Create</button></div></div></div>}
    {showRenameProjectDialog && <div className="mrp-dialog-backdrop"><div className="mrp-dialog" role="dialog" aria-modal="true" aria-labelledby="rename-project-title"><div id="rename-project-title" className="mrp-dialog__title">Rename Project</div><p>Nama file export mengikuti nama baru jika kolom nama export kosong.</p><input autoFocus maxLength={120} value={newProjectName} onChange={(event) => setNewProjectName(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') void confirmRenameProject(); if (event.key === 'Escape') setShowRenameProjectDialog(false); }} /><div className="mrp-dialog__actions"><button type="button" className="mrp-btn" onClick={() => setShowRenameProjectDialog(false)}>Batal</button><button type="button" className="mrp-btn mrp-btn--primary" onClick={() => void confirmRenameProject()}>Simpan Nama</button></div></div></div>}
    {pendingResolutionProject && <div className="mrp-dialog-backdrop"><div className="mrp-dialog" role="dialog" aria-modal="true" aria-labelledby="resolution-prompt-title"><div id="resolution-prompt-title" className="mrp-dialog__title">Ukuran canvas setelah import</div><p>Pilih resolusi video dan canvas preview. Posisi layer tetap mengikuti proporsi canvas.</p><div className="mrp-dialog__actions"><button type="button" className="mrp-btn" onClick={() => void chooseImportedResolution('720p')}>720p • 1280×720</button><button type="button" autoFocus className="mrp-btn mrp-btn--primary" onClick={() => void chooseImportedResolution('1080p')}>1080p • 1920×1080</button></div></div></div>}
    {showImportPrompt && <div className="mrp-dialog-backdrop"><div className="mrp-dialog" role="dialog" aria-modal="true" aria-labelledby="import-prompt-title"><div id="import-prompt-title" className="mrp-dialog__title">Project siap</div><p>Import gambar atau video utama sekarang?</p><div className="mrp-dialog__actions"><button type="button" className="mrp-btn" onClick={() => setShowImportPrompt(false)}>Nanti</button><button type="button" autoFocus className="mrp-btn mrp-btn--primary" onClick={() => { setShowImportPrompt(false); void importMedia(); }}>Import Media</button></div></div></div>}
    {completion && <div className="mrp-dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setCompletion(null); }}><div className="mrp-dialog mrp-render-complete" role="dialog" aria-modal="true" aria-labelledby="render-complete-title"><div className="mrp-render-complete__head"><div><span className="mrp-kicker">Render selesai</span><h2 id="render-complete-title">Video siap diputar</h2></div><button type="button" autoFocus className="mrp-render-complete__close" aria-label="Tutup ringkasan render" title="Tutup" onClick={() => setCompletion(null)}>×</button></div><div className="mrp-render-complete__grid"><span>Durasi video<b>{formatSeconds(completion.durationSec)}</b></span><span>Resolusi<b>{completion.resolution}</b></span><span>FPS<b>{completion.fps}</b></span><span>Target bitrate<b>{completion.bitrateKbps} kbps</b></span><span>Waktu render<b>{formatSeconds(completion.elapsedSec)}</b></span><span>Ukuran file<b>{completion.fileSizeBytes === null ? '—' : `${(completion.fileSizeBytes / 1024 / 1024).toFixed(2)} MB`}</b></span><span>Overlay<b>{completion.overlays}</b></span><span>Intro<b>{completion.intro ? 'Ya' : 'Tidak'}</b></span><span>Sticker<b>{completion.stickers}</b></span><span>Perangkat Render<b>{completion.renderDevice === 'gpu' ? `GPU • ${completion.gpu.encoder ?? 'H.264'}` : 'CPU • libx264'}</b></span><span>VGA / GPU<b>{completion.gpu.name}</b></span><span>VRAM<b>{completion.gpu.vramMb === null ? 'Tidak tersedia' : `${completion.gpu.vramMb} MB`}</b></span></div><div className="mrp-render-complete__path"><small>Folder penyimpanan</small><strong>{completion.outputPath.replace(/[\\/][^\\/]+$/, '')}</strong><small>File: {completion.outputPath.split(/[\\/]/).at(-1)}</small></div><div className="mrp-dialog__actions"><button type="button" className="mrp-btn" onClick={() => void openCompletedFolder()}>Buka Folder</button><button type="button" className="mrp-btn mrp-btn--primary" onClick={() => void openCompletedVideo()}>▶ Buka Video</button></div></div></div>}
    <main className="mrp-shell"><WindowChrome /><div className="mrp-top-nav">{mainNav}<div className="mrp-top-nav__copyright">© 2026 Radist Ginola. All rights reserved.</div></div><section className="mrp-page-content">{page}</section></main>
  </>;
}

function formatSeconds(value: number): string { const total = Math.max(0, Math.floor(value || 0)); const h = Math.floor(total / 3600); const m = Math.floor((total % 3600) / 60); const s = total % 60; return h > 0 ? `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; }

export function App(): JSX.Element { return <HistoryProvider historyLimit={100} initialProject={null}><AppContent /></HistoryProvider>; }
