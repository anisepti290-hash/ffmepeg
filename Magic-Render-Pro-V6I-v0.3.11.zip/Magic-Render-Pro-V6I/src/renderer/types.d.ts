import type { MagicRenderApi } from '../shared/ipc';

declare global {
  interface Window {
    magicRender: MagicRenderApi;
  }
}

export {};
