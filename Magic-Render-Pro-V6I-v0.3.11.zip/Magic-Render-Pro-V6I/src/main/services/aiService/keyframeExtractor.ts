import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import type { Keyframe } from '../../../shared/domain/aiTypes';
import type { ProjectData } from '../../../shared/domain/projectTypes';

const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif']);

export class KeyframeExtractor {
  constructor(private readonly ffmpegExecutable: string) {}

  async extract(project: ProjectData, sourcePath?: string, sourceDurationSeconds?: number): Promise<Keyframe[]> {
    if (!project.mainMedia?.path && !sourcePath) throw new Error('Media belum tersedia untuk analisis AI.');
    const input = path.resolve(sourcePath ?? project.mainMedia!.path);
    const stat = await fs.stat(input).catch(() => null);
    if (!stat?.isFile()) throw new Error(`Main media tidak ditemukan: ${input}`);

    const ext = path.extname(input).toLowerCase();
    // Resize still media too: sending a 4K original consumes upload bandwidth
    // and vision tokens without improving an SEO description.
    if (IMAGE_EXTENSIONS.has(ext)) return [await this.extractFrame(input, 0)];

    const duration = Math.max(0, sourceDurationSeconds ?? project.mainMedia?.durationSeconds ?? project.mainMedia?.metadata?.durationSeconds ?? 0);
    const timestamps = representativeTimestamps(duration);
    const frames: Keyframe[] = [];
    for (const timestampSec of timestamps) frames.push(await this.extractFrame(input, timestampSec));
    return frames;
  }

  private extractFrame(input: string, timestampSec: number): Promise<Keyframe> {
    if (!this.ffmpegExecutable.trim()) throw new Error('FFmpeg executable belum dikonfigurasi.');
    // Bound each sampled frame to reduce request size and vision token use.
    const args = ['-hide_banner', '-loglevel', 'error', '-ss', timestampSec.toFixed(3), '-i', input, '-frames:v', '1', '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-q:v', '4', 'pipe:1'];
    return new Promise((resolve, reject) => {
      const child = spawn(this.ffmpegExecutable, args, { shell: false, windowsHide: true });
      const chunks: Buffer[] = [];
      let stderr = '';
      child.stdout.on('data', (chunk: Buffer) => chunks.push(Buffer.from(chunk)));
      child.stderr.on('data', (chunk: Buffer) => { stderr += chunk.toString(); });
      child.on('error', reject);
      child.on('close', (code) => {
        if (code !== 0 || chunks.length === 0) return reject(new Error(stderr.trim() || `Ekstraksi keyframe gagal (exit ${code}).`));
        resolve({ timestampSec, mimeType: 'image/jpeg', base64: Buffer.concat(chunks).toString('base64') });
      });
    });
  }
}

function representativeTimestamps(duration: number): number[] {
  if (!(duration > 0)) return [0];
  if (duration < 3) return [Math.max(0, duration / 2)];
  return [Math.min(duration - 0.1, duration * 0.1), Math.min(duration - 0.1, duration * 0.5), Math.min(duration - 0.1, duration * 0.9)];
}
