import fs from 'node:fs/promises';
import path from 'node:path';

export const OUTPUT_EXTENSION = '.mp4';
const MIN_FREE_BYTES = 100 * 1024 * 1024;

export type OutputValidation = {
  valid: boolean;
  directory: string;
  extension: string;
  writable: boolean;
  availableBytes: number | null;
  sufficientStorage: boolean | null;
  exists: boolean;
  errors: string[];
  warnings: string[];
};

export class OutputService {
  async validateDirectory(directory: string, expectedExtension = OUTPUT_EXTENSION, estimatedBytes?: number): Promise<OutputValidation> {
    const resolvedDirectory = path.resolve(directory.trim());
    const errors: string[] = [];
    const warnings: string[] = [];
    let writable = false;
    let availableBytes: number | null = null;

    if (!directory.trim()) errors.push('Output directory wajib diisi.');
    const extension = expectedExtension.toLowerCase().startsWith('.') ? expectedExtension.toLowerCase() : `.${expectedExtension.toLowerCase()}`;
    if (extension !== OUTPUT_EXTENSION) errors.push(`Extension output harus ${OUTPUT_EXTENSION}.`);

    try {
      await fs.mkdir(resolvedDirectory, { recursive: true });
      await fs.access(resolvedDirectory, fs.constants.W_OK);
      writable = true;
    } catch {
      errors.push('Output directory tidak dapat ditulis.');
    }

    if (writable) {
      try {
        const stats = await fs.statfs(resolvedDirectory);
        availableBytes = Number(stats.bavail) * Number(stats.bsize);
      } catch {
        warnings.push('Kapasitas storage tidak dapat diperiksa pada environment ini.');
      }
    }

    const requiredBytes = Math.max(estimatedBytes ?? 0, MIN_FREE_BYTES);
    const sufficientStorage = availableBytes === null ? null : availableBytes >= requiredBytes;
    if (sufficientStorage === false) warnings.push('Ruang kosong pada output directory lebih kecil dari kebutuhan minimum yang diperkirakan.');

    return {
      valid: errors.length === 0 && sufficientStorage !== false,
      directory: resolvedDirectory,
      extension,
      writable,
      availableBytes,
      sufficientStorage,
      exists: false,
      errors,
      warnings,
    };
  }

  async prepareOutputPath(directory: string, baseName: string, options: { overwrite?: boolean; extension?: string; estimatedBytes?: number } = {}): Promise<{ outputPath: string; validation: OutputValidation }> {
    const extension = (options.extension ?? OUTPUT_EXTENSION).toLowerCase();
    const validation = await this.validateDirectory(directory, extension, options.estimatedBytes);
    if (!validation.valid) throw new Error(validation.errors.join(' ') || validation.warnings.join(' '));

    const safeBaseName = sanitizeBaseName(baseName);
    const initialPath = path.join(validation.directory, `${safeBaseName}${extension}`);
    if (options.overwrite) {
      return { outputPath: initialPath, validation: { ...validation, exists: await fileExists(initialPath) } };
    }

    if (!(await fileExists(initialPath))) return { outputPath: initialPath, validation };
    for (let index = 1; index <= 1000; index += 1) {
      const candidate = path.join(validation.directory, `${safeBaseName}-${index}${extension}`);
      if (!(await fileExists(candidate))) return { outputPath: candidate, validation: { ...validation, exists: true } };
    }
    throw new Error('Tidak dapat menemukan nama output unik setelah 1000 percobaan.');
  }
}

function sanitizeBaseName(value: string): string {
  return value.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 120) || 'Magic-Render-Pro';
}

async function fileExists(filePath: string): Promise<boolean> {
  try { await fs.access(filePath); return true; } catch { return false; }
}
