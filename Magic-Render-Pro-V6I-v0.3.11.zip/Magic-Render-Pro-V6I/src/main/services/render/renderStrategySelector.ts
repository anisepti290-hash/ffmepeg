import type { ProjectData } from '../../../shared/domain/projectTypes';

export type RenderStrategy = 'single-pass' | 'multi-stage';

export function selectRenderStrategy(project: ProjectData, options: { requireCheckpointPause?: boolean } = {}): RenderStrategy {
  const needsVisualComposition = project.overlays.length > 0 || (project.textOverlays?.length ?? 0) > 0 || Boolean(project.stickerSubscribe || project.stickerSubscribes?.length) || (project.mainMediaEffects?.length ?? 0) > 0 || (project.particleEffects?.length ?? 0) > 0;
  const needsContentFlow = project.intro.enabled && Boolean(project.intro.path);
  const needsAudio = (project.playlistTracks?.length ?? project.playlist.files.length) > 0;
  if (!needsVisualComposition && !needsContentFlow && !needsAudio && project.mainMedia?.type === 'video' && !options.requireCheckpointPause) return 'single-pass';
  return 'multi-stage';
}
