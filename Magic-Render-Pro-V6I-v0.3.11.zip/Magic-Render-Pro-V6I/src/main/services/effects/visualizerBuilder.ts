import type { VisualizerEffect } from '../../../shared/domain/visualizerTypes';
import { visualizerColors } from '../../../shared/domain/visualizerPalette';

function spectrumColors(colors:string[]): string {
  return ['r','g','b'].map((channel,index)=>{
    const values=colors.map(hex=>parseInt(hex.slice(index*2+1,index*2+3),16));
    return `${channel}='if(lt(X,W/3),${values[0]},if(lt(X,2*W/3),${values[1]},${values[2]}))'`;
  }).join(':');
}

/** Generate visualizer frames from the exact playlist audio used in the MP4. */
export function buildVisualizerFilters(items: VisualizerEffect[], input: string, audioIndex: number, canvasScale: number, fps: number): { filters: string[]; output: string } {
  if (!items.length) return { filters: [], output: input };
  const filters: string[] = [];
  const sources = items.map((_, index) => `[visual_audio_${index}]`).join('');
  filters.push(`[${audioIndex}:a]asplit=${items.length}${sources}`);
  let output = input;
  items.forEach((item, index) => {
    const width = Math.max(32, Math.round(item.size.width * canvasScale / 2) * 2);
    const height = Math.max(16, Math.round(item.size.height * canvasScale / 2) * 2);
    const color = item.color.slice(1);
    const strength = Math.min(4, Math.max(0.2, item.sensitivity));
    const source = `visual_audio_${index}`, frame = `visual_frame_${index}`, next = `visual_composite_${index}`;
    const isWave = ['wave','mirror','waveLine','wavePoints','wavePeak'].includes(item.kind);
    const isSpectrum = ['spectrum','spectrumFire','spectrumCool','spectrumScroll','spectrumViridis','spectrumMagma'].includes(item.kind);
    const columns=['bars','solidBars','smoothBars','spectrum','spectrumFire','spectrumCool','spectrumViridis','spectrumMagma'].includes(item.kind);
    const bands=item.density??64;
    const sourceWidth=columns?Math.max(16,Math.round(bands/(item.peakPosition==='center'?2:1))):undefined;
    const frequencyScale = item.frequencyScale === 'linear' ? 'lin' : 'log';
    const frequencyWidth=item.peakPosition==='center'?Math.max(16,Math.floor(width/4)*2):width;
    const graphWidth=sourceWidth??frequencyWidth;
    const filter = isWave
      ? `showwaves=s=${width}x${height}:r=${fps}:mode=${item.kind === 'mirror'||item.kind==='wavePeak' ? 'cline' : item.kind === 'waveLine' ? 'line' : item.kind === 'wavePoints' ? 'point' : 'p2p'}:colors=${color}:scale=lin`
      : isSpectrum
        ? `showfreqs=s=${graphWidth}x${height}:r=${fps}:mode=${item.kind==='spectrumScroll'?'line':'bar'}:colors=ffffff:ascale=log:fscale=${frequencyScale}:win_size=${bands*32}:averaging=${Math.max(1,Math.round(1+(item.smoothing??.7)*10))}`
        : `showfreqs=s=${graphWidth}x${height}:r=${fps}:mode=${['bars','smoothBars','solidBars'].includes(item.kind) ? 'bar' : ['dots','sparkDots'].includes(item.kind) ? 'dot' : 'line'}:colors=${color}:ascale=log:fscale=${frequencyScale}:win_size=${bands*32}:averaging=${Math.max(1, Math.round(1 + (item.smoothing ?? 0.7) * 10))}`;
    // Amplify this branch only: the mapped soundtrack stays untouched.
    // All variants use actual soundtrack frequencies, keyed black background,
    // and opaque bars/points. Spectrum colors are applied only where audio
    // was drawn, avoiding opaque spectrogram rectangles on the final video.
    const blur=Math.max(item.kind==='smoothBars'?1:item.kind==='sparkDots'?1.5:0,Math.min(5,item.glow??0))*canvasScale;
    const raw=`visual_raw_${index}`;
    const responseFrames=item.sensitivity<1?Math.min(12,Math.ceil(1/item.sensitivity)):1;
    filters.push(`[${source}]volume=${strength.toFixed(2)},${filter}${sourceWidth?`,scale=${frequencyWidth}:${height}:flags=neighbor`:''}${item.kind==='wavePeak'?',crop=iw:ih/2:0:0,pad=iw:ih*2:0:ih:color=black':''}${responseFrames>1?`,tmix=frames=${responseFrames}`:''}[${raw}]`);
    let oriented=raw;
    if(!isWave && item.peakPosition==='center') {
      const lhs=`visual_left_${index}`,rhs=`visual_right_${index}`,flip=`visual_flip_${index}`;
      oriented=`visual_oriented_${index}`;
      filters.push(`[${raw}]split=2[${lhs}][${rhs}]`,`[${lhs}]hflip[${flip}]`,`[${flip}][${rhs}]hstack[${oriented}]`);
    } else if(!isWave && item.peakPosition==='right') {
      oriented=`visual_oriented_${index}`;
      filters.push(`[${raw}]hflip[${oriented}]`);
    }
    const spacing=columns||['dots','sparkDots'].includes(item.kind)?Math.max(0,Math.min(.8,item.bandSpacing??(item.kind==='solidBars'?0:.15))):0;
    const gapPx=Math.min(Math.round(width/Math.max(1,bands)) - 1,Math.round(width/Math.max(1,bands)*spacing));
    const barGap=gapPx>0?`drawgrid=w=${Math.max(2,Math.round(width/bands))}:h=${height}:t=${gapPx}:c=black,`:'';
    const radius=columns && item.roundedTop?Math.max(.2,(item.cornerRadius??6)*canvasScale/3):0;
    const rounding=radius>0?`,gblur=sigma=${radius.toFixed(2)}:planes=8,lut=a='if(gte(val,128),255,0)'`:'';
    filters.push(`[${oriented}]${barGap}${blur>0 ? `gblur=sigma=${blur.toFixed(2)},` : ''}format=rgba,colorkey=0x000000:0.05:0.02${rounding}${isSpectrum?`,geq=${spectrumColors(visualizerColors(item))}:a='alpha(X,Y)'`:''},colorchannelmixer=aa=${item.opacity.toFixed(3)}[${frame}]`);
    filters.push(`[${output}][${frame}]overlay=x=${Math.round(item.position.x * canvasScale)}:y=${Math.round(item.position.y * canvasScale)}:eof_action=pass:shortest=0:format=auto[${next}]`);
    output = next;
  });
  return { filters, output };
}
