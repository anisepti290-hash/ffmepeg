import type { VisualizerEffect } from '../../../shared/domain/visualizerTypes';

export function validateVisualizer(value: unknown): VisualizerEffect {
  const v = value as VisualizerEffect;
  const finite = (n: unknown) => typeof n === 'number' && Number.isFinite(n);
  if (!v || typeof v.id !== 'string' || !/^[\w-]{1,80}$/.test(v.id) || !['bars','line','dots','wave','mirror','spectrum','smoothBars','waveLine','wavePoints','spectrumFire','spectrumCool','spectrumScroll','solidBars','sparkDots','wavePeak','spectrumViridis','spectrumMagma'].includes(v.kind)
      || !v.position || !finite(v.position.x) || !finite(v.position.y) || Math.abs(v.position.x) > 16384 || Math.abs(v.position.y) > 16384
      || !v.size || !finite(v.size.width) || !finite(v.size.height) || v.size.width < 32 || v.size.height < 16 || v.size.width > 3840 || v.size.height > 2160
      || typeof v.color !== 'string' || !/^#[0-9a-f]{6}$/i.test(v.color)
      || !finite(v.opacity) || v.opacity < 0 || v.opacity > 1 || !finite(v.sensitivity) || v.sensitivity < 0.2 || v.sensitivity > 4
      || (v.smoothing !== undefined && (!finite(v.smoothing) || v.smoothing < 0 || v.smoothing > 0.95))
      || (v.frequencyScale !== undefined && !['log','linear'].includes(v.frequencyScale))
      || (v.palette !== undefined && !['rainbow','fire','cool','viridis','magma','custom'].includes(v.palette))
      || (v.peakPosition !== undefined && !['left','center','right'].includes(v.peakPosition))
      || (v.density !== undefined && ![16,32,64,128].includes(v.density))
      || (v.bandSpacing !== undefined && (!finite(v.bandSpacing) || v.bandSpacing<0 || v.bandSpacing>.8))
      || (v.roundedTop !== undefined && typeof v.roundedTop!=='boolean')
      || (v.cornerRadius !== undefined && (!finite(v.cornerRadius) || v.cornerRadius<0 || v.cornerRadius>24))
      || (v.glow !== undefined && (!finite(v.glow) || v.glow < 0 || v.glow > 5))) throw new Error('Konfigurasi visualizer tidak valid.');
  return v;
}
