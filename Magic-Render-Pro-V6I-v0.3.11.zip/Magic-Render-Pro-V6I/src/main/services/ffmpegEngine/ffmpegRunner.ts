import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import { readFileSync } from 'node:fs';
import type { SpawnCommand } from './commandBuilder';
import { FfmpegProgressParser, type ParsedFfmpegProgress } from './progressParser';
import { applyFfmpegThreadMapping, detectLogicalCoreCount, getCpuAllocation } from '../cpuController';

export type FfmpegRunResult = {
  exitCode: number | null;
  stderr: string;
  stdout: string;
  cancelled: boolean;
  interrupted: boolean;
};

export type FfmpegRunOptions = {
  onOutput?: (line: string) => void;
  onProgress?: (progress: ParsedFfmpegProgress) => void;
};

export async function runFfmpeg(command: SpawnCommand, options: FfmpegRunOptions = {}, cpuLoadPercent: number | null = null): Promise<FfmpegRunResult> {
  return new FfmpegProcess(cpuLoadPercent).run(command, options);
}

export class FfmpegProcess {
  private child: ChildProcessWithoutNullStreams | null = null;
  private cancelled = false;
  private interrupted = false;

  constructor(private readonly cpuLoadPercent: number | null = null) {}

  async run(command: SpawnCommand, options: FfmpegRunOptions = {}): Promise<FfmpegRunResult> {
    if (this.child) throw new Error('FFmpeg process already running.');

    return new Promise((resolve, reject) => {
      const progressArgs = injectProgressArgs(command.args);
      const args = this.cpuLoadPercent === null
        ? progressArgs
        : applyFfmpegThreadMapping(progressArgs, this.cpuLoadPercent, detectLogicalCoreCount());
      const child = spawn(command.executable, args, {
        shell: false,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
      this.child = child;
      if (this.cpuLoadPercent !== null && child.pid) {
        const allocation = getCpuAllocation(this.cpuLoadPercent);
        if (allocation.ffmpegThreads < allocation.logicalCoreCount) {
          limitProcessAffinity(child.pid, allocation.ffmpegThreads, options.onOutput);
        }
      }
      this.cancelled = false;
      this.interrupted = false;
      const progressParser = new FfmpegProgressParser();
      let stderr = '';
      let stdout = '';
      let stderrPending = '';
      let stdoutPending = '';
      let settled = false;

      const processLines = (chunk: string, stream: 'stdout' | 'stderr') => {
        const combined = (stream === 'stderr' ? stderrPending : stdoutPending) + chunk;
        const lines = combined.split(/\r\n|\n|\r/);
        const pending = lines.pop() ?? '';
        if (stream === 'stderr') stderrPending = pending;
        else stdoutPending = pending;
        for (const line of lines) {
          if (!line.trim()) continue;
          if (stream === 'stdout') options.onProgress?.(progressParser.parseLine(line));
          else {
            options.onOutput?.(line.trim());
            const stats = progressParser.parseStats(line);
            if (stats) options.onProgress?.(stats);
            else if (/^(?:out_time_ms|out_time_us|out_time|speed|progress)=/.test(line.trim())) options.onProgress?.(progressParser.parseLine(line));
          }
        }
      };

      const finish = (result: FfmpegRunResult) => {
        if (settled) return;
        settled = true;
        this.child = null;
        resolve(result);
      };

      child.stdout.setEncoding('utf8');
      child.stderr.setEncoding('utf8');

      child.stdout.on('data', (chunk: string) => {
        stdout = (stdout + chunk).slice(-131072);
        processLines(chunk, 'stdout');
      });

      child.stderr.on('data', (chunk: string) => {
        stderr = (stderr + chunk).slice(-131072);
        processLines(chunk, 'stderr');
      });

      child.once('error', (error) => {
        this.child = null;
        if (settled) return;
        settled = true;
        reject(error);
      });

      child.once('close', (exitCode) => {
        if (stdoutPending.trim()) options.onProgress?.(progressParser.parseLine(stdoutPending));
        if (stderrPending.trim()) {
          options.onOutput?.(stderrPending.trim());
          const stats = progressParser.parseStats(stderrPending);
          if (stats) options.onProgress?.(stats);
        }
        finish({ exitCode, stderr, stdout, cancelled: this.cancelled, interrupted: this.interrupted });
      });
    });
  }

  cancel(): void {
    this.cancelled = true;
    if (this.child && !this.child.killed) {
      this.child.kill('SIGKILL');
    }
  }

  forceStop(): void {
    const pid = this.child?.pid;
    this.cancel();
    if (process.platform === 'win32' && pid) {
      // TerminateProcess may leave decoder subprocesses behind on Windows.
      const killer = spawn('taskkill.exe', ['/PID', String(pid), '/T', '/F'], {
        shell: false, windowsHide: true, stdio: 'ignore',
      });
      killer.on('error', () => undefined);
    }
  }

  interrupt(): void {
    this.interrupted = true;
    if (this.child && !this.child.killed) this.child.kill('SIGKILL');
  }

  gracefulStop(timeoutMs = 1500): void {
    const child = this.child;
    if (!child || child.killed) return;
    if (child.stdin && !child.stdin.destroyed) {
      child.stdin.write('q\n');
      const timer = setTimeout(() => {
        if (this.child === child && !child.killed) child.kill();
      }, timeoutMs);
      child.once('close', () => clearTimeout(timer));
      return;
    }
    child.kill();
  }

  isRunning(): boolean {
    return this.child !== null;
  }
}

function limitProcessAffinity(pid: number, cores: number, onOutput?: (line: string) => void): void {
  let executable: string;
  let args: string[];
  if (process.platform === 'win32') {
    // SetProcessorAffinityMask constrains the whole FFmpeg process, including
    // decoder, filter workers and encoder threads (up to one 64-core group).
    const mask = ((1n << BigInt(Math.min(cores, 63))) - 1n).toString();
    executable = 'powershell.exe';
    args = ['-NoProfile', '-NonInteractive', '-Command',
      `(Get-Process -Id ${pid} -ErrorAction Stop).ProcessorAffinity = [IntPtr]${mask}`];
  } else if (process.platform === 'linux') {
    // Container/VM affinity may begin at a nonzero core number.
    let allowed = '';
    try { allowed = readFileSync('/proc/self/status', 'utf8').match(/^Cpus_allowed_list:\s*(.+)$/m)?.[1] ?? ''; }
    catch { return; }
    const ids = allowed.split(',').flatMap((range) => {
      const [first, last] = range.split('-').map(Number);
      if (first === undefined || !Number.isInteger(first)) return [];
      const end = last ?? first;
      return Number.isInteger(end) && end >= first
        ? Array.from({ length: end - first + 1 }, (_, offset) => first + offset) : [];
    });
    if (!ids.length) return;
    executable = 'taskset';
    args = ['-pc', ids.slice(0, cores).join(','), String(pid)];
  } else return;
  const setter = spawn(executable, args, { shell: false, windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
  let errorText = '';
  setter.stderr.on('data', (chunk: Buffer) => { errorText += chunk.toString(); });
  setter.on('error', (error) => onOutput?.(`[CPU] Batas inti tidak dapat diterapkan: ${error.message}`));
  setter.on('close', (code) => {
    if (code !== 0 && !/No such process|Cannot find a process/i.test(errorText)) {
      onOutput?.(`[CPU] Batas inti tidak dapat diterapkan: ${errorText.trim() || 'izin sistem ditolak'}`);
    }
  });
}

function injectProgressArgs(args: string[]): string[] {
  if (args.includes('-progress')) return [...args];
  const clone = [...args];
  const insertAt = clone[0] === '-y' ? 1 : 0;
  clone.splice(insertAt, 0, '-progress', 'pipe:1', '-stats_period', '0.5');
  return clone;
}
