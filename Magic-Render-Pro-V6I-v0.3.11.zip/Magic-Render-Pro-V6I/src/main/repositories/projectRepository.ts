import fs from 'node:fs/promises';
import path from 'node:path';
import type { ProjectData } from '../../shared/domain/projectTypes';
import { getProjectFilePath, validateProjectData } from '../services/project/projectValidator';

export class ProjectRepository {
  async save(project: ProjectData): Promise<string> {
    await fs.mkdir(project.projectDir, { recursive: true });
    const filePath = getProjectFilePath(project.projectDir);
    const payload = JSON.stringify(project, null, 2);
    const tempPath = `${filePath}.tmp`;
    await fs.writeFile(tempPath, payload, 'utf8');
    await fs.rename(tempPath, filePath);
    return filePath;
  }

  async load(projectFilePath: string): Promise<ProjectData> {
    const resolved = path.resolve(projectFilePath);
    if (path.basename(resolved).toLowerCase() !== 'project.json') {
      throw new Error('Project file must be named project.json.');
    }
    const content = await fs.readFile(resolved, 'utf8');
    let parsed: unknown;
    try {
      parsed = JSON.parse(content);
    } catch {
      throw new Error('Project file contains invalid JSON.');
    }
    const validation = validateProjectData(parsed);
    if (!validation.valid) throw new Error(validation.errors.join(' '));
    return parsed as ProjectData;
  }
}
