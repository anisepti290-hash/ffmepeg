import { app, BrowserWindow, net, protocol } from 'electron';
import path from 'node:path';
import { createApplicationConfig } from './config/appConfig';
import { createRuntimeConfig } from './config/environment';
import { registerIpcHandlers } from './ipc/registerIpc';
import { settingsService } from './ipc/settingsHandlers';
import { initializeLogger, logger, subscribeLogger } from './utils/logger';
import { DEFAULT_WINDOW_SIZE } from '../shared/app';
import { initializeLockedAssetPersistence, listLockedAssets } from './services/persistentStore';
import type { RenderOrchestrator } from './services/render/renderOrchestrator';
import { CacheManager } from './services/cache/cacheManager';
import { IPC_CHANNELS } from '../shared/ipc';
import { translateFfmpegError } from './services/ffmpegEngine/errorTranslator';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';

protocol.registerSchemesAsPrivileged([{ scheme: 'mrp-media', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } }]);

const runtimeConfig = createRuntimeConfig();
const applicationConfig = createApplicationConfig(runtimeConfig);

function translateForUser(message: string): string {
  if (/prompt\(\) is not supported/i.test(message)) return 'Fitur dialog input lama tidak didukung oleh Electron. Aplikasi menggunakan dialog project bawaan.';
  if (/failed to load|network|econnrefused|fetch failed/i.test(message)) return 'Aplikasi gagal terhubung ke layanan yang dibutuhkan. Periksa koneksi internet atau konfigurasi.';
  if (/enoent|not found|cannot find/i.test(message)) return 'File atau program yang dibutuhkan tidak ditemukan. Periksa path file yang dipilih.';
  if (/permission|access denied/i.test(message)) return 'Aplikasi tidak memiliki izin untuk mengakses file atau folder tersebut.';
  if (/ffmpeg/i.test(message) && /not available|spawn|enoent|cannot find/i.test(message)) return 'FFmpeg tidak ditemukan atau tidak bisa dijalankan. Periksa Path FFmpeg di Menu Setting.';
  if (/ffprobe/i.test(message) && /not available|spawn|enoent|cannot find/i.test(message)) return 'FFprobe tidak ditemukan atau tidak bisa dijalankan. Periksa Path FFprobe di Menu Setting.';
  if (/renderer process exited unexpectedly/i.test(message)) return 'Jendela editor berhenti secara tidak terduga. Coba buka kembali aplikasi.';
  if (/renderer failed to load/i.test(message)) return 'Tampilan aplikasi gagal dimuat. Silakan tutup dan buka kembali aplikasi.';
  if (/bootstrap failed/i.test(message)) return 'Aplikasi gagal melakukan persiapan awal. Periksa Console Log atau coba buka kembali aplikasi.';
  return message;
}

function translateLogDetail(detail: string | null | undefined): string | null {
  if (!detail) return null;
  try {
    const parsed = JSON.parse(detail) as Record<string, unknown>;
    if (typeof parsed.stage === 'string') return `Tahap: ${parsed.stage.replaceAll('-', ' ')}.${parsed.code ? ` Kode: ${String(parsed.code)}.` : ''}`;
    const candidateKeys = ['message', 'errorDescription', 'reason', 'stderr', 'raw'];
    for (const key of candidateKeys) {
      const value = parsed[key];
      if (typeof value === 'string' && value.trim()) {
        if (key === 'stderr' || key === 'raw') { const translated = translateFfmpegError(value); return `${translated.title}: ${translated.message} Solusi: ${translated.solution}`; }
        return translateForUser(value);
      }
    }
    return 'Ada detail tambahan. Periksa Console Log untuk konteks proses.';
  } catch {
    return translateForUser(detail);
  }
}

const logSubscribers = new Set<BrowserWindow>();
subscribeLogger((entry) => {
  const translated = translateForUser(entry.message);
  for (const window of logSubscribers) {
    if (!window.isDestroyed()) window.webContents.send(IPC_CHANNELS.APP_LOG, { ...entry, message: translated, detail: translateLogDetail(entry.detail) });
  }
});


let mainWindow: BrowserWindow | null = null;
let renderOrchestrator: RenderOrchestrator | null = null;
let cleanupInFlight: Promise<void> | null = null;

function cleanupOnClose(): Promise<void> {
  if (!cleanupInFlight) cleanupInFlight = (async () => {
    renderOrchestrator?.cancelAll();
    // FFmpeg and filesystem cleanup can stall on removable/network drives.
    // Bound shutdown while retaining active job directories for next startup.
    let cancellationTimeout: ReturnType<typeof setTimeout> | undefined;
    try {
      await Promise.race([
        renderOrchestrator?.waitForAvailability() ?? Promise.resolve(),
        new Promise<void>((resolve) => { cancellationTimeout = setTimeout(resolve, 5000); }),
      ]);
    } finally { if (cancellationTimeout) clearTimeout(cancellationTimeout); }
    const assets = await listLockedAssets();
    const results = await new CacheManager().cleanupStaleJobs(0, assets.map((item) => item.path), renderOrchestrator?.activeJobDirectories() ?? []);
    logger.info('[SISTEM] File sementara aplikasi dibersihkan saat jendela ditutup.', { jobs: results.length, failures: results.flatMap((item) => item.failed).length });
  })().catch((error) => { logger.warn('Pembersihan file sementara saat tutup gagal.', { message: String(error) }); });
  return cleanupInFlight;
}

function assertElectronSecurity(window: BrowserWindow): void {
  const webPreferences = window.webContents.getURL();
  if (window.webContents && webPreferences === 'about:blank') {
    logger.debug('Electron window initialized before renderer navigation.');
  }
}

function registerMediaProtocol(): void {
  protocol.handle('mrp-media', async (request) => {
    try {
      const url = new URL(request.url);
      const filePath = url.searchParams.get('path');
      if (!filePath) return new Response('Missing media path.', { status: 400 });
      const absolutePath = path.resolve(filePath);
      const stat = await fs.promises.stat(absolutePath).catch(() => null);
      if (!stat?.isFile()) return new Response('Media file not found.', { status: 404 });
      const fileUrl = pathToFileURL(absolutePath).toString();
      const response = await net.fetch(fileUrl, { headers: request.headers });
      const headers = new Headers(response.headers);
      headers.set('Access-Control-Allow-Origin', '*');
      return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
    } catch (error) {
      logger.error('Media protocol request failed.', { message: error instanceof Error ? error.message : String(error) });
      return new Response('Unable to load local media.', { status: 500 });
    }
  });
}

function getRendererEntry(): { url?: string; file?: string } {
  if (runtimeConfig.isDevelopment) {
    return { url: runtimeConfig.devServerUrl };
  }
  return { file: path.join(__dirname, '..', 'renderer', 'index.html') };
}

function createMainWindow(): BrowserWindow {
  const window = new BrowserWindow({
    width: applicationConfig.window.width || DEFAULT_WINDOW_SIZE.width,
    height: applicationConfig.window.height || DEFAULT_WINDOW_SIZE.height,
    minWidth: applicationConfig.window.minWidth,
    minHeight: applicationConfig.window.minHeight,
    backgroundColor: '#070711',
    icon: (() => {
      const candidates = [path.join(process.resourcesPath, 'app-icon.ico'), path.join(__dirname, '..', '..', 'resources', 'app-icon.ico'), path.join(__dirname, '..', 'renderer', 'assets', 'magic-render-pro.ico')];
      return candidates.find((candidate) => fs.existsSync(candidate)) ?? candidates[2];
    })(),
    show: false,
    // The title bar and File/Help menus are intentionally rendered by React.
    // Window actions are still executed by Electron through the preload bridge.
    frame: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, '..', 'preload', 'index.js'),
      contextIsolation: true,
      nodeIntegration: false,
      // Preload is compiled as CommonJS and imports local typed bridge modules.
      // Keep context isolation and disable renderer Node integration; do not sandbox
      // this preload until it is bundled into a single sandbox-compatible artifact.
      sandbox: false,
      devTools: runtimeConfig.isDevelopment,
    },
  });

  assertElectronSecurity(window);
  let closeReady = false;
  window.on('close', (event) => {
    if (closeReady) return;
    event.preventDefault();
    let timeout: ReturnType<typeof setTimeout> | undefined;
    void Promise.race([
      cleanupOnClose(),
      new Promise<void>((resolve) => { timeout = setTimeout(resolve, 8000); }),
    ]).finally(() => {
      if (timeout) clearTimeout(timeout);
      closeReady = true;
      if (!window.isDestroyed()) window.close();
    });
  });
  logSubscribers.add(window);
  window.on('closed', () => logSubscribers.delete(window));
  window.once('ready-to-show', () => window.show());
  window.on('closed', () => {
    mainWindow = null;
  });
  window.webContents.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    logger.error('Renderer failed to load.', { errorCode, errorDescription, validatedURL, isMainFrame });
  });
  window.webContents.on('render-process-gone', (_event, details) => {
    logger.error('Renderer process exited unexpectedly.', {
      reason: details.reason,
      exitCode: details.exitCode,
    });
  });
  window.webContents.on('console-message', (event) => {
    const { level, message, lineNumber, sourceId } = event;
    const numericLevel = typeof level === 'number' ? level : Number(level);
    if (numericLevel >= 2) {
      logger.warn('Renderer console error.', {
        level: numericLevel,
        message,
        line: lineNumber,
        sourceId,
      });
    }
  });

  const entry = getRendererEntry();
  if (entry.url) {
    void window.loadURL(entry.url);
  } else if (entry.file) {
    void window.loadFile(entry.file);
  }

  return window;
}

async function bootstrap(): Promise<void> {
  await app.whenReady();
  if (process.platform === 'win32') app.setAppUserModelId(applicationConfig.appId);
  await initializeLogger();
  const persistedSettings = settingsService.get();
  runtimeConfig.ffmpegPath = persistedSettings.ffmpegPath;
  runtimeConfig.ffprobePath = persistedSettings.ffprobePath;
  logger.info('Bootstrapping Magic Render Pro.', {
    environment: runtimeConfig.environment,
    platform: process.platform,
    electron: process.versions.electron,
    node: process.versions.node,
  });

  registerMediaProtocol();
  renderOrchestrator = registerIpcHandlers(applicationConfig);
  const lockedAssets = await initializeLockedAssetPersistence();
  logger.info('Locked asset persistence initialized.', { count: lockedAssets.length });
  mainWindow = createMainWindow();
  const cacheManager = new CacheManager();
  void cacheManager.cleanupStaleJobs(24 * 60 * 60 * 1000, lockedAssets.map((asset) => asset.path))
    .then((staleCleanup) => logger.info('Stale render cache cleanup completed.', { jobs: staleCleanup.length, failures: staleCleanup.reduce((sum, item) => sum + item.failed.length, 0) }))
    .catch((error) => logger.warn('Stale render cache cleanup failed.', { message: String(error) }));

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createMainWindow();
    }
  });
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception in Main Process.', { message: error.message, stack: error.stack });
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection in Main Process.', { reason });
});

void bootstrap().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  logger.error('Application bootstrap failed.', { message });
  app.exit(1);
});
