# Magic Render Pro V5R — perbaikan chroma sticker, render, canvas, metadata MP3, fade intro

## Penyebab dan perubahan

1. **Sticker chroma tampak pudar pada ekspor.** Filter `chromakey` YUV dipakai sesudah `pad` transparan. Ambang similarity/blend ikut mengubah alfa huruf putih dan area padding menjadi selaput gelap. `stickerFilterBuilder.ts` menerapkan `colorkey` RGB sebelum padding dan secara eksplisit memakai alfa lurus pada overlay. `CanvasPreview.tsx` memakai mode warna RGB yang sama untuk chroma sticker. Sticker gambar berchroma dibuat sebagai PNG transparan sekali per render oleh `renderOrchestrator.ts`, lalu dipakai sepanjang video; file asli tetap utuh.
2. **Render CPU lambat.** Jalur sticker gambar statis berhenti menghitung chroma setiap frame. Jalur biasa tanpa chroma tetap memakai compositing langsung dan satu proses encoding video akhir. `gpuDetection.ts` dan `renderHandlers.ts` melewati uji encoder FFmpeg pada awal render CPU; pengenalan nama/VRAM tetap ada. Mode GPU terus menguji encoder H.264 yang tersedia saat dipilih; pemilihan CPU tidak bergantung pada merek Intel/AMD. Preset CPU dan batas bitrate pada Setting tetap dihormati. Kecepatan sebenarnya bergantung pada media, efek, resolusi, dan CPU.
3. **Canvas meluas ketika layer ditarik keluar.** `.mrp-canvas-extent` dan `.mrp-canvas-stage` mengklip visual yang melewati batas; pembesaran manual 100–500% tetap dapat digeser di area preview.
4. **Reset metadata MP3.** Tombol pada Playlist menyalin seluruh track ke subfolder project dengan `-c:a copy`, mematikan metadata global/stream/chapters serta ID3, memeriksa hasil dengan FFprobe, dan mengganti referensi playlist serta urutan putar. MP3 sumber tidak disentuh. Metadata embedded dibersihkan; tindakan ini tidak menghapus hak cipta atau informasi yang terdengar di dalam audio.
5. **Fade tanpa intro.** Gaya gelap atau blur, durasi, tingkat blur, serta kecerahan awal tersedia pada menu Intro. Fade fallback hanya berlaku bila Intro dan Fade-In Media Utama tidak aktif. Preview memakai campuran visual blur dan video tajam; render menerapkannya hanya pada segmen pembuka untuk menghindari filter blur sepanjang lagu. Sisa video lewat tanpa blur.

## File yang diubah

- `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`
- `src/main/services/render/renderOrchestrator.ts`, `src/main/services/render/renderCommandBuilder.ts`, `src/main/services/render/gpuDetection.ts`, `src/main/ipc/renderHandlers.ts`
- `src/renderer/components/CanvasPreview.tsx`, `src/renderer/styles/index.css`
- `src/main/services/audio/playlistService.ts`, `src/main/ipc/playlistHandlers.ts`, `src/preload/index.ts`, `src/shared/ipc.ts`, `src/renderer/components/PlaylistPanel.tsx`
- `src/shared/domain/introTypes.ts`, `src/main/services/intro/introService.ts`, `src/main/domain/project/projectFactory.ts`, `src/main/services/project/projectValidator.ts`, `src/renderer/components/IntroPanel.tsx`
- `src/renderer/App.tsx`, `src/main/ipc/appHandlers.ts`, `package.json`, `package-lock.json`
- Tes baru: `scripts/test-v5r-chroma.cjs`, `scripts/test-v5r-fade-metadata.cjs`, `scripts/test-v5r-render-integration.cjs`
- `dist/` dibangun ulang untuk menjalankan versi yang telah diperbaiki. Tidak ada file proyek yang dihapus.

## Verifikasi

`npm run build`, `npm run typecheck`, `npm run test:orchestrator`, `node scripts/test-v5q-sticker-cpu-ai.cjs`, dan ketiga tes V5R lolos. Tes V5R memakai FFmpeg sungguhan untuk mengecek alfa piksel merah/putih, ekspor chroma melalui orchestrator, render fade blur, dan penghapusan tag Suno/copyright dari salinan MP3. Pengujian ini dijalankan pada Linux; tampilan dan durasi render sebenarnya di mesin Windows pengguna tetap perlu dicoba dengan video asli.
