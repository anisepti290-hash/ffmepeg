# Magic Render Pro V6C · v0.3.5

Baseline: V6B v0.3.4. Perubahan alur render 10 detik dan stream copy pada pertanyaan nomor 1 **tidak diterapkan**.

## Perbaikan

- Audio Visualizer: kepadatan 16/32/64/128, slider jarak antar partikel/kolom 0–80%, opsi sudut atas melengkung dan radius, respons gerak lebih lambat bila sensitivitas diperkecil. Preview dan filter FFmpeg sama-sama menerapkan pengaturan tersebut.
- Bulk Render: kontrol fade blur kini dapat ditampilkan saat intro acak dipilih dan bekerja pada bagian awal intro; saat tanpa intro tetap bekerja pada media utama. Kartu progres setiap media menampilkan detik berjalan, durasi, persentase, dan speed render.
- Sticker Bulk Render: pilihan dari awal sampai akhir dimulai setelah waktu pembuka (umumnya 00:30; pada video pendek disesuaikan), lalu bertahan sampai akhir. Mode berulang dimulai setelah waktu pembuka. Timestamp 00:00 digeser ke 00:01; editor Render biasa mempertahankan logika jadwalnya.

## File diperbaiki

| Bagian | Berkas |
| --- | --- |
| Visualizer | `src/shared/domain/visualizerTypes.ts`, `src/main/services/effects/visualizerValidator.ts`, `src/renderer/components/EffectsPanels.tsx`, `src/renderer/components/VisualizerPreview.tsx`, `src/main/services/effects/visualizerBuilder.ts` |
| Bulk Render | `src/shared/domain/bulkTypes.ts`, `src/renderer/components/BulkRenderPage.tsx`, `src/renderer/App.tsx`, `src/main/services/bulk/bulkPlanner.ts`, `src/main/services/render/renderCommandBuilder.ts` |
| Versi/uji | `package.json`, `package-lock.json`, `src/renderer/components/HelpPage.tsx`, `scripts/test-v6b-render-effects-editor.cjs`, `scripts/test-v5n-bulk.cjs` |

Tidak ada file yang dihapus. Uji build, filter FFmpeg, dan render gabungan Bulk menggunakan media sintetis lulus. Kecepatan proses di perangkat Intel i5-10400F perlu diukur langsung karena tidak tersedia di lingkungan pengujian ini.
