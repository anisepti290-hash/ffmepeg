# Magic Render Pro V5Y • Versi 0.3.1

## Tujuh revisi

1. Panel Main Media Controls, Overlay, dan Sticker Subscribe menyimpan perubahan
   pada project saat kontrol berubah. Canvas Preview menerima nilai terbaru tanpa
   tombol Terapkan. Perubahan slider dikelompokkan menjadi satu langkah Undo.
2. Partikel kini 17 jenis dan sembilan arah. Tambah Partikel diikuti tombol
   chevron untuk membuka atau menutup kontrol.
3. Visualizer kini 12 gaya, dengan kontrol palet, skala frekuensi, kehalusan,
   sensitivitas, ukuran, posisi, dan opacity sesuai gaya. Chevron tersedia di
   samping Tambah Visualizer.
4. Filter FFmpeg memakai audio playlist, sensitivitas, jenis, palet, kehalusan,
   skala frekuensi, posisi, ukuran, dan opacity yang disimpan panel. Preview
   memperbaiki pemetaan frekuensi dan arah scroll serta menggunakan nilai ini.
5. Asset Preview, Canvas Preview, dan jalur ekspor chroma key menggunakan RGB
   `colorkey` dengan kemiripan dan blend yang sama. Piksel transparan asli tetap
   dipertahankan. Nilai alpha dibandingkan dengan output FFmpeg dalam tes.
6. Pintasan: F1; Ctrl+1–6; Alt+1–6; Ctrl+N/O/S/I; Ctrl+Enter;
   Ctrl+Shift+P/X; Ctrl+Z/Y; Space; Home; +/-; Delete; panah; Shift+panah;
   Esc. Pintasan canvas tidak mengganggu pengetikan pada input.
7. `Jalankan-Magic-Render-Pro.bat` menjalankan enam perintah pengguna secara
   berurutan; `call` mencegah CMD keluar saat menjalankan npm dan status gagal
   menghentikan langkah berikutnya.

## File yang berkaitan

| Kebutuhan | File utama |
| --- | --- |
| Edit langsung dan riwayat | `src/renderer/App.tsx`, `src/renderer/components/StickerPanel.tsx`, `src/renderer/context/historyContext.tsx` |
| Partikel | `src/renderer/components/EffectsPanels.tsx`, `src/shared/domain/effectTypes.ts`, `src/shared/domain/effectPreview.ts`, `src/main/services/effects/effectFilterBuilder.ts`, `src/main/services/effects/effectValidator.ts` |
| Visualizer | `src/renderer/components/VisualizerPreview.tsx`, `src/main/services/effects/visualizerBuilder.ts`, `src/main/services/effects/visualizerValidator.ts`, `src/shared/domain/visualizerTypes.ts` |
| Keying | `src/renderer/components/KeyedMedia.tsx`, `src/renderer/components/CanvasPreview.tsx`, `src/main/services/ffmpegEngine/filterGraphBuilder/chromaKeyBuilder.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts` |
| Pintasan dan panduan | `src/renderer/utils/editorShortcuts.ts`, `src/renderer/components/HelpPage.tsx`, `src/main/ipc/appHandlers.ts` |
| Eksekusi dan pengujian | `Jalankan-Magic-Render-Pro.bat`, `scripts/test-v5y-sync.cjs`, `scripts/run-current-tests.cjs`, `package.json`, `package-lock.json` |

Tidak ada file sumber yang dihapus. Preview visualizer menggunakan Web Audio
dan render menggunakan visualisasi FFT FFmpeg. Keduanya memakai opsi yang sama,
namun detail tiap piksel dan respons frekuensi dapat sedikit berbeda karena
algoritma audio kedua mesin berbeda. Uji pada media pengguna diperlukan untuk
memastikan tampilan yang diinginkan pada semua pilihan gaya.
