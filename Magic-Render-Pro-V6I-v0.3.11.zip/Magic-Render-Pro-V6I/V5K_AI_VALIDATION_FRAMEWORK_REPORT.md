# V5K — Diagnostik API dan Tinjauan AI Visual SEO

## Temuan pada HTTP 429

Stack CMD berasal dari `settings:configure-ai` → `SettingsService.configureAi` → `validateProvider` → OpenAI `/v1/chat/completions`. Uji validasi ini sebelumnya langsung menjalankan generasi dengan gambar 2×2 piksel. Pesan yang dikutip berarti respons HTTP 429 memang diterima dari endpoint tersebut. Klasifikasi lama menyamakan `insufficient_quota` dengan kredit habis/batas pengeluaran; kode itu sendiri tidak cukup untuk memastikan mana batas yang terjadi. Tanpa akses ke dashboard dan respons lengkap untuk masing-masing akun, saldo dan limit ketiga akun tidak dapat diverifikasi.

Key `sk-proj-...` dibuat pada project API; key baru tidak mengubah kredit, batas project, atau batas organisasi. Akun API baru dapat menggunakan prepaid billing. ChatGPT Plus ditagih terpisah dari API. `gpt-4o-mini` sesuai dengan endpoint Chat Completions yang dipakai aplikasi dan menerima input gambar; memilih model lain tidak memperbaiki 429 karena kuota.

## Perbaikan kode

- `src/main/services/aiService/aiProviderClient.ts`: tambahkan GET `/v1/models/{model}` untuk autentikasi dan akses model OpenAI tanpa generasi. POST kecil tetap dijalankan bila pengguna secara sadar menekan **Simpan & Validasi** atau **Check API Key**. Tampilkan `error.code` dan `x-request-id` yang aman jika tersedia; bedakan 401, 403, 404, quota/spend, dan rate limit. Tidak menampilkan API key atau respons mentah.
- `src/main/services/settingsService.ts`: key yang diterima oleh GET tetapi terhalang HTTP 429 saat POST disimpan secara terenkripsi dan diberi status *generasi belum siap*, tanpa exception IPC yang tercetak sebagai stack di CMD. Key tidak sah (401) tetap ditolak dan tidak mengganti key lama.
- `src/renderer/components/SettingsPanel.tsx`: status saat membuka Settings hanya melakukan autentikasi GET; status ini tidak dipresentasikan sebagai bukti siap generasi.
- `src/renderer/components/YoutubeSeoPanel.tsx`: status awal hanya GET; tombol Generate tidak mengirim POST validasi berbayar yang sama tepat sebelum POST generasi.
- `src/main/services/aiService/youtubeSeoService.ts`: HTTP 4xx dan output JSON yang tidak valid tidak dicoba ulang secara buta. Tiga percobaan hanya untuk HTTP 5xx sementara.
- `src/main/services/aiService/aiProviderClient.ts`: batas output OpenAI SEO `max_completion_tokens: 5000` dan padanan 5000 pada provider kompatibel.
- `src/main/services/aiService/promptBuilder.ts`: mencegah inferensi genre musik, lirik, artis, lokasi, dan tren dari gambar semata; fakta visual dan interpretasi dipisahkan dalam instruksi.
- Kontrak IPC terkait diperbarui di `src/shared/domain/aiTypes.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`, dan `src/main/ipc/settingsHandlers.ts`.
- `scripts/test-v5k-ai-diagnostics.cjs` baru; `scripts/test-v5j-sticker-ai-429.cjs` dan `scripts/verify-phase18.mjs` disesuaikan dengan perilaku dan endpoint saat ini.
- `docs/AI_Visual_SEO_Analysis_Framework.md` menyalin lampiran tanpa perubahan untuk referensi di baseline.

## Penilaian framework

| Risiko | Temuan saat ini | Arah implementasi berikutnya |
| --- | --- | --- |
| Metadata menyesatkan | Thumbnail adalah ilustrasi, tiga frame tidak membuktikan isi audio, lirik, lokasi, orang, atau genre. Prompt lama justru meminta model menebak genre dan perilaku penonton US. | Minta konteks channel/video yang ditulis pengguna. Simpan klaim sebagai **teramati**, **ditafsirkan**, atau **diberi pengguna**; klaim spekulatif hanya boleh masuk draf setelah disetujui. |
| Skor confidence palsu | Angka 98% dari satu model tanpa kalibrasi bukan probabilitas teruji. | Gunakan label *jelas/kurang jelas/tidak diketahui* dan tampilkan bukti frame; jika perlu skor numerik, ukur dan kalibrasi pada dataset nyata. |
| OCR | Model multimodal mungkin membaca teks, tetapi tiga frame video tidak menjamin teks thumbnail/overlay tercakup; teks kecil dan efek neon dapat keliru. | Masukkan thumbnail asli bila tersedia, lakukan OCR terpisah dan konfirmasi teks sebelum dipakai di judul. |
| Tren/kompetitor | Tanpa integrasi data eksternal yang sah, AI tidak punya tren pencarian atau volume real-time. | Jadikan mode online terpisah dengan sumber, waktu pengambilan, dan izin yang jelas. |
| Waktu/biaya | Kode mengekstrak tiga PNG tanpa penurunan resolusi dan meminta 50+50+25 keyword, 10 judul, tiga deskripsi sekaligus. Ukuran gambar dan panjang output memengaruhi token dan latensi. | Jadikan default ringkas, misalnya 5 judul, 8–15 keyword relevan, 1–2 deskripsi, 3–5 hashtag; tawarkan analisis mendalam sebagai pilihan dengan estimasi pemakaian dan batas token. Simpan hasil analisis untuk penggunaan ulang. |
| Retry | Sebelumnya semua error termasuk 429/JSON invalid dicoba sampai tiga kali. | V5K menghentikan retry jenis ini. Pertimbangkan tombol eksplisit untuk memperbaiki hanya JSON gagal, dengan informasi biaya tambahan. |

Framework yang dilampirkan belum diubah menjadi pipeline 26 tahap di aplikasi. Untuk menghasilkan metadata yang benar sesuai video, diperlukan form konteks channel/video/audio yang dapat dikonfirmasi pengguna, rancangan schema, dan uji hasil nyata. Perubahan V5K hanya menerapkan pengaman yang dapat diverifikasi tanpa menebak data tersebut.

## Verifikasi

`npm run build`, `test-v5k-ai-diagnostics`, `test-v5j-sticker-ai-429`, `test-v5h-settings-seo`, `test-ai-response`, dan `verify-phase18` lulus. Semua panggilan HTTP dalam test memakai mock; tidak ada key pengguna dalam workspace dan belum ada uji dengan akun pengguna atau UI Windows.
