# Magic Render Pro v5 — perbaikan lanjutan 4

## Akar masalah

- Paket sumber tidak menyertakan `ffmpeg.exe` dan `ffprobe.exe` (lihat `resources/ffmpeg/README.md`). Bila path Setting menunjuk ke executable yang tidak ada atau FFmpeg tidak menyediakan aliran progres, monitor tidak memiliki data untuk menggerakkan bar, persentase, speed, dan estimasi.
- Mesin render dibuat satu kali saat aplikasi dibuka. Setelah path FFmpeg/FFprobe diubah di Setting, instance yang sedang dipakai render tetap memakai path lama. Layanan impor media, intro, playlist, preview frame, dan SEO juga dapat menyimpan referensi path lama.
- Reader progres sebelumnya bergantung pada output `-progress` di stdout saja. Sekarang status encoding FFmpeg di stderr juga dibaca sebagai cadangan.
- Pause menghentikan tahap yang berjalan dan Resume mengulang tahap dari awal. Pada video panjang proses tersebut dapat memakan waktu; Reset kini menghentikan proses, melepas antrean monitor, lalu memungkinkan render baru.
- Pada Text Overlay, warna neon mengikuti warna teks sehingga tidak bisa dipilih terpisah. Preview mengandalkan `color` saja; fill color kini disetel eksplisit.

## Perubahan

- Setting otomatis menguji path FFmpeg/FFprobe dan keluaran progres saat dibuka, menampilkan diagnosis berbahasa Indonesia, serta menyediakan tombol **Uji FFmpeg & Monitor**. Render juga melakukan prauji dan menampilkan kesalahan yang dapat ditindaklanjuti bila mesin tidak siap.
- Path yang disimpan diterapkan pada mesin render dan layanan terkait tanpa perlu membuka ulang aplikasi. Pada render berikutnya engine memakai path tersimpan terbaru.
- Telemetri FFmpeg menerima `out_time_ms`, `out_time_us`, dan keluaran statistik `time=`/`speed=`; bar, persentase, speed, serta estimasi sisa memakai peristiwa aktual.
- **Reset Render** menghentikan proses saat berjalan atau dijeda, mereset monitor, dan mengabaikan pesan terlambat dari render lama. Cancel dan Reset menghentikan jam. Saat Resume, bar tahap kembali ke titik awal tahap dan kembali mengikuti progres FFmpeg.
- Tombol **Bersihkan Cache** dipindah ke pojok kanan atas menu Setting.
- Warna teks dan warna neon glow kini terpisah, ada pratinjau warna, dan warna diterapkan pada canvas serta filter drawtext video. Penerapan edit tanpa memilih teks menunjukkan instruksi yang jelas.

## Berkas yang diubah

`src/main/services/render/renderOrchestrator.ts`, `ffmpegEngine/ffmpegRunner.ts`, `ffmpegEngine/progressParser.ts`, `ffmpegEngine/textOverlayBuilder.ts`, `settingsService.ts`; `src/main/ipc/{renderHandlers,settingsHandlers,registerIpc,projectHandlers,playlistHandlers,introHandlers,previewHandlers,seoHandlers}.ts`; `src/shared/{ipc.ts,domain/renderTypes.ts}`; `src/preload/index.ts`; `src/renderer/{App.tsx,components/SettingsPanel.tsx,components/CanvasPreview.tsx,styles/index.css}`; `package.json`.

Berkas baru: `src/main/services/ffmpegEngine/engineDiagnostics.ts`, `scripts/test-v5d-regressions.cjs`, `V5D_FOLLOWUP_REPORT.md`. Tidak ada berkas yang dihapus.

## Pengujian

`npm run build`, `npm run typecheck`, `npm run test:render-engine`, `npm run test:orchestrator`, `npm run test:monitor-pause-cache`, `npm run test:critical-hotfixes`, dan `npm run test:v5d-regressions` lulus pada Linux dengan FFmpeg 6.1. Uji baru mencakup path mesin salah, keluaran progres normal dan cadangan stderr, Reset saat jeda, render ulang setelah Reset, path FFmpeg yang berubah, dan warna teks/neon pada filter.

Paket ini berupa sumber dan hasil build, tanpa executable FFmpeg Windows atau installer. Uji antarmuka Electron dan FFmpeg Windows tetap perlu dilakukan pada perangkat Windows; di Setting pilih lokasi `ffmpeg.exe` dan `ffprobe.exe`, lalu jalankan **Uji FFmpeg & Monitor** sampai status keduanya dan progres siap sebelum memulai render.
