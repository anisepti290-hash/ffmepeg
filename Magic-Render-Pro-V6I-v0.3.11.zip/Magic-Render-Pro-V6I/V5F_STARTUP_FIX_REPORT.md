# Perbaikan render macet di tahap persiapan (v5f)

## Temuan

Teks `[SISTEM] Permintaan render dikirim. Menyiapkan media dan output...` dibuat oleh Renderer sebelum pemanggilan IPC `render:start` selesai. Pada baseline v5e, `renderOrchestrator.ts` baru mengirim event pertama setelah membuat direktori sementara, memvalidasi folder output (`mkdir`, `access`, `statfs`), dan menulis log. Jika salah satu akses file Windows tersebut tertahan, monitor tetap menampilkan teks awal. Pemeriksaan media oleh `ffprobe` juga tidak memiliki timeout, sehingga sumber yang bermasalah atau FFprobe yang tidak merespons bisa menahan proses tanpa batas. Polling monitor menunggu pembacaan Console Log dalam `Promise.all`, sehingga respons log lambat dapat menahan pembacaan snapshot progres.

Tanpa log dari komputer pengguna, operasi Windows mana yang tertahan tidak dapat dipastikan. Masalah arsitektur yang membuatnya tidak terlihat dan tidak berbatas waktu berhasil direproduksi dengan folder output serta FFprobe yang sengaja dibuat macet.

## Perubahan

- `src/main/ipc/renderHandlers.ts`: kirim tanda terima segera saat permintaan render diterima; jaga pengiriman event ke jendela yang masih aktif.
- `src/main/services/render/renderOrchestrator.ts`: event setiap tahap persiapan, batas waktu 20 detik per langkah, error dengan nama tahap dan path yang terkait, Cancel selama persiapan, dan pencatatan sebab sebelum FFmpeg berjalan.
- `src/main/services/media/mediaProbe.ts`: FFprobe dibatasi waktunya, output metadata dibatasi, proses serta pipe ditutup bila timeout atau dibatalkan.
- `src/renderer/App.tsx`: polling progres terpisah dari pembacaan Console Log, waktu render bergerak selama persiapan, dan pemberitahuan bila IPC belum memberi respons setelah 12 detik. Cancel/Reset tetap tersedia.
- `scripts/test-render-startup.cjs` (baru), `scripts/test-live-monitor.cjs`, `package.json`: verifikasi tahap awal, timeout, pembatalan, IPC, dan output nyata.

Tidak ada file yang dihapus. Pipeline audio, overlay, intro, sticker, FPS, dan kualitas video dari v5e dipertahankan.

## Hasil pengujian

- `npm run build`: lulus.
- `npm run test:render-startup`: lulus. Folder output yang sengaja macet menghasilkan error terukur; FFprobe yang sengaja macet menghasilkan error; Cancel saat persiapan segera diterima; render FFmpeg sungguhan menghasilkan video dan progres.
- `npm run test:live-monitor-ipc`: lulus; tanda terima IPC dan snapshot progres terkirim.
- `node scripts/test-render-orchestrator.cjs` serta `node scripts/test-monitor-pause-cache.cjs`: lulus untuk komposisi dan kontrol render.

Verifikasi dilakukan pada Linux dengan FFmpeg lokal. Perilaku Windows yang spesifik perlu diuji pada komputer pengguna. ZIP berisi source dan build Electron, bukan installer Windows; executable FFmpeg/FFprobe harus tersedia sesuai Path di Settings.
