# V5J — Sticker Canvas dan Diagnostik OpenAI 429

## Akar masalah

- `CanvasPreview.tsx` hanya menggambar sticker ketika waktu preview berada dalam jadwal. Sticker baru dijadwalkan pada 00:30 oleh `stickerService.ts`, sedangkan canvas pertama kali dibuka pada 00:00. Akibatnya sticker tidak dapat dilihat atau diatur pada canvas sebelum memutar/menggeser timeline.
- `aiProviderClient.ts` membuang kode error dari respons OpenAI dan memberi satu pesan umum untuk seluruh respons HTTP 429. Padahal kuota kredit atau batas biaya berbeda dari rate limit, dan bukan otomatis berarti format `sk-proj-...` salah.
- `SettingsPanel.tsx` memvalidasi model dengan POST setiap perubahan teks ID model. Ini bisa menghasilkan permintaan tambahan yang tidak perlu.

## Perubahan

- `src/renderer/components/CanvasPreview.tsx`: mode edit menampilkan sticker terlepas dari jadwal. Play/seek mengikuti jadwal asli. Tombol `Lihat jadwal sticker` / `Tampilkan sticker untuk edit` berpindah mode. Eye visibility tetap berlaku.
- `src/main/services/aiService/aiProviderClient.ts`: baca kode error API; tampilkan pesan Indonesia yang membedakan kredit/batas biaya, rate limit, 401, 403, dan 404. Jalur Generate SEO juga memakai diagnostik aman tanpa menampilkan kunci/respons mentah.
- `src/renderer/components/SettingsPanel.tsx`: validasi otomatis tidak terjadi di setiap ketikan model. `gpt-4o-mini` menjadi saran awal OpenAI. `Simpan Key Saja` menyimpan terenkripsi tanpa mengklaim berhasil divalidasi saat billing sedang dibatasi; `Check API Key` memeriksa lagi setelah billing pulih.
- `src/main/services/settingsService.ts`, `src/main/domain/project/projectFactory.ts`: model default OpenAI `gpt-4o-mini` untuk project baru; pilihan project lama tetap disimpan.
- `src/main/ipc/settingsHandlers.ts`, `src/preload/index.ts`, `src/shared/ipc.ts`: meneruskan opsi simpan key tanpa validasi dengan pemeriksaan tipe IPC.
- `scripts/test-v5j-sticker-ai-429.cjs`: pengujian tampilan sticker awal, eye hide, dan respons API 429/401.

Tidak ada file dihapus. Pengujian: `npm run build`, `node scripts/test-v5j-sticker-ai-429.cjs`, `node scripts/test-v5h-settings-seo.cjs`, `node scripts/test-user-14-fixes.cjs` semuanya lulus. Validasi nyata API dan Windows UI memerlukan kunci serta lingkungan pengguna; keduanya tidak dilakukan di sini.

## Cara memakai OpenAI API

ChatGPT Plus dan penggunaan API memiliki tagihan terpisah. Buka Billing/Usage/Limits project di platform.openai.com, aktifkan pembayaran/kredit API dan pastikan batas pemakaian mengizinkan generasi. Pilih provider OpenAI, model `gpt-4o-mini` untuk input keyframe gambar, lalu `Simpan & Validasi`. Jika masih 429 karena kuota, `Simpan Key Saja` menyimpan key sampai billing siap; klik `Check API Key` sesudahnya. Respons 429 dengan `rate_limit_exceeded` perlu jeda/menurunkan frekuensi permintaan. Jangan mengirim API key ke pihak lain.
