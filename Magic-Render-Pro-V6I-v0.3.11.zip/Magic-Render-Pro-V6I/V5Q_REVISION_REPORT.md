# Magic Render Pro 0.2.1 — V5Q

## Penyebab dan perbaikan

| Keluhan | Penyebab | File yang diubah |
| --- | --- | --- |
| Stiker pindah posisi setelah export | Koordinat X/Y dibatasi paksa ke 0..lebar/tinggi canvas sebelum dikirim ke FFmpeg. Layer yang diedit sebagian di luar canvas bergeser pada export. Jalur filter stiker mandiri juga melewatkan skala resolusi. | `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/main/services/stickerService.ts` |
| Stiker tampak seperti Screen atau rendah opacity | Jalur normal selalu mengonversi frame stiker ke RGBA dan mengisi padding walau opacity 100%, tanpa keying/fade/rotasi. Proses ini dihilangkan pada jalur stiker biasa; transparansi bawaan PNG tetap dihormati. Mode Blend Screen tetap bekerja saat memang dipilih. | `src/main/services/ffmpegEngine/stickerFilterBuilder.ts` |
| CPU lambat | Komposisi RGBA/padding berulang pada stiker biasa dan preset Standar `fast`. Jalur overlay langsung memakai ukuran sumber untuk posisi contain; Standar CPU sekarang `veryfast` dengan target CRF 20 dan batas bitrate semula. Preset Cepat tetap `veryfast` CRF 21, Pelan tetap `slow` CRF 19. | `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/main/services/render/encodingBuilder.ts`, `src/renderer/components/SettingsPanel.tsx` |
| Output terlalu besar | Mode CBR dapat menghasilkan file lebih besar daripada VBR pada adegan yang sederhana. VBR yang sudah tersedia tetap menjadi default dan memakai CRF serta batas bitrate. Jalur video final tetap sekali encode; AAC playlist disalin ke hasil. Perubahan preset dan filter dapat membantu ukuran, tetapi hasil bergantung konten. Tidak ada janji byte identik dan ukuran lebih kecil secara bersamaan. | `src/main/services/render/encodingBuilder.ts`, `src/renderer/components/SettingsPanel.tsx` |
| CMD `settings:ai-models` gagal tanpa API key | Panel Settings otomatis memanggil daftar model sebelum key provider tersedia; service melempar error. Kini panel menunggu status kunci dan service mengembalikan daftar kosong jika key belum ada. Tombol Muat Model tetap bisa memakai key yang diketik atau tersimpan. | `src/renderer/components/SettingsPanel.tsx`, `src/main/services/settingsService.ts` |

`README.md`, Help di `src/main/ipc/appHandlers.ts`, dan `package.json`/`package-lock.json` diperbarui ke 0.2.1. Tidak ada berkas sumber yang dihapus. `scripts/test-v5q-sticker-cpu-ai.cjs` ditambah untuk memeriksa posisi negatif, posisi 720p, opacity stiker penuh, jalur CPU, dan API key kosong.

## Pengujian

- `npm run build`: lulus.
- `node scripts/test-v5q-sticker-cpu-ai.cjs`: lulus.
- `node scripts/test-v5o-revisions.cjs`, `node scripts/test-v5i-blend-sticker-timing.cjs`: lulus untuk alfa PNG, jadwal, serta berbagai blend.
- `node scripts/test-render-orchestrator.cjs`: lulus render end to end dengan playlist, intro, overlay, stiker, monitor.
- `node scripts/test-v5l-free-seo.cjs`: lulus tes katalog provider lokal dan SEO.
- Benchmark lokal sintetis 5 detik, 720p, 30 fps, 4 thread, CRF 20: `fast` 974 ms / 2,394,123 byte; `veryfast` 702 ms / 2,139,948 byte. Angka ini hanya untuk sampel pengujian, bukan proyeksi waktu atau ukuran berkas pengguna.

Aplikasi GUI Windows dan video 3 menit asli belum dapat diuji pada perangkat pengguna. Warna/ukuran hasil H.264 dapat berubah sedikit ketika preset berbeda walau CRF sama. Memperkecil setiap berkas yang sudah terkompresi tanpa sedikit pun perubahan kualitas atau data tidak dapat dijamin.
