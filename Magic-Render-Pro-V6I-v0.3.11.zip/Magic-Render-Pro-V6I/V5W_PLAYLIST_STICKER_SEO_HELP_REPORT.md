# Magic Render Pro V5W — playlist, sticker, timestamp, SEO, Help

Baseline: V5V. Versi aplikasi: 0.2.7.

## Penyebab dan perbaikan

1. **Urutan lagu tidak sinkron:** fungsi reorder sebelumnya memindah `playlistTracks`, namun mempertahankan `playbackOrder` lama. Audio render dan timestamp membaca urutan lama. Sekarang pengurutan dan penghapusan beroperasi pada urutan yang terlihat, termasuk setelah Shuffle, lalu menyimpan keduanya konsisten. Resolver bersama juga dipakai oleh menu Playlist dan Canvas Preview. Panel tidak lagi menerima ringkasan playlist asinkron yang dapat menimpa urutan terkini. Reset preview ke 00:00 memuat ulang audio dan urutan proyek terbaru.
2. **Sticker berulang:** nilai `iterativeCount` yang tersimpan kini berarti **interval menit**, bukan jumlah kemunculan tersebar. Angka 3 menjadwalkan 00:00, 03:00, 06:00, dan seterusnya hingga video berakhir. Durasi tampil dibatasi agar satu interval tidak tumpang tindih dengan interval berikutnya. Preview dan render memakai `buildScheduleWindows` yang sama.
3. **Timestamp dan deskripsi SEO:** `youtubetimestamp.txt` sekarang berisi baris waktu dan judul saja. Awalan nomor pada nama file dibuang, garis bawah menjadi spasi, judul menjadi Title Case. Tracklist di paragraf `youtubeSEO.txt` mengikuti format yang sama dan tidak menyertakan label Intro.
4. **Tag SEO:** seluruh kumpulan 50 keyword utama dan 50 sekunder dinilai terhadap keyword pengguna, genre, analisis media, dan tujuan audiens. Kandidat tertinggi disaring dari duplikasi dan dipotong hingga gabungannya kurang dari 500 karakter. Data **volume pencarian YouTube yang terukur** tidak tersedia lewat API AI yang dikonfigurasi. Aplikasi tidak mengklaim angka volume/tren nyata; untuk itu diperlukan akses ke data Analytics channel yang diotorisasi. Lihat dokumentasi: https://developers.google.com/youtube/analytics/sample-requests dan https://developers.google.com/youtube/v3/docs/search/list.
5. **Help:** User Guide dan Troubleshooting menjadi artikel di aplikasi dengan bab, baris terpisah, ikon, penekanan, dan langkah yang spesifik. Dialog native untuk topik tersebut juga diringkas dengan jeda baris.

## Berkas yang diubah atau ditambah

- `src/shared/domain/playlistOrder.ts` **baru**; `src/main/services/audio/playlistService.ts`; `src/renderer/components/PlaylistPanel.tsx`; `src/renderer/components/CanvasPreview.tsx`.
- `src/shared/domain/stickerTimeline.ts`, `stickerTypes.ts`; `src/renderer/components/StickerPanel.tsx`.
- `src/main/services/aiService/timestampGenerator.ts`, `seoFileWriter.ts`, `seoPipeline.ts`, `youtubeSeoService.ts`; `seoTags.ts` **baru**; `src/renderer/components/YoutubeSeoPanel.tsx`.
- `src/renderer/components/HelpPage.tsx` **baru**; `src/renderer/App.tsx`; `src/renderer/styles/index.css`; `src/main/ipc/appHandlers.ts`.
- `package.json`, `package-lock.json`; `scripts/test-v5w-playlist-sticker-seo.cjs` **baru**, `scripts/test-v5i-blend-sticker-timing.cjs`, `scripts/test-phase22-unit.cjs`.

Tidak ada berkas yang dihapus. `dist` dibangun ulang dari source.

## Pengujian

- `npm run build` dan `npm run test:playlist`.
- `node scripts/test-v5w-playlist-sticker-seo.cjs`: import 10 MP3, hapus satu, import baru, pindahkan ke urutan pertama, hasilkan audio FFmpeg, periksa plan, timestamp, sticker 3 menit, dan tag <500 karakter.
- `node scripts/test-v5t-seo-format.cjs`, `node scripts/test-v5i-blend-sticker-timing.cjs`, `node scripts/test-phase22-unit.cjs`, `node scripts/test-render-orchestrator.cjs`.

Uji Electron visual Windows, playlist asli pengguna, dan volume pencarian nyata memerlukan lingkungan/data pengguna.
