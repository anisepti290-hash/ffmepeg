# Magic Render Pro V5T — YouTube SEO

## Perubahan

- `youtubeSEO.txt` kini berisi judul dalam tiga pola (4/3/3 pilihan), deskripsi siap tempel dengan pembuka, jembatan dari draf Premium Channel, intensi audiens, daftar waktu dan judul lagu dari playlist, penutup natural, satu baris hashtags, serta tags. Timestamp tidak dikarang bila playlist kosong.
- Pada Opsi 2, sumber visual dapat dipilih dari main media atau gambar/video manual. Tombol pemilihan video final dihilangkan dari antarmuka. Generate langsung berjalan dengan indikator loading, bahkan sebelum render final selesai.
- Analisis 125 kandidat keyword disimpan menurut sidik media, keyword, niche, provider, dan model; pengulangan input yang sama memakai ulang tahap analisis visual. Prompt tahap penulisan hanya membawa sebagian kandidat yang paling relevan. Output yang berubah tetap dibuat ulang; edit media atau parameter membatalkan cache.
- Nomor aplikasi dinaikkan ke `0.2.4` dan Help diperbarui.

## Akar masalah dan berkas yang diubah

Format sebelumnya menggabungkan keluaran riset dan draf tanpa menyusun deskripsi siap tempel serta mewajibkan video final pada IPC/UI. Pengulangan juga mengirim ulang frame dan keseluruhan daftar keyword. Perubahan utama ada pada `src/main/services/aiService/seoPipeline.ts`, `seoFileWriter.ts`, `youtubeSeoService.ts`, `seoAnalysisCache.ts` (baru), `keyframeExtractor.ts`, `src/main/ipc/seoHandlers.ts`, `src/renderer/components/YoutubeSeoPanel.tsx`, tipe/IPC/preload, dan validasi project. Pengujian ada pada `scripts/test-v5t-seo-format.cjs` serta pengujian regresi yang diperbarui. Tidak ada berkas sumber yang dihapus.

## Verifikasi

- `npm run build` dan `npm run typecheck` lulus.
- Pengujian format file, service dua tahap, pemilihan manual, reuse cache, IPC, provider gratis, dan render orchestrator lulus.
- Keluaran model langsung pada akun/provider pengguna belum dapat diuji tanpa API key; validasi struktur dan perilaku diamati menggunakan respons model tiruan. Pengecekan biaya nyata bergantung pada harga dan batas model pilihan. Cache menghemat tahap analisis visual pada input identik; tahap penulisan tetap menggunakan token untuk hasil baru.
