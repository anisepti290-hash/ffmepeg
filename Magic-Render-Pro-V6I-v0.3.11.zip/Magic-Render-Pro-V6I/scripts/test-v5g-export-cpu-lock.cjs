const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const cp = require('node:child_process');
const Module = require('node:module');
const ts = require('typescript');
Module._extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText, filename);
const { getResolution } = require('../src/main/services/ffmpegEngine/resolutionMap.ts');
const { renderEncodingProfile } = require('../src/main/services/render/encodingBuilder.ts');
const { applyFfmpegThreadMapping, calculateSafeFfmpegThreads } = require('../src/main/services/cpuController.ts');
const { applyPreviewVisualUpdate } = require('../src/shared/domain/previewTypes.ts');
const { FfmpegProcess } = require('../src/main/services/ffmpegEngine/ffmpegRunner.ts');
assert.deepEqual(getResolution('720p'), {width:1280,height:720});
assert.deepEqual(['fast','standard','slow'].map((preset) => renderEncodingProfile(preset).preset), ['veryfast','fast','slow']);
assert.equal(calculateSafeFfmpegThreads(60,8),4);
const mapped = applyFfmpegThreadMapping(['-y','-i','input.mp4','-c:v','libx264','out.mp4'],60,8);
assert.deepEqual(mapped, ['-y','-filter_threads','4','-filter_complex_threads','4','-i','input.mp4','-c:v','libx264','-threads:v','4','out.mp4']);
const overlay = {id:'o',locked:true,config:{position:{x:12,y:24},resize:{width:42,height:35},rotation:0}};
const sticker = {id:'s',locked:true,config:{position:{x:100,y:120},scale:1,rotation:0}};
const project = {overlays:[overlay],stickerSubscribe:sticker,stickerSubscribes:[sticker]};
assert.strictEqual(applyPreviewVisualUpdate(project,{kind:'overlay',id:'o',position:{x:99,y:99}}).overlays[0],overlay);
assert.strictEqual(applyPreviewVisualUpdate(project,{kind:'sticker',id:'s',position:{x:99,y:99}}).stickerSubscribes[0],sticker);
assert.equal(applyPreviewVisualUpdate({...project, overlays:[{...overlay,locked:false}]},{kind:'overlay',id:'o',position:{x:99,y:99}}).overlays[0].config.position.x,99);
(async () => {
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-v5g-'));
 try {
  const out=path.join(dir,'720p.mp4'); const progress=[]; const warnings=[];
  const result=await new FfmpegProcess(60).run({executable:'ffmpeg',args:['-y','-f','lavfi','-i','color=c=blue:s=320x180:r=24','-vf','scale=1280:720','-t','1','-c:v','libx264','-preset','veryfast','-pix_fmt','yuv420p',out]}, {onProgress:(p)=>progress.push(p), onOutput:(line)=>{if(line.startsWith('[CPU]'))warnings.push(line)}});
  assert.equal(result.exitCode,0,result.stderr.slice(-1500));
  assert.equal(warnings.length,0,warnings.join('; '));
  assert(progress.some((p)=>p.outTimeSec>0),'FFmpeg progress missing');
  const probe=cp.execFileSync('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','csv=p=0',out],{encoding:'utf8'}).trim();
  assert.equal(probe,'1280,720');
  console.log('V5G 720p, presets, CPU mapping/affinity, preview lock, FFmpeg progress: PASSED');
 } finally {fs.rmSync(dir,{recursive:true,force:true});}
})().catch((error)=>{console.error(error);process.exitCode=1});
