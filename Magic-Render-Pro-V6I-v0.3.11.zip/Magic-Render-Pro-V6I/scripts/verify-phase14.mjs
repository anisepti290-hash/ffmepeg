import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/shared/domain/renderTypes.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'src/main/services/render/renderOrchestrator.ts',
  'src/main/services/render/renderStrategySelector.ts',
  'src/main/ipc/renderHandlers.ts',
  'src/renderer/App.tsx',
  'scripts/verify-phase14.mjs',
];
for (const file of required) if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
const orch = fs.readFileSync(path.join(root,'src/main/services/render/renderOrchestrator.ts'),'utf8');
const ipc = fs.readFileSync(path.join(root,'src/shared/ipc.ts'),'utf8');
const preload = fs.readFileSync(path.join(root,'src/preload/index.ts'),'utf8');
const handler = fs.readFileSync(path.join(root,'src/main/ipc/renderHandlers.ts'),'utf8');
const app = fs.readFileSync(path.join(root,'src/renderer/App.tsx'),'utf8');
const checks = [
  ["state machine statuses", ['idle','processing_audio','assembling_overlay','composing_text','compressing_video','done','error','paused','cancelled'].every(x => orch.includes(`'${x}'` ) || fs.readFileSync(path.join(root,'src/shared/domain/renderTypes.ts'),'utf8').includes(`'${x}'`))],
  ['render progress payload', ['percent','totalDurationSec','elapsedRenderSec','speedMultiplier'].every(x => fs.readFileSync(path.join(root,'src/shared/domain/renderTypes.ts'),'utf8').includes(x))],
  ['render control channel', ipc.includes("RENDER_CONTROL: 'render:control'")],
  ['preload control exposure', preload.includes('controlRender')],
  ['handler control registration', handler.includes('IPC_CHANNELS.RENDER_CONTROL')],
  ['pause boundary', orch.includes('maybePauseAtBoundary') && orch.includes('Menunggu titik aman untuk jeda')],
  ['checkpoint file', orch.includes('checkpoint.json')],
  ['resume continuation', orch.includes('resumeResolve') && orch.includes('active.resumePromise')],
  ['SIGKILL cancel', orch.includes('active.process.cancel()')],
  ['UI controls', ['Render','Pause','Resume','Cancel'].every(x => app.includes(x))],
  ['UI metrics', ['elapsed','total','speedMultiplier'].every(x => app.includes(x) || app.includes('renderProgress'))],
];
for (const [name, ok] of checks) if (!ok) throw new Error(`FAIL: ${name}`);
console.log(`PHASE 14 STATIC VERIFY: PASSED (${required.length} core files, ${checks.length} checks).`);
