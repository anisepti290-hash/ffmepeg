const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'mrp-error-translator-'));
try {
  execFileSync('tsc', [
    '--target', 'ES2022', '--module', 'commonjs', '--moduleResolution', 'node',
    '--strict', '--esModuleInterop', '--skipLibCheck',
    '--outDir', temp,
    'src/main/services/ffmpegEngine/errorTranslator.ts',
    'src/shared/domain/renderTypes.ts'
  ], { stdio: 'pipe' });
  const { translateFfmpegError, getErrorRules } = require(path.join(temp, 'main/services/ffmpegEngine/errorTranslator.js'));
  const moov = translateFfmpegError('Input #0, mov: ...\nmoov atom not found');
  if (moov.code !== 'MOOV_ATOM_NOT_FOUND' || !/rusak/i.test(moov.message) || !/import ulang/i.test(moov.solution)) throw new Error('Moov translation failed.');
  const permission = translateFfmpegError('Error opening output file: Permission denied', { stage: 'output', exitCode: 1 });
  if (permission.code !== 'PERMISSION_DENIED') throw new Error('Permission translation failed.');
  const unknown = translateFfmpegError('unexpected codec failure', { stage: 'output', exitCode: 9 });
  if (unknown.code !== 'FFMPEG_UNKNOWN_ERROR') throw new Error('Fallback translation failed.');
  if (getErrorRules().length < 6) throw new Error('Extensible rule registry missing.');
  console.log('ERROR TRANSLATOR TEST: PASSED (3 translation paths + extensible rule registry).');
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}
