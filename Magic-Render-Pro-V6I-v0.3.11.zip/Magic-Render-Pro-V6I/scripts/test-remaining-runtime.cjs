const fs = require('node:fs');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
function assert(c, m) { if (!c) throw new Error(m); }
const previousTs = Module._extensions['.ts'];
Module._extensions['.ts'] = function(mod, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const out = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true },
    fileName: filename,
  }).outputText;
  mod._compile(out, filename);
};
try {
  const command = require(path.join(root, 'src/main/services/ffmpegEngine/commandBuilder.ts'));
  const overlay = require(path.join(root, 'src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.ts'));
  const blend = require(path.join(root, 'src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts'));
  const text = require(path.join(root, 'src/main/services/ffmpegEngine/textOverlayBuilder.ts'));
  const audio = require(path.join(root, 'src/main/services/audio/audioConcatBuilder.ts'));
  const controls = { autoMute: true, fadeInSec: 1, fadeOutSec: 2, resize: { width: 640, height: 360 }, position: { x: 100, y: 50 }, rotation: 15 };
  const f = command.buildMainMediaFilterGraph(controls, 1920, 1080, 10);
  assert(f.includes('pad=1920:1080:100:50:color=black@0'), '#10 main media position missing');
  assert(f.includes('rotate=15*PI/180:fillcolor=black@0'), '#10 rotation missing');
  assert((f.match(/fade=/g) || []).length === 2, '#10 fade count wrong');
  const ov = new overlay.OverlayFilterBuilder();
  assert(ov.buildPreOverlayFilters({ type: 'image', config: { speed: 1, resize: null, rotation: 20, opacity: 0.5 } }, 'in', 'out').includes('format=rgba'), '#8 overlay alpha format missing');
  assert(ov.buildPositionedLayer('a', 'b', 1920, 1080, 5, 7).includes('format=rgba'), '#8 pad alpha format missing');
  const bf = new blend.BlendFilterBuilder().build('base', 'ov', 'out', 'screen');
  assert(bf.includes('format=gbrp') && bf.includes('maskedmerge'), '#9 RGB blend and alpha mask missing');
  const tc = { text: 'RUNNING', fontFamily: 'Arial', fontSize: 50, fontColor: '#ffffff', strokeColor: '#000000', strokeWidth: 1, glowColor: '#ffffff', glowBlur: 2, neonGlow: true, bold: true, italic: false, underline: true, opacity: 0.4, speed: 2, position: { x: 100, y: 100 }, animation: 'running-left' };
  const tg = new text.TextOverlayBuilder().build({ id: 'x', config: tc }, 'in', 'out', 10);
  const pg = new text.TextOverlayBuilder().build({ id: 'p', config: { ...tc, animation: 'pulse' } }, 'in', 'out', 10);
  assert(tg.includes('w-mod(t*'), '#12 running animation missing');
  assert(!tg.includes("text='________________'"), '#13 fixed underline remains');
  assert(pg.includes("alpha='0.4*"), '#14 animation opacity not multiplied');
  const plan = { totalDurationSeconds: 6, targetDurationSeconds: 6, segments: [{ path: 'same.mp3', durationSeconds: 3 }, { path: 'same.mp3', durationSeconds: 3 }] };
  const ac = audio.buildAudioConcatCommand('ffmpeg', plan, 'out.aac', 6);
  assert(ac.args.filter((x) => x === '-i').length === 1, '#16 repeated audio input not deduped');
  console.log('REMAINING FIXES RUNTIME VERIFY: TEST PASSED');
} finally {
  if (previousTs) Module._extensions['.ts'] = previousTs;
  else delete Module._extensions['.ts'];
}
