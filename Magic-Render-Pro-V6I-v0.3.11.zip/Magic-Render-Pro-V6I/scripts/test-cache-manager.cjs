const fs = require('node:fs');
const fsp = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');
const ts = require('typescript');

const project = process.cwd();
const buildRoot = path.join(project, '.cache-test-build');
const outputDir = path.join(buildRoot, 'main');

async function prepareCompiledModule() {
  await fsp.rm(buildRoot, { recursive: true, force: true });
  await fsp.mkdir(path.join(outputDir, 'services', 'cache'), { recursive: true });
  await fsp.mkdir(path.join(outputDir, 'utils'), { recursive: true });
  await fsp.mkdir(path.join(buildRoot, 'node_modules', 'electron'), { recursive: true });

  const source = await fsp.readFile(path.join(project, 'src/main/services/cache/cacheManager.ts'), 'utf8');
  const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText;
  await fsp.writeFile(path.join(outputDir, 'services/cache/cacheManager.js'), js, 'utf8');
  await fsp.writeFile(path.join(outputDir, 'utils/logger.js'), "exports.logger={warn(){},info(){},error(){},debug(){}};\n", 'utf8');
  await fsp.writeFile(path.join(buildRoot, 'node_modules/electron/index.js'), "exports.app={getPath(){return require('node:os').tmpdir();}};\n", 'utf8');
  return require(path.join(outputDir, 'services/cache/cacheManager.js')).CacheManager;
}

async function assert(condition, message) {
  if (!condition) throw new Error(message);
}

(async () => {
  const CacheManager = await prepareCompiledModule();
  const root = await fsp.mkdtemp(path.join(os.tmpdir(), 'mrp-cache-test-'));
  const cacheRoot = path.join(root, 'MagicRenderPro');
  const outputPath = path.join(root, 'final-output.mp4');
  const sourcePath = path.join(root, 'source.mp4');
  await fsp.writeFile(outputPath, 'FINAL');
  await fsp.writeFile(sourcePath, 'SOURCE');

  const manager = new CacheManager(cacheRoot);
  const job = await manager.createRenderJob('project-123');
  const renderDir = await manager.prepareArtifactDirectory(job, 'render');
  const keyframeDir = await manager.prepareArtifactDirectory(job, 'keyframe');
  const audioDir = await manager.prepareArtifactDirectory(job, 'audio');
  const logDir = await manager.prepareArtifactDirectory(job, 'log');
  await fsp.writeFile(path.join(renderDir, 'stage.mp4'), 'render');
  await fsp.writeFile(path.join(keyframeDir, 'frame.png'), 'frame');
  const readOnlyAudio = path.join(audioDir, 'temp.aac');
  await fsp.writeFile(readOnlyAudio, 'audio');
  await fsp.chmod(readOnlyAudio, 0o444);
  await manager.appendRenderLog(job, 'test log');

  let rejected = false;
  try { manager.assertTempArtifact(outputPath, job); } catch { rejected = true; }
  await assert(rejected, 'Output path protection did not reject external output.');
  rejected = false;
  try { manager.assertTempArtifact(sourcePath, job); } catch { rejected = true; }
  await assert(rejected, 'Source path protection did not reject external source.');

  const cleanup = await manager.cleanupJob(job);
  await assert(cleanup.failed.length === 0, `Cleanup had failures: ${JSON.stringify(cleanup.failed)}`);
  await assert(!(await fsp.stat(job).catch(() => null)), 'Job directory was not removed.');
  await assert((await fsp.readFile(outputPath, 'utf8')) === 'FINAL', 'Final output was deleted.');
  await assert((await fsp.readFile(sourcePath, 'utf8')) === 'SOURCE', 'Project source was deleted.');

  const stale = await manager.createRenderJob('stale-project');
  await fsp.utimes(stale, new Date(Date.now() - 2 * 24 * 3600 * 1000), new Date(Date.now() - 2 * 24 * 3600 * 1000));
  const staleResults = await manager.cleanupStaleJobs(24 * 3600 * 1000);
  await assert(staleResults.length === 1, 'Stale job cleanup did not detect the old job.');
  await assert(!(await fsp.stat(stale).catch(() => null)), 'Stale job was not removed.');

  await fsp.rm(root, { recursive: true, force: true });
  await fsp.rm(buildRoot, { recursive: true, force: true });
  console.log('CACHE MANAGER TEST: PASSED (root isolation, category cleanup, retry-safe read-only cleanup, output/source protection, stale cleanup).');
})().catch(async (error) => {
  await fsp.rm(buildRoot, { recursive: true, force: true }).catch(() => undefined);
  console.error(error.stack || error.message || error);
  process.exit(1);
});
