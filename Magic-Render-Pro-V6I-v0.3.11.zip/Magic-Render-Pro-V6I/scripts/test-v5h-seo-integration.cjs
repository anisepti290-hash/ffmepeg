const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const Module=require('node:module');
const ts=require('typescript');
const handlers=new Map();const calls=[];
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-seo-ipc-'));const video=path.join(tmp,'final.mp4');fs.writeFileSync(video,'video fixture');
for (const ext of ['.ts','.tsx']) Module._extensions[ext]=(mod,file)=>mod._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true,jsx:ts.JsxEmit.ReactJSX}}).outputText,file);
const realLoad=Module._load;
Module._load=function(request,parent,isMain){
 if(parent?.filename.endsWith('ipc/seoHandlers.ts')){
  if(request==='electron')return {BrowserWindow:{getAllWindows:()=>[]}};
  if(request==='./loggedHandler')return {registerIpcHandler:(key,fn)=>handlers.set(key,fn)};
  if(request==='./validation')return {assertProjectData:(p)=>p,assertAllowedString:(v)=>{if(typeof v!=='string'||!v.trim())throw Error('Invalid')}};
  if(request==='./dialogHelper')return {showOpenDialog:async()=>({canceled:false,filePaths:[video]})};
  if(request==='./settingsHandlers')return {settingsService:{get:()=>({aiProvider:'gemini',aiModel:'gemini-2.0-flash'}),getAiCredentials:()=>({model:'gemini-2.0-flash',apiKey:'secret'})}};
  if(request==='../services/aiService/youtubeSeoService')return {YoutubeSeoService:class{async generate(r){calls.push(r);return {titles:['ok'],outputFiles:{seoTxt:'seo.txt',timestampTxt:'timestamps.txt'}}}}};
 }
 return realLoad.apply(this,arguments);
};
const {registerSeoIpcHandlers}=require('../src/main/ipc/seoHandlers.ts');
const {IPC_CHANNELS}=require('../src/shared/ipc.ts');
registerSeoIpcHandlers({runtime:{ffmpegPath:'ffmpeg',ffprobePath:'ffprobe'}});
(async()=>{
 assert.equal(await handlers.get(IPC_CHANNELS.SEO_CHOOSE_VIDEO)(null),video);
 assert.equal(await handlers.get(IPC_CHANNELS.SEO_CHOOSE_MEDIA)(null),video);
 const React=require('react');const {renderToStaticMarkup}=require('react-dom/server');
 const {YoutubeSeoPanel}=require('../src/renderer/components/YoutubeSeoPanel.tsx');
 const html=renderToStaticMarkup(React.createElement(YoutubeSeoPanel,{project:{projectId:'id',youtubeSEO:{mode:'timestamp-seo',mainKeyword:'whiskey blues',context:{nicheGenre:'slow blues'},provider:'openai',model:'stale'}},onProjectChange:()=>{},onMessage:()=>{},onOpenSettings:()=>{},lastRenderOutputPath:null}));
 assert.match(html,/<button[^>]*>Generate YouTube SEO<\/button>/,'Generate button disabled without session render');
 assert.doesNotMatch(html,/Pilih Video Final/);
 const project={projectId:'id',youtubeSEO:{mode:'timestamp-seo',mainKeyword:'whiskey blues',context:{nicheGenre:'slow blues'},provider:'openai',model:'stale'}};
 const result=await handlers.get(IPC_CHANNELS.SEO_GENERATE)(null,project);
 assert.equal(result.titles[0],'ok');assert.equal(calls[0].provider,'gemini');assert.equal(calls[0].model,'gemini-2.0-flash');assert.equal(calls[0].outputPath,undefined);
 await assert.rejects(handlers.get(IPC_CHANNELS.SEO_GENERATE)(null,{...project,youtubeSEO:{...project.youtubeSEO,mode:'timestamp'}},video),/Opsi 2/);
 await assert.rejects(handlers.get(IPC_CHANNELS.SEO_GENERATE)(null,project,path.join(tmp,'missing.mp4')),/belum ditemukan/);
 console.log('V5H SEO IPC VIDEO PICKER, GLOBAL AI CONFIGURATION, GENERATE: PASSED');
})().catch(e=>{console.error(e);process.exitCode=1}).finally(()=>{fs.rmSync(tmp,{recursive:true,force:true});Module._load=realLoad});
