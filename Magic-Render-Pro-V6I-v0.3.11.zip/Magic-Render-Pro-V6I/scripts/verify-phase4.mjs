import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/shared/domain/mediaTypes.ts',
  'src/main/services/media/mediaImporter.ts',
  'src/main/services/media/mediaValidator.ts',
  'src/main/services/media/mediaProbe.ts',
  'src/main/services/media/mainMediaControls.ts',
  'src/main/services/media/mediaService.ts',
  'src/main/services/ffmpegEngine/resolutionMap.ts',
  'src/main/services/ffmpegEngine/commandBuilder.ts',
  'src/main/services/ffmpegEngine/mainMediaPrep.ts',
  'src/main/services/ffmpegEngine/ffmpegRunner.ts',
  'src/main/services/project/projectService.ts',
  'src/main/ipc/projectHandlers.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
];
for (const file of required) if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const types = read('src/shared/domain/projectTypes.ts');
const builder = read('src/main/services/ffmpegEngine/commandBuilder.ts');
const prep = read('src/main/services/ffmpegEngine/mainMediaPrep.ts');
const probe = read('src/main/services/media/mediaProbe.ts');
const validator = read('src/main/services/media/mediaValidator.ts');
const service = read('src/main/services/media/mediaService.ts');
const ipc = read('src/shared/ipc.ts');
const handler = read('src/main/ipc/projectHandlers.ts');
const runner = read('src/main/services/ffmpegEngine/ffmpegRunner.ts');
if (!types.includes('metadata: MediaMetadata | null')) throw new Error('Project/media metadata contract missing.');
for (const token of ['-loop','1','-c:v','libx264','-t','-pix_fmt','yuv420p','-vf']) if (!builder.includes(`'${token}'`) && !builder.includes(`"${token}"`)) throw new Error(`Image-to-video flag missing: ${token}`);
for (const res of ['1080p','2K','4K']) if (!read('src/main/services/ffmpegEngine/resolutionMap.ts').includes(`'${res}'`)) throw new Error(`Resolution ${res} missing.`);
for (const field of ['durationSeconds','resolution','fps','hasAudioTrack','formatName','sizeBytes']) if (!probe.includes(field)) throw new Error(`Probe field missing: ${field}`);
for (const ext of ['.png','.jpg','.jpeg','.mp4','.mov','.mkv','.webm']) if (!validator.includes(ext)) throw new Error(`Media extension missing: ${ext}`);
for (const channel of ['MEDIA_PROBE','MEDIA_CONVERT_IMAGE','MEDIA_UPDATE_CONTROLS']) if (!ipc.includes(channel)) throw new Error(`IPC channel missing: ${channel}`);
if (!handler.includes('IPC_CHANNELS.MEDIA_PROBE') || !handler.includes('IPC_CHANNELS.MEDIA_CONVERT_IMAGE') || !handler.includes('IPC_CHANNELS.MEDIA_UPDATE_CONTROLS')) throw new Error('Media IPC handlers missing.');
if (!runner.includes("shell: false")) throw new Error('FFmpeg runner must use shell:false.');
if (!service.includes('MediaImporter') || !service.includes('buildImageToVideo')) throw new Error('Media service integration missing.');
if (!prep.includes('buildMainMediaRenderPlan') || !prep.includes('getResolution')) throw new Error('Main media preparation missing.');
const forbidden = /TODO|FIXME|coming soon|implement later|dummy implementation|mock feature/gi;
for (const file of required) if (forbidden.test(read(file))) throw new Error(`Forbidden placeholder text in ${file}`);
console.log(`PHASE 4 STATIC VERIFY: PASSED (${required.length} required files checked).`);
console.log('Media validation, ffprobe metadata extraction, image-to-video command, resolution mapping, main-media controls, typed IPC, and shell:false checks passed.');
