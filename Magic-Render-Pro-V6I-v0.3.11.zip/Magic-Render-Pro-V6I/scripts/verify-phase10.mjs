import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const required = [
  'src/shared/domain/previewTypes.ts',
  'src/main/services/preview/previewFrameService.ts',
  'src/main/ipc/previewHandlers.ts',
  'src/renderer/components/CanvasPreview.tsx',
  'src/renderer/wasmPreview/index.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'src/main/ipc/registerIpc.ts',
  'src/renderer/App.tsx',
];
for (const relative of required) {
  const full = path.join(root, relative);
  if (!fs.existsSync(full)) throw new Error(`Missing ${relative}`);
  const text = fs.readFileSync(full, 'utf8');
  if (/TODO|FIXME|coming soon|implement later|dummy implementation|mock feature/i.test(text)) throw new Error(`Placeholder in ${relative}`);
}
const preview = fs.readFileSync(path.join(root, 'src/renderer/components/CanvasPreview.tsx'), 'utf8');
for (const token of ['aspect-video', 'Play', 'Pause', 'Stop', 'type="range"', 'Volume', 'onPointerDown', 'Resize +', 'Rotate +', 'Opacity', 'extractPreviewFrame']) if (!preview.includes(token)) throw new Error(`Missing preview token ${token}`);
const frame = fs.readFileSync(path.join(root, 'src/main/services/preview/previewFrameService.ts'), 'utf8');
for (const token of ['-frames:v', 'image2pipe', 'pipe:1', 'shell: false']) if (!frame.includes(token)) throw new Error(`Missing frame extraction token ${token}`);
const wasm = fs.readFileSync(path.join(root, 'src/renderer/wasmPreview/index.ts'), 'utf8');
for (const token of ['@ffmpeg/ffmpeg', 'catch']) if (!wasm.includes(token)) throw new Error(`Missing WASM optional fallback token ${token}`);
const ipc = fs.readFileSync(path.join(root, 'src/shared/ipc.ts'), 'utf8');
if (!ipc.includes('PREVIEW_EXTRACT_FRAME')) throw new Error('Preview IPC whitelist missing.');
console.log('PHASE 10 STATIC VERIFY: PASSED (9 core files checked).');
