import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const root = process.cwd();
const required = [
  'src/shared/domain/projectTypes.ts',
  'src/main/domain/project/projectFactory.ts',
  'src/main/repositories/projectRepository.ts',
  'src/main/services/project/projectService.ts',
  'src/main/services/project/projectValidator.ts',
  'src/main/services/project/recentProjectsService.ts',
  'src/main/ipc/projectHandlers.ts',
];
for (const file of required) if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
const source = fs.readFileSync(path.join(root, 'src/main/ipc/projectHandlers.ts'), 'utf8');
for (const ch of ['PROJECT_CREATE','PROJECT_LOAD','PROJECT_SAVE','PROJECT_GET_RECENT','PROJECT_OPEN_FOLDER','PROJECT_IMPORT_MAIN_MEDIA']) if (!source.includes(ch)) throw new Error(`Missing IPC channel ${ch}`);
const ipc = fs.readFileSync(path.join(root, 'src/shared/ipc.ts'), 'utf8');
if (!ipc.includes("project:create") || !ipc.includes("project:save")) throw new Error('Shared IPC contract incomplete.');
const repo = fs.readFileSync(path.join(root, 'src/main/repositories/projectRepository.ts'), 'utf8');
if (!repo.includes('project.json') || !repo.includes('JSON.stringify')) throw new Error('Project serialization not implemented.');
console.log('PHASE 2 STATIC VERIFY: PASSED');
console.log(`Checked ${required.length} Phase 2 core files.`);
