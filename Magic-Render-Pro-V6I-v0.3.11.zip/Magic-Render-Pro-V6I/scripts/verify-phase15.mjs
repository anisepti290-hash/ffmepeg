import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/main/services/ffmpegEngine/errorTranslator.ts',
  'src/main/services/render/renderOrchestrator.ts',
  'src/main/services/ffmpegEngine/commandBuilder.ts',
  'src/renderer/components/ConsoleLogPanel.tsx',
  'src/renderer/App.tsx',
  'src/shared/domain/renderTypes.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'scripts/test-error-translator.cjs',
  'scripts/verify-phase15.mjs',
];
for (const file of required) if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
const translator = fs.readFileSync(path.join(root, 'src/main/services/ffmpegEngine/errorTranslator.ts'), 'utf8');
const orch = fs.readFileSync(path.join(root, 'src/main/services/render/renderOrchestrator.ts'), 'utf8');
const builder = fs.readFileSync(path.join(root, 'src/main/services/ffmpegEngine/commandBuilder.ts'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/renderer/components/ConsoleLogPanel.tsx'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/renderer/App.tsx'), 'utf8');
const checks = [
  ['Moov atom rule', translator.includes('MOOV_ATOM_NOT_FOUND') && translator.includes('moov atom not found')],
  ['extensible rules', translator.includes('RULES') && translator.includes('getErrorRules')],
  ['contextual translation', translator.includes('RenderStage') && translator.includes('stageLabel')],
  ['translated render failure', orch.includes('translateFfmpegError')],
  ['command log emission', orch.includes('FFmpeg command:') && orch.includes('formatSpawnCommand')],
  ['safe command formatter', builder.includes('formatSpawnCommand')],
  ['console collapse/expand', panel.includes('Collapse') && panel.includes('Expand')],
  ['console command/activity/progress/error kinds', ['command','activity','progress','error'].every((x) => panel.includes(`'${x}'`))],
  ['bounded console history', panel.includes('next.length > 400')],
  ['console integrated', app.includes('<ConsoleLogPanel') && app.includes('appendConsoleEntry')],
  ['placeholder-free phase 15', !/TODO|FIXME|coming soon|dummy implementation|mock feature/i.test(translator + panel)],
];
for (const [name, ok] of checks) if (!ok) throw new Error(`FAIL: ${name}`);
console.log(`PHASE 15 STATIC VERIFY: PASSED (${required.length} core files, ${checks.length} checks).`);
