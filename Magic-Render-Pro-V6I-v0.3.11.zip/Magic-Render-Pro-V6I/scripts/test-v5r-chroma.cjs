const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const ts = require('typescript');
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,filename);
const { buildStickerFilterGraph } = require('../src/main/services/ffmpegEngine/stickerFilterBuilder.ts');
const { defaultStickerConfig } = require('../src/shared/domain/stickerTypes.ts');
const temp = fs.mkdtempSync(path.join(os.tmpdir(),'mrp-chroma-parity-'));
const source = path.join(temp,'green-white.png');
try {
  const create=spawnSync('python3',['-c','from PIL import Image,ImageDraw; import sys; im=Image.new("RGBA",(120,60),(0,255,0,255)); d=ImageDraw.Draw(im);d.rectangle((20,10,50,50),fill=(255,0,0,255));d.rectangle((60,10,90,50),fill=(255,255,255,255));im.save(sys.argv[1])',source]);
  assert.equal(create.status,0,create.stderr?.toString());
  const config=defaultStickerConfig();config.position={x:12,y:15};config.backgroundRemoval='chroma';config.chromaKey.enabled=true;config.chromaKey.color='0x00FF00';config.chromaKey.similarity=0.3;config.chromaKey.blend=0.1;
  const graph=buildStickerFilterGraph({id:'chroma',path:source,type:'image',config},'base','sticker',320,180,1);
  assert(graph.filterGraph.indexOf('colorkey=')<graph.filterGraph.indexOf('pad=') && graph.filterGraph.includes('colorkey='));
  const result=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=blue:s=320x180:r=1:d=1','-loop','1','-framerate','1','-i',source,'-filter_complex',`[0:v]null[base];[1:v]null[sticker];${graph.filterGraph}`,'-map',`[${graph.finalLabel}]`,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],{timeout:30000,maxBuffer:320*180*3+1024});
  assert.equal(result.status,0,result.stderr.toString());
  const p=(x,y)=>[...result.stdout.subarray((y*320+x)*3,(y*320+x)*3+3)];
  // At x=13 there is transparent padding. The old filter made it ~77% black.
  assert(p(13,20)[2]>240 && p(13,20)[0]<15,`transparent padding darkened the canvas: ${p(13,20)}`);
  assert(p(75,50)[0]>230 && p(75,50)[2]<25,`red sticker became translucent: ${p(75,50)}`);
  assert(p(145,50).every(v=>v>230),`white lettering became translucent: ${p(145,50)}`);
  // Match the production fast path: key the still once, then composite its PNG.
  const prepared=path.join(temp,'prepared.png');
  const once=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-y','-i',source,'-vf','format=rgba,colorkey=00FF00:0.3:0.1,format=rgba','-frames:v','1','-pix_fmt','rgba',prepared]);
  assert.equal(once.status,0,once.stderr.toString());
  const cached={...config,backgroundRemoval:'none',chromaKey:{...config.chromaKey,enabled:false}};
  const cachedGraph=buildStickerFilterGraph({id:'cached',path:prepared,type:'image',config:cached},'base','sticker',320,180,1);
  const composited=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=blue:s=320x180:r=1:d=1','-loop','1','-framerate','1','-i',prepared,'-filter_complex',`[0:v]null[base];[1:v]null[sticker];${cachedGraph.filterGraph}`,'-map',`[${cachedGraph.finalLabel}]`,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],{timeout:30000,maxBuffer:320*180*3+1024});
  assert.equal(composited.status,0,composited.stderr.toString());
  const q=(x,y)=>[...composited.stdout.subarray((y*320+x)*3,(y*320+x)*3+3)];
  assert(q(13,20)[2]>240 && q(13,20)[0]<15,`cached transparent area darkened: ${q(13,20)}`);
  assert(q(75,50)[0]>230 && q(75,50)[2]<25,`cached red sticker faded: ${q(75,50)}`);
  assert(q(145,50).every(v=>v>230),`cached white lettering faded: ${q(145,50)}`);
  console.log('V5R chroma RGB/key-before-padding: white, red and transparent padding PASSED');
} finally { fs.rmSync(temp,{recursive:true,force:true}); }
