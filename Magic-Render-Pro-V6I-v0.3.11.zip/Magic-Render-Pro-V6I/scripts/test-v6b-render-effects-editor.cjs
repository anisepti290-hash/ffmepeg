const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { particlePosition } = require('../dist/shared/domain/effectPreview.js');
const { particleGlyph } = require('../dist/shared/domain/particleGeometry.js');
const { buildParticleFilters } = require('../dist/main/services/effects/effectFilterBuilder.js');
const { buildVisualizerFilters } = require('../dist/main/services/effects/visualizerBuilder.js');
const ts = require('typescript');
const Module = require('node:module');
const etaFile=path.resolve(__dirname,'../src/renderer/utils/renderEta.ts');
const etaModule=new Module(etaFile,module);
etaModule._compile(ts.transpileModule(fs.readFileSync(etaFile,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,etaFile);
const { countdownEta }=etaModule.exports;

const beat={bpm:120,phaseSec:0,source:'fallback'};
const particle={id:'directions',kind:'diamonds',opacity:1,flipX:false,flipY:false,rotation:0,minCount:1,maxCount:1,minDistance:0,maxDistance:0,motion:'rise',speed:.25,beatSync:false,size:30};
assert.equal(particleGlyph.diamonds,'◆');
assert.ok(particlePosition(particle,0,1,beat).y < particlePosition(particle,0,0,beat).y,'Naik moves upward');
assert.ok(particlePosition({...particle,motion:'fall'},0,1,beat).y > particlePosition({...particle,motion:'fall'},0,0,beat).y,'Jatuh moves downward');
assert.ok(particlePosition({...particle,motion:'drift'},0,1,beat).x > particlePosition({...particle,motion:'drift'},0,0,beat).x,'Berjalan moves right');
assert.ok(Math.abs(particlePosition({...particle,motion:'fall'},0,1,beat).y-particlePosition({...particle,motion:'fall'},0,0,beat).y) < 8,'Quarter speed is at most 6 px/s');
const eta=countdownEta({projectId:'test',status:'compressing_video',percent:95,currentTimeSec:99.9,totalDurationSec:100,speedMultiplier:1,elapsedRenderSec:90},null);
assert.equal(eta.seconds,null,'Finalization never advertises a completed countdown');

const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-v6b-'));
function ffmpeg(args){const result=spawnSync('ffmpeg',['-hide_banner','-loglevel','error',...args],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);}
try{
  for(const motion of ['rise','fall','zigzag','drift','spread','spiral','orbit','bounce','evaporate']){
    const graph=buildParticleFilters([{...particle,motion}],'0:v',320,180,beat,10);
    const file=path.join(dir,'particles.txt');fs.writeFileSync(file,graph.filters.join(';'));
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.4','-filter_complex_script',file,'-map',`[${graph.output}]`,'-frames:v','2','-f','null','-']);
  }
  for(const kind of ['diamonds','hearts','petals','leaves','ice','snow']){
    const graph=buildParticleFilters([{...particle,kind}],'0:v',320,180,beat,10);
    const file=path.join(dir,'glyphs.txt');fs.writeFileSync(file,graph.filters.join(';'));
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.4','-filter_complex_script',file,'-map',`[${graph.output}]`,'-frames:v','2','-f','null','-']);
  }
  const frames={};
  for(const kind of ['bars','solidBars','wavePeak','mirror','spectrumFire']) for(const peakPosition of ['left','center','right']){
    const item={id:'visual',kind,peakPosition,position:{x:0,y:0},size:{width:320,height:180},color:'#fc1313',palette:'custom',opacity:1,sensitivity:2,density:32,glow:0};
    const graph=buildVisualizerFilters([item],'0:v',1,1,10),file=path.join(dir,'visualizer.txt'),output=path.join(dir,`${kind}-${peakPosition}.raw`);
    fs.writeFileSync(file,graph.filters.join(';'));
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.5','-f','lavfi','-i','sine=frequency=440:duration=0.5','-filter_complex_script',file,'-map',`[${graph.output}]`,'-frames:v','3','-pix_fmt','rgb24','-f','rawvideo','-y',output]);
    frames[`${kind}-${peakPosition}`]=fs.readFileSync(output).subarray(2*320*180*3);
  }
  assert.notDeepEqual(frames['bars-left'],frames['solidBars-left'],'Solid columns differ from gapped equalizer bars');
  assert.notDeepEqual(frames['solidBars-left'],frames['solidBars-right'],'Frequency peak placement changes pixels');
  assert.notDeepEqual(frames['solidBars-left'],frames['solidBars-center'],'Center peak placement changes pixels');
  assert.notDeepEqual(frames['wavePeak-left'],frames['mirror-left'],'Peak waves differ from symmetric waves');
  const red=frames['spectrumFire-left'];let redPixels=0;
  for(let i=0;i<red.length;i+=3)if(red[i]>red[i+1]*1.5 && red[i]>red[i+2]*1.5)redPixels++;
  assert.ok(redPixels>50,'Custom red color also applies to the spectrum style');
  const coverage=(spacing)=>{
    const item={id:'sparse',kind:'bars',peakPosition:'left',position:{x:0,y:0},size:{width:320,height:180},color:'#fc1313',opacity:1,sensitivity:.2,smoothing:.7,density:16,bandSpacing:spacing,roundedTop:true,cornerRadius:8,glow:0};
    const graph=buildVisualizerFilters([item],'0:v',1,1,10),script=path.join(dir,'sparse.txt'),output=path.join(dir,`sparse-${spacing}.raw`);
    fs.writeFileSync(script,graph.filters.join(';'));
    assert.match(graph.filters.join(';'),/tmix=frames=5/,'Low sensitivity filters temporal response');
    assert.match(graph.filters.join(';'),/gblur=sigma=.*:planes=8/,'Top corners use alpha rounding');
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.6','-f','lavfi','-i','sine=frequency=440:duration=0.6','-filter_complex_script',script,'-map',`[${graph.output}]`,'-frames:v','3','-pix_fmt','rgb24','-f','rawvideo','-y',output]);
    const pixels=fs.readFileSync(output).subarray(2*320*180*3);let occupied=0;for(let i=0;i<pixels.length;i+=3)if(pixels[i]>90)occupied++;return occupied;
  };
  assert.ok(coverage(.65)<coverage(0)*.6,'Spacing visibly separates rounded frequency columns');
  console.log('V6B: particle directions/speed/glyphs, ETA finalization, FFmpeg peak placement/styles/custom color: PASSED');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
