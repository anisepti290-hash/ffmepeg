import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/shared/domain/playlistTypes.ts',
  'src/shared/domain/projectTypes.ts',
  'src/main/services/audio/audioProbe.ts',
  'src/main/services/audio/playlistAlgorithms.ts',
  'src/main/services/audio/playlistValidator.ts',
  'src/main/services/audio/playlistService.ts',
  'src/main/services/audio/audioConcatBuilder.ts',
  'src/main/ipc/playlistHandlers.ts',
  'src/preload/index.ts',
  'src/main/ipc/registerIpc.ts',
  'src/renderer/components/PlaylistPanel.tsx',
  'src/renderer/App.tsx',
];
for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing Phase 8 file: ${file}`);
}
const sourceFiles = required.filter((file) => /\.(ts|tsx)$/.test(file)).map((file) => fs.readFileSync(path.join(root, file), 'utf8'));
const source = sourceFiles.join('\n');
for (const marker of ['TODO', 'FIXME', 'coming soon', 'implement later', 'dummy implementation', 'mock feature']) {
  if (source.toLowerCase().includes(marker.toLowerCase())) throw new Error(`Forbidden placeholder marker found: ${marker}`);
}
if (!source.includes("'.mp3'") && !source.includes("'.MP3'")) throw new Error('MP3 validation support missing.');
for (const symbol of ['buildExactDurationComposition', 'buildAudioConcatCommand', 'probeAudioFile', 'PLAYLIST_IMPORT', 'PLAYLIST_REORDER', 'PLAYLIST_REMOVE', 'PLAYLIST_SHUFFLE', 'PLAYLIST_SUMMARY', 'PLAYLIST_BUILD_AUDIO']) {
  if (!source.includes(symbol)) throw new Error(`Phase 8 symbol missing: ${symbol}`);
}
if (!source.includes("shell: false")) throw new Error('Audio probing/build execution must use shell:false.');
if (!source.includes("-filter_complex")) throw new Error('Audio concat filtergraph missing.');
if (!source.includes("'-b:a', '320k'")) throw new Error('AAC 320kbps output requirement missing.');
if (!source.includes('playbackOrder')) throw new Error('Actual playback order persistence missing.');
console.log(`PHASE 8 STATIC VERIFY: PASSED (${required.length} files checked).`);
