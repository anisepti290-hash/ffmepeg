const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const Module = require('node:module');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
process.resourcesPath = path.join(root, 'resources');
function assert(c, m) { if (!c) throw new Error(m); }
const originalLoad = Module._load;
const previousTs = Module._extensions['.ts'];
Module._extensions['.ts'] = function(mod, filename) {
  const source = fs.readFileSync(filename, 'utf8');
  const out = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true },
    fileName: filename,
  }).outputText;
  mod._compile(out, filename);
};
Module._load = function(request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => os.tmpdir() } };
  if (request === 'dotenv') return { config: () => undefined };
  return originalLoad.apply(this, arguments);
};
(async () => {
  try {
    const { CacheManager } = require(path.join(root, 'src/main/services/cache/cacheManager.ts'));
    const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'mrp-checkpoint-'));
    try {
      const cm = new CacheManager(temp);
      const job = await cm.createRenderJob('resume-me');
      await cm.prepareArtifactDirectory(job, 'render');
      const cp = path.join(job, 'render', 'checkpoint.json');
      fs.writeFileSync(cp, JSON.stringify({ projectId: 'resume-me', completedStage: 'visual-layer-composition', nextStage: 'content-flow', jobDir: job, outputPath: path.join(temp, 'out.mp4'), createdAt: new Date().toISOString() }));
      const found = await cm.findLatestCheckpoint('resume-me');
      assert(found && found.data.nextStage === 'content-flow', '#6 checkpoint not recoverable');
    } finally { fs.rmSync(temp, { recursive: true, force: true }); }
    const { FfmpegProcess } = require(path.join(root, 'src/main/services/ffmpegEngine/ffmpegRunner.ts'));
    const proc = new FfmpegProcess(null);
    const done = proc.run({ executable: 'ffmpeg', args: ['-re', '-f', 'lavfi', '-i', 'testsrc=size=32x32:rate=10', '-t', '5', '-f', 'null', '-'] });
    await new Promise((r) => setTimeout(r, 250));
    assert(proc.isRunning(), '#7 FFmpeg test did not start');
    proc.gracefulStop(2000);
    const result = await done;
    assert(result.exitCode === 0 && !result.cancelled, '#7 graceful stop did not exit cleanly');
    process.env.MAGIC_RENDER_ENV = 'development';
    delete process.env.MAGIC_RENDER_FFMPEG_PATH;
    const cfg = require(path.join(root, 'src/main/config/environment.ts')).createRuntimeConfig();
    assert(cfg.ffmpegPath.replaceAll('\\', '/').endsWith('/resources/ffmpeg/ffmpeg.exe'), '#15 dev FFmpeg path incorrect');
    console.log('REMAINING FIXES #6 #7 #15 RUNTIME VERIFY: TEST PASSED');
  } finally {
    Module._load = originalLoad;
    if (previousTs) Module._extensions['.ts'] = previousTs;
    else delete Module._extensions['.ts'];
  }
})().catch((error) => { console.error(error); process.exitCode = 1; });
