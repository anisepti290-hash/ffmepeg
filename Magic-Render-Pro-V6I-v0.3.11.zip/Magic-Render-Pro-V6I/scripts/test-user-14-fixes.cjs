const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const app = read('src/renderer/App.tsx');
const header = read('src/renderer/components/WindowChrome.tsx');
const nav = read('src/renderer/components/MainNav.tsx');
const css = read('src/renderer/styles/index.css');
const canvas = read('src/renderer/components/CanvasPreview.tsx');
const overlay = app;
const sticker = read('src/renderer/components/StickerPanel.tsx');
const intro = read('src/renderer/components/IntroPanel.tsx');
const seo = read('src/renderer/components/YoutubeSeoPanel.tsx');
const settings = read('src/renderer/components/SettingsPanel.tsx');
const playlist = read('src/renderer/components/PlaylistPanel.tsx');
const validation = read('src/main/ipc/validation.ts');
const introHandlers = read('src/main/ipc/introHandlers.ts');
const filter = read('src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts');
const stickerFilter = read('src/main/services/ffmpegEngine/stickerFilterBuilder.ts');
const renderCommand = read('src/main/services/render/renderCommandBuilder.ts');
const projectTypes = read('src/shared/domain/projectTypes.ts');
const ipc = read('src/shared/ipc.ts');
const preload = read('src/preload/index.ts');
const logger = read('src/main/ipc/loggedHandler.ts');

const checks = [
  ['1 custom chrome + home actions', header.includes('APP_NAME') && header.includes('minimizeWindow') && app.includes('Start New Project') && app.includes('Video Rendering')],
  ['2 CPU control only Settings', !app.includes('<CpuLoadControlPanel') && settings.includes('CPU Load Control')],
  ['3 IPC + renderer error logging + top-right toast', logger.includes('ipcMain.handle(channel, listener)') && app.includes('unhandledrejection') && css.includes('.mrp-toast { position: fixed; top: 18px; right: 18px')],
  ['4 New/Open/Save only Media', app.includes("renderTab === 'Media'") && app.includes('>New</button>') && app.includes('>Open</button>') && app.includes('>Save</button>')],
  ['5 form contrast', css.includes('background:#111627') && css.includes('color:#f7f9ff')],
  ['6 media image/video preview + working play + no technical fallback text', canvas.includes('<video') && canvas.includes('<img') && canvas.includes('togglePlay') && !canvas.includes('css+pipe:1 fallback')],
  ['7 overlay/sticker Apply', overlay.includes('Terapkan') && sticker.includes('Terapkan')],
  ['8 shuffle is button', playlist.includes('>Shuffle</button>') && !playlist.includes('Shuffle playback order</label>')],
  ['9 SEO only main keyword, AI settings separate', seo.includes('Main Keyword') && !seo.includes('API Key') && !seo.includes('AI Provider<select') && settings.includes('AI Provider')],
  ['10 Lanczos scaling', renderCommand.includes('flags=lanczos') && stickerFilter.includes('flags=lanczos')],
  ['11 multi sticker controls', projectTypes.includes('stickerSubscribes?:') && sticker.includes('Sticker Subscribe') && sticker.includes('durationSec') && sticker.includes('blendMode') && sticker.includes('backgroundRemoval')],
  ['12 flat fade validation', validation.includes('controls.fadeInSec') && validation.includes('controls.fadeOutSec') && !validation.includes('const fade = controls.fade')],
  ['13 intro upload + safe enable', intro.includes('importIntro') && intro.includes('disabled={!project.intro.path}') && introHandlers.includes('INTRO_IMPORT')],
  ['14 modular graph has no null filter and uses valid composition', !filter.includes('null[') && !renderCommand.includes('[0:v]null') && stickerFilter.includes('overlay=x=')],
  ['typed IPC additions', ipc.includes('APP_LOG') && ipc.includes('INTRO_IMPORT') && preload.includes('importIntro') && preload.includes('logActivity')],
  ['custom local media protocol', read('src/main/index.ts').includes("protocol.handle('mrp-media'") && canvas.includes('mrp-media://local')],
  ['realtime application log buffer', read('src/main/utils/logger.ts').includes('recentEntries') && read('src/main/utils/logger.ts').includes('getRecentLogEntries')],
];
for (const [name, passed] of checks) console.log(`${passed ? 'PASS' : 'FAIL'}: ${name}`);
assert(checks.every(([, passed]) => passed), 'One or more user-14 static checks failed.');

// Actual FFmpeg filter smoke using the same post-fix filter shape: two sticker windows + one blend layer.
const temp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'mrp-user14-'));
try {
  const main = path.join(temp, 'main.mp4');
  const stickerA = path.join(temp, 'sticker-a.mp4');
  const stickerB = path.join(temp, 'sticker-b.mp4');
  const out = path.join(temp, 'out.mp4');
  const lavfi = (source, output) => execFileSync('ffmpeg', ['-hide_banner','-loglevel','error','-y','-f','lavfi','-i',source,output], { stdio:'pipe' });
  lavfi('color=c=blue:s=320x180:d=2', main);
  lavfi('color=c=yellow:s=60x30:d=1', stickerA);
  lavfi('color=c=red:s=40x20:d=1', stickerB);
  const graph = '[1:v]setpts=PTS-STARTPTS,format=rgba,fade=t=in:st=0.4:d=0.1:alpha=1,fade=t=out:st=0.9:d=0.1:alpha=1[a];[0:v][a]overlay=x=10:y=10:eof_action=repeat[c1];[2:v]setpts=PTS-STARTPTS,format=rgba,fade=t=in:st=0:d=0.1:alpha=1,fade=t=out:st=1.9:d=0.1:alpha=1[b];[b]pad=320:180:100:80:color=black@0[bc];[c1][bc]blend=all_mode=screen:all_opacity=1[out]';
  execFileSync('ffmpeg', ['-hide_banner','-loglevel','error','-y','-i',main,'-stream_loop','-1','-i',stickerA,'-stream_loop','-1','-i',stickerB,'-filter_complex',graph,'-map','[out]','-t','2','-c:v','libx264','-preset','veryfast','-pix_fmt','yuv420p',out], { stdio:'pipe' });
  const probe = execFileSync('ffprobe', ['-v','error','-select_streams','v:0','-show_entries','stream=width,height,duration','-of','csv=p=0',out], { encoding:'utf8' }).trim();
  assert(/^320,180,2\.0+\s*$/.test(probe), `Unexpected FFmpeg smoke output: ${probe}`);
  console.log('PASS: FFmpeg multi-sticker/filtergraph smoke');
} finally {
  fs.rmSync(temp, { recursive:true, force:true });
}
console.log('USER 14-FIX VALIDATION: PASSED');
