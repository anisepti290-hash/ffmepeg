const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const os=require('node:os');const cp=require('node:child_process');const Module=require('node:module');const ts=require('typescript');
Module._extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,f);
const {buildComposedOutputCommand}=require('../src/main/services/render/renderCommandBuilder.ts');
const {defaultOverlayConfig}=require('../src/main/services/overlay/overlayService.ts');
const {defaultStickerConfig}=require('../src/main/services/stickerService.ts');
const {TextOverlayBuilder}=require('../src/main/services/ffmpegEngine/textOverlayBuilder.ts');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-720-layer-'));
function exec(executable,args){const p=cp.spawnSync(executable,args,{encoding:'utf8',maxBuffer:3e6});assert.equal(p.status,0,p.stderr);return p.stdout;}
try {
 function image(color,name,w,h){const file=path.join(temp,name);exec('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','lavfi','-i',`color=c=${color}:s=${w}x${h}`,'-frames:v','1',file]);return file;}
 const main=image('blue','main.png',320,180),red=image('red','overlay.png',100,50),green=image('green','sticker.png',100,50),out=path.join(temp,'output.mp4');
 const overlayConfig=defaultOverlayConfig();overlayConfig.position={x:1600,y:50};overlayConfig.resize=null;
 const stickerConfig=defaultStickerConfig();stickerConfig.position={x:1600,y:900};stickerConfig.fade={fadeInSec:0,fadeOutSec:0};stickerConfig.schedule={mode:'full-duration',iterativeCount:null,timestamps:[]};stickerConfig.durationSec=1;
 const textConfig={text:'TEST',fontFamily:'Arial',fontStyle:'normal',fontColor:'#ffffff',fontSize:72,bold:false,italic:false,underline:false,strokeColor:'#000000',strokeWidth:3,opacity:1,neonGlow:false,glowColor:'#ffffff',glowBlur:0,effect:'none',animation:'none',position:{x:1600,y:900},scale:1,rotation:0,speed:1};
 const textGraph=new TextOverlayBuilder().build({id:'text',config:textConfig},'main','textOut',1,2/3);assert.match(textGraph,/fontsize=48:x=1067:y=600/);
 const project={mainMedia:{path:main,type:'image',autoMute:true,fade:{fadeInSec:0,fadeOutSec:0},resize:{width:1920,height:1080},position:{x:0,y:0},rotation:0},overlays:[{id:'red',path:red,type:'image',config:overlayConfig}],textOverlays:[],stickerSubscribe:{id:'green',path:green,type:'image',config:stickerConfig},stickerSubscribes:[],intro:{enabled:false,path:null},settings:{resolution:'720p',fps:24,renderPreset:'fast',bitrateKbps:2400}};
 const command=buildComposedOutputCommand('ffmpeg',project,out,1,0,null,false);
 assert.match(command.args.join(' '),/overlay=x=1067:y=33/);
 assert.match(command.args.join(' '),/overlay=x=1066\.666667:y=600/);
 exec(command.executable,['-hide_banner','-loglevel','error',...command.args]);
 assert.equal(exec('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=width,height','-of','csv=p=0',out]).trim(),'1280,720');
 function pixel(x,y){const p=cp.spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-ss','0.5','-i',out,'-vf',`crop=1:1:${x}:${y},format=rgb24`,'-frames:v','1','-f','rawvideo','pipe:1'],{maxBuffer:1024});assert.equal(p.status,0,p.stderr.toString());return [...p.stdout];}
 const a=pixel(1100,42),b=pixel(1100,620);assert(a[0]>a[1]*2&&a[0]>a[2]*2,`Overlay missing at 720p: ${a}`);assert(b[1]>b[0]*2&&b[1]>b[2]*2,`Sticker missing at 720p: ${b}`);
 const scheduled={...project,intro:{enabled:true,path:main},stickerSubscribe:{...project.stickerSubscribe,config:{...stickerConfig,schedule:{mode:'timestamp',iterativeCount:null,timestamps:['1.2']},durationSec:.4}}};
 const scheduledOut=path.join(temp,'scheduled.mp4');const scheduledCommand=buildComposedOutputCommand('ffmpeg',scheduled,scheduledOut,1,.5,null,false);
 exec(scheduledCommand.executable,['-hide_banner','-loglevel','error',...scheduledCommand.args]);
 function scheduledPixel(time){const p=cp.spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-ss',String(time),'-i',scheduledOut,'-vf','crop=1:1:1100:620,format=rgb24','-frames:v','1','-f','rawvideo','pipe:1'],{maxBuffer:1024});assert.equal(p.status,0,p.stderr.toString());return [...p.stdout];}
 const before=scheduledPixel(.8),during=scheduledPixel(1.3);assert(before[2]>before[1]*1.5,`Sticker appeared early with intro: ${before}`);assert(during[1]>during[2]*1.5,`Sticker missing at final video timestamp 1.3: ${during}`);
 console.log('V5H 720p MAIN + OVERLAY + STICKER PIXEL INTEGRATION: PASSED');
}finally{fs.rmSync(temp,{recursive:true,force:true});}
