const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const cp=require('node:child_process');const Module=require('node:module');const ts=require('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,f);
const original=Module._load;Module._load=function(req,parent,main){if(req==='electron')return {app:{getPath:()=>os.tmpdir()}};return original.call(this,req,parent,main)};
const {createDefaultProject}=require('../src/main/domain/project/projectFactory.ts');const {defaultStickerConfig}=require('../src/shared/domain/stickerTypes.ts');const {RenderOrchestrator}=require('../src/main/services/render/renderOrchestrator.ts');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-v5r-render-'));const exec=(args,buffer=1e6)=>{const r=cp.spawnSync('ffmpeg',['-hide_banner','-loglevel','error',...args],{timeout:120000,maxBuffer:buffer});assert.equal(r.status,0,String(r.stderr));return r.stdout};
(async()=>{try{
 const image=path.join(dir,'base.png'),sticker=path.join(dir,'sticker.png');exec(['-f','lavfi','-i','color=c=blue:s=320x180','-frames:v','1',image]);
 const py=cp.spawnSync('python3',['-c','from PIL import Image,ImageDraw; import sys; a=Image.new("RGB",(120,60),(0,255,0));d=ImageDraw.Draw(a);d.rectangle((20,10,50,50),fill=(255,0,0));d.rectangle((60,10,90,50),fill=(255,255,255));a.save(sys.argv[1])',sticker]);assert.equal(py.status,0,String(py.stderr));
 const p=createDefaultProject('chroma',dir,{outputDir:dir,resolution:'720p',fps:24,bitrateKbps:1600,cpuLoadPercent:75});p.mainMedia={type:'image',path:image,metadata:null,durationSeconds:0.5,resize:null,position:{x:0,y:0},rotation:0,fade:{fadeInSec:0,fadeOutSec:0},autoMute:true};p.intro.fallbackFadeInSec=0;
 const c=defaultStickerConfig();c.position={x:0,y:0};c.backgroundRemoval='chroma';c.chromaKey.enabled=true;c.chromaKey.similarity=0.3;c.chromaKey.blend=0.1;
 p.stickerSubscribe={id:'s',path:sticker,type:'image',config:c};p.stickerSubscribes=[p.stickerSubscribe];
 const r=await new RenderOrchestrator('ffmpeg','ffprobe',path.join(dir,'jobs')).start(p,()=>{});assert.equal(r.status,'done');
 const frame=exec(['-ss','0.25','-i',r.outputPath,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],1280*720*3+1000);
 const color=(x,y)=>[...frame.subarray((y*1280+x)*3,(y*1280+x)*3+3)];
 assert(color(5,25)[2]>140 && color(5,25)[0]<65,`green or black background leaked: ${color(5,25)}`);
 assert(color(30,40)[0]>150 && color(30,40)[2]<90,`red sticker faded: ${color(30,40)}`);
 assert(color(75,40).every(v=>v>160),`white lettering faded: ${color(75,40)}`);
 console.log('V5R actual orchestrator cached chroma export pixels PASSED');
}finally{fs.rmSync(dir,{recursive:true,force:true})}})().catch(e=>{console.error(e);process.exitCode=1});
