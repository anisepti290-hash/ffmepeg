const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'main', 'services', 'cpuController.ts'), 'utf8');
if (!src.includes('os.availableParallelism') || !src.includes('calculateSafeFfmpegThreads') || !src.includes("'-threads'")) process.exit(1);
console.log('CPU CONTROLLER STATIC UNIT: PASSED');
