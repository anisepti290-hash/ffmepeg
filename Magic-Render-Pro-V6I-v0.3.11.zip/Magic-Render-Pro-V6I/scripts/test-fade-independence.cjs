const assert = require('node:assert/strict');
const { effectiveMainFadeIn } = require('../dist/shared/domain/introTypes.js');
const { buildSinglePassCommand } = require('../dist/main/services/render/renderCommandBuilder.js');
const base = { mainMedia: { path:'/tmp/main.mp4', autoMute:true, resize:{width:1920,height:1080}, position:{x:0,y:0}, rotation:0, fade:{fadeInSec:1.5,fadeOutSec:0} }, intro:{enabled:true,path:'/tmp/intro.mp4',fallbackFadeInSec:3}, settings:{resolution:'1080p',renderPreset:'fast',bitrateKbps:1200} };
assert.equal(effectiveMainFadeIn(base),1.5);
assert.equal(effectiveMainFadeIn({...base,mainMedia:{...base.mainMedia,fade:{...base.mainMedia.fade,fadeInSec:0}}}),0);
assert.equal(effectiveMainFadeIn({...base,intro:{...base.intro,enabled:false},mainMedia:{...base.mainMedia,fade:{...base.mainMedia.fade,fadeInSec:0}}}),3);
assert.ok(buildSinglePassCommand('ffmpeg',base,'/tmp/output.mp4',10).args.join(' ').includes('fade=t=in:st=0:d=1.5'));
console.log('FADE INDEPENDENCE: PASSED (main media controls work with intro enabled; fallback only when needed).');
