import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root,p),'utf8');
const checks = [
  ['encodingBuilder exists', fs.existsSync(path.join(root,'src/main/services/render/encodingBuilder.ts'))],
  ['outputService exists', fs.existsSync(path.join(root,'src/main/services/render/outputService.ts'))],
  ['output IPC exists', fs.existsSync(path.join(root,'src/main/ipc/outputHandlers.ts'))],
  ['output IPC channels wired', /OUTPUT_CHOOSE_DIRECTORY/.test(read('src/shared/ipc.ts')) && /OUTPUT_UPDATE_SETTINGS/.test(read('src/preload/index.ts'))],
  ['output handlers registered', /registerOutputIpcHandlers/.test(read('src/main/ipc/registerIpc.ts'))],
  ['H.264 encoding', /libx264/.test(read('src/main/services/render/encodingBuilder.ts'))],
  ['AAC encoding', /\baac\b/.test(read('src/main/services/render/encodingBuilder.ts'))],
  ['AAC 320', /320/.test(read('src/main/services/render/encodingBuilder.ts'))],
  ['veryfast', /veryfast/.test(read('src/main/services/render/encodingBuilder.ts'))],
  ['CBR approximation flags', /-b:v/.test(read('src/main/services/render/encodingBuilder.ts')) && /-minrate/.test(read('src/main/services/render/encodingBuilder.ts')) && /-maxrate/.test(read('src/main/services/render/encodingBuilder.ts')) && /-bufsize/.test(read('src/main/services/render/encodingBuilder.ts'))],
  ['CRF with bitrate cap in final builder', /-crf/.test(read('src/main/services/render/renderCommandBuilder.ts')) && /-maxrate/.test(read('src/main/services/render/renderCommandBuilder.ts'))],
  ['MP4 output validation', /OUTPUT_EXTENSION = '.mp4'/.test(read('src/main/services/render/outputService.ts'))],
  ['write permission validation', /fs\.constants\.W_OK/.test(read('src/main/services/render/outputService.ts'))],
  ['storage validation', /statfs/.test(read('src/main/services/render/outputService.ts'))],
  ['collision-safe overwrite handling', /prepareOutputPath/.test(read('src/main/services/render/outputService.ts')) && /-\$\{index\}/.test(read('src/main/services/render/outputService.ts'))],
  ['settings UI', /OutputSettingsPanel/.test(read('src/renderer/App.tsx'))],
  ['resolution selectors', /1080p/.test(read('src/renderer/App.tsx')) && /2K/.test(read('src/renderer/App.tsx')) && /4K/.test(read('src/renderer/App.tsx'))],
  ['save output through IPC', /updateOutputSettings/.test(read('src/renderer/App.tsx'))],
];
const failed = checks.filter(([,ok])=>!ok);
console.log(`PHASE 20 STATIC VERIFY: ${failed.length ? 'FAILED' : 'PASSED'} (${checks.length - failed.length}/${checks.length} checks)`);
if (failed.length) { for (const [name] of failed) console.error(`FAIL: ${name}`); process.exit(1); }
