import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const checks=[
['Main media default 1920x1080', read('src/main/services/media/mainMediaControls.ts').includes('width: 1920') && read('src/main/services/project/projectService.ts').includes('resize: { width: 1920, height: 1080 }')],
['Sticker default timestamp 30s', read('src/main/services/stickerService.ts').includes("timestamps: ['00:30']")],
['Sticker numeric timestamp support', read('src/main/services/stickerScheduler.ts').includes('^\\d+'),],
['Canvas local draft gesture state', read('src/renderer/components/CanvasPreview.tsx').includes('dragProjectRef') && read('src/renderer/components/CanvasPreview.tsx').includes('setDraftProject')],
['Render target driven by playlist', read('src/main/services/render/renderOrchestrator.ts').includes('playlistDuration') && read('src/main/services/render/renderOrchestrator.ts').includes('targetDuration')],
['Progress monitor labels', read('src/renderer/App.tsx').includes('Total Durasi') && read('src/renderer/App.tsx').includes('Waktu Render')],
];
for(const [name,ok] of checks){ console.log(`${ok?'PASS':'FAIL'}: ${name}`); if(!ok) process.exitCode=1; }
if(!process.exitCode) console.log('PHASE 30 VERIFY: PASSED');
