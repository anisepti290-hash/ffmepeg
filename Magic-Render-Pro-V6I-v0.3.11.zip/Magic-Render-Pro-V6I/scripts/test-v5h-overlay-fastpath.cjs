const assert=require('node:assert/strict');const cp=require('node:child_process');const fs=require('node:fs');const Module=require('node:module');const ts=require('typescript');
Module._extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,f);
const {FilterGraphBuilder}=require('../src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts');
const overlay={id:'layer',path:'unused',type:'image',config:{opacity:1,position:{x:12,y:8},resize:{width:64,height:36},rotation:0,speed:1,blendMode:'normal',chromaKey:{enabled:false,color:'0x00FF00',similarity:.3,blend:.1},colorKey:{enabled:false,color:'0x000000',similarity:.3,blend:.1}}};
const graph=new FilterGraphBuilder().build('0:v',[{sourceIndex:1,sourceLabel:'1:v',overlay}],320,180);
assert(!graph.filterGraph.includes('positioned_bg'),'Normal overlay should not allocate a full-frame transparent canvas');
assert.match(graph.filterGraph,/overlay=x=12:y=8/);
const old='[1:v]scale=64:36:flags=lanczos[prepared];color=c=black@0:s=320x180:r=24,format=rgba[bg];[bg][prepared]overlay=x=12:y=8:eof_action=repeat:format=auto[positioned];[0:v][positioned]overlay=x=0:y=0:eof_action=repeat[out]';
function frame(filter){const r=cp.spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=blue:s=320x180:r=24','-f','lavfi','-i','color=c=red@0.5:s=64x36:r=24','-filter_complex',filter,'-map',filter===old?'[out]':'[composite_0]','-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],{maxBuffer:1024*1024});assert.equal(r.status,0,r.stderr.toString());return r.stdout;}
const a=frame(graph.filterGraph),b=frame(old);
assert.equal(a.length,320*180*3);assert.equal(b.length,a.length);
const at=(bytes,x,y)=>[...bytes.subarray((y*320+x)*3,(y*320+x)*3+3)];
for (const [x,y] of [[0,0],[24,20]]) { const lhs=at(a,x,y),rhs=at(b,x,y); assert(lhs.every((channel,i)=>Math.abs(channel-rhs[i])<=3),`Composited pixel differs at ${x},${y}: ${lhs} vs ${rhs}`); }
console.log('V5H NORMAL OVERLAY FAST PATH: frame pixels and single composition PASSED');
