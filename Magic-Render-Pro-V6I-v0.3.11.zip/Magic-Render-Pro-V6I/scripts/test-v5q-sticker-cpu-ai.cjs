const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const ts = require('typescript');
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText, filename);
const { buildStickerFilterGraph } = require('../src/main/services/ffmpegEngine/stickerFilterBuilder.ts');
const { defaultStickerConfig } = require('../src/shared/domain/stickerTypes.ts');
const { renderEncodingProfile } = require('../src/main/services/render/encodingBuilder.ts');
const { SettingsService } = require('../src/main/services/settingsService.ts');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'mrp-v5q-'));
const png = path.join(temp, 'sticker.png');
const python = spawnSync('python3', ['-c', 'from PIL import Image; import sys; Image.new("RGBA", (100,60), (255,0,0,255)).save(sys.argv[1])', png]);
assert.equal(python.status,0,python.stderr?.toString());
function frame(position, width, height, canvasScale) {
  const sticker = { id:'fixture', type:'image', path:png, config:{ ...defaultStickerConfig(), scale:0.5, position } };
  const graph = buildStickerFilterGraph(sticker, 'base', 'sticker', width, height, 1, 1, canvasScale);
  assert.match(graph.filterGraph, /alpha=straight/);
  assert.doesNotMatch(graph.filterGraph, /format=rgba/,'opaque fast path should not convert every sticker frame to RGBA');
  const run = spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i',`color=c=blue:s=${width}x${height}:r=1:d=1`,'-loop','1','-framerate','1','-i',png,'-filter_complex',`[0:v]null[base];[1:v]null[sticker];${graph.filterGraph}`,'-map',`[${graph.finalLabel}]`,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'],{timeout:30000,maxBuffer:width*height*3+1024});
  assert.equal(run.status,0,run.stderr.toString());
  return (x,y) => [...run.stdout.subarray((y*width+x)*3,(y*width+x)*3+3)];
}
(async () => { try {
  const negative=frame({x:-20,y:30},320,180,1);
  assert(negative(5,60)[0]>240 && negative(5,60)[2]<15,`opaque sticker became screen/low opacity: ${negative(5,60)}`);
  assert(negative(100,60)[0]<10,`negative position was clamped to canvas edge: ${negative(100,60)}`);
  const scaled=frame({x:1600,y:900},1280,720,2/3);
  assert(scaled(1100,620)[0]>240 && scaled(1100,620)[2]<15,`720p position/opacity mismatch: ${scaled(1100,620)}`);
  assert(scaled(1000,620)[0]<10,`sticker leaked left of preview location: ${scaled(1000,620)}`);
  assert.deepEqual(renderEncodingProfile('standard'),{preset:'veryfast',crf:'20'});
  const service = Object.create(SettingsService.prototype);
  service.credentials = { get: () => null };
  assert.deepEqual(await service.listAiModels('openai'),[],'empty key must not throw from IPC handler');
  console.log('V5Q sticker position/alpha at 720p, direct CPU path and missing AI key: PASSED');
} finally { fs.rmSync(temp,{recursive:true,force:true}); } })().catch((error)=>{ console.error(error); process.exitCode=1; });
