import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const rtmPath = path.join(root, 'RTM.md');
const pkgPath = path.join(root, 'package.json');
if (!fs.existsSync(rtmPath)) throw new Error('Missing RTM.md');
if (!fs.existsSync(pkgPath)) throw new Error('Missing package.json');
const rtm = fs.readFileSync(rtmPath, 'utf8');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
const statuses = ['Verified', 'Partially Verified', 'Failed', 'Not Implemented', 'Explicitly Excluded (documented)'];
const auditStart = rtm.indexOf('## PHASE 23 FINAL AUDIT');
if (auditStart < 0) throw new Error('Missing Phase 23 final audit section');
const audit = rtm.slice(auditStart);
const ids = [...audit.matchAll(/^\| (R-\d{3}) \| (Verified|Partially Verified|Failed|Not Implemented|Explicitly Excluded \(documented\)) \|/gm)].map((m) => m[1]);
const unique = new Set(ids);
if (ids.length !== 221 || unique.size !== 221 || ids[0] !== 'R-001' || ids.at(-1) !== 'R-221') {
  throw new Error(`Final audit must contain exactly R-001..R-221 once; got ${ids.length} rows`);
}
for (const status of statuses) if (status !== 'Explicitly Excluded (documented)' && !audit.includes(status)) throw new Error(`Missing final status category: ${status}`);
if (audit.includes('Forgotten') || audit.includes('Silently Removed')) throw new Error('Audit contains omission markers');
if (!audit.includes('R-221 | Not Implemented |')) throw new Error('R-221 must remain explicitly Not Implemented');
if (!audit.includes('R-218 | Partially Verified |')) throw new Error('R-218 must remain partially verified until ffmpeg.exe is present');
if (pkg.scripts?.['verify:phase22'] !== 'node scripts/verify-phase22.mjs') throw new Error('verify:phase22 script is not registered');
if (pkg.scripts?.['verify:phase23'] !== 'node scripts/verify-phase23.mjs') throw new Error('verify:phase23 script is not registered');
if (!fs.existsSync(path.join(root, 'docs/FINAL_REQUIREMENT_AUDIT_PHASE23.md'))) throw new Error('Missing final audit report');
console.log('PHASE 23 FINAL AUDIT VERIFY: PASSED (221 requirements audited; final verdict remains NOT FINAL-COMPLETE due explicit R-221 gap).');
