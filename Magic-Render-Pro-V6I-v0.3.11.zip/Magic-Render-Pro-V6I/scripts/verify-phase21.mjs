import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const checks = [
  ['global settings type', read('src/shared/domain/settingsTypes.ts').includes('GlobalSettings')],
  ['persistent settings store', read('src/main/services/settingsService.ts').includes("magic-render-pro-settings")],
  ['output default', read('src/main/services/settingsService.ts').includes("app.getPath('videos')")],
  ['resolution persistence', read('src/main/services/settingsService.ts').includes("resolution: ProjectResolution")],
  ['bitrate persistence', read('src/main/services/settingsService.ts').includes('bitrateKbps')],
  ['cpu persistence', read('src/main/services/settingsService.ts').includes('cpuLoadPercent')],
  ['AI provider/model persistence', read('src/main/services/settingsService.ts').includes('aiProvider') && read('src/main/services/settingsService.ts').includes('aiModel')],
  ['settings IPC', read('src/main/ipc/settingsHandlers.ts').includes("IPC_CHANNELS.SETTINGS_GET") && read('src/main/ipc/settingsHandlers.ts').includes("IPC_CHANNELS.SETTINGS_UPDATE")],
  ['typed preload boundary', read('src/preload/index.ts').includes('SETTINGS_CONFIGURE_AI') && read('src/preload/index.ts').includes('SETTINGS_AI_STATUS')],
  ['API key not exposed by settings get', !read('src/shared/domain/settingsTypes.ts').includes('apiKey') && !read('src/main/ipc/settingsHandlers.ts').includes('return settingsService.get().apiKey')],
  ['secure OS API storage', read('src/main/services/aiService/aiCredentialStore.ts').includes('safeStorage.encryptString')],
  ['secure status no plaintext', read('src/shared/domain/aiTypes.ts').includes('configured: boolean') && !/return\s+\{[^}]*apiKey\s*:/.test(read('src/main/ipc/settingsHandlers.ts'))],
  ['new project consumes persisted defaults', read('src/main/services/project/projectService.ts').includes('this.settingsService.get()')],
  ['settings UI', read('src/renderer/components/SettingsPanel.tsx').includes('Persistent Settings') && read('src/renderer/components/SettingsPanel.tsx').includes('AI Configuration')],
  ['settings registered', read('src/main/ipc/registerIpc.ts').includes('registerSettingsIpcHandlers')],
];
let failed = 0;
for (const [name, ok] of checks) {
  if (ok) console.log(`PASS ${name}`); else { console.log(`FAIL ${name}`); failed++; }
}
if (failed) process.exit(1);
console.log(`PHASE 21 STATIC VERIFY: PASSED (${checks.length} checks)`);
