const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const Module = require('node:module');
const ts = require('typescript');
const realLoad = Module._load;
const stores = new Map();
class MemoryStore {
  constructor({ name, defaults }) { this.name = name; if (!stores.has(name)) stores.set(name, structuredClone(defaults)); }
  get store() { return stores.get(this.name); }
  get(key) { return stores.get(this.name)[key]; }
  set(key, value) { stores.get(this.name)[key] = value; }
}
Module._extensions['.ts'] = (mod, filename) => mod._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText, filename);
Module._load = function (request, parent, isMain) {
  if (request === 'electron-store') return { __esModule: true, default: MemoryStore };
  if (request === 'electron') return { app: { getPath: () => os.tmpdir() }, safeStorage: { isEncryptionAvailable: () => true, encryptString: (s) => Buffer.from(s), decryptString: (b) => b.toString() } };
  return realLoad.apply(this, arguments);
};
const { SettingsService } = require('../src/main/services/settingsService.ts');
const settings = new SettingsService();
const calls = [];
const response = (ok, status, code) => ({ ok, status, headers: { get: (name) => name === 'x-request-id' ? 'req-example123' : null }, json: async () => ok ? { id: 'gpt-4o-mini', choices: [{ message: { content: 'ok' } }] } : { error: { code } } });
global.fetch = async (url, options) => {
  calls.push({ url, method: options?.method ?? 'GET', authorization: options?.headers?.Authorization });
  return options?.method === 'POST' ? response(false, 429, 'insufficient_quota') : response(true, 200);
};
(async () => {
  const configured = await settings.configureAi('openai', 'gpt-4o-mini', 'sk-proj-fresh');
  assert.equal(configured.saved, true);
  assert.match(configured.validationError, /HTTP 429.*Kode: insufficient_quota.*ID permintaan: req-example123/);
  assert.deepEqual(calls.map(({ method }) => method), ['GET', 'POST']);
  assert.equal(calls[0].authorization, 'Bearer sk-proj-fresh');
  assert.equal(calls[1].authorization, 'Bearer sk-proj-fresh');
  assert.equal(settings.getAiCredentials('openai').apiKey, 'sk-proj-fresh', 'Authenticated key should remain saved');
  calls.length = 0;
  const auth = await settings.checkAiStatus('openai', 'gpt-4o-mini', undefined, true);
  assert.equal(auth.authenticated, true);
  assert.equal(auth.valid, false, 'GET cannot establish generation readiness');
  assert.deepEqual(calls.map(({ method }) => method), ['GET']);
  calls.length = 0;
  const status = await settings.checkAiStatus('openai', 'gpt-4o-mini');
  assert.equal(status.valid, false);
  assert.match(status.message, /insufficient_quota/);
  assert.deepEqual(calls.map(({ method }) => method), ['POST']);
  global.fetch = async () => response(false, 401, 'invalid_api_key');
  await assert.rejects(settings.configureAi('openai', 'gpt-4o-mini', 'sk-proj-invalid'), /HTTP 401/);
  assert.equal(settings.getAiCredentials('openai').apiKey, 'sk-proj-fresh');
  console.log('V5K authenticate/get model, generation 429, save verified key, no auto paid check: PASSED');
})().catch((error) => { console.error(error); process.exitCode = 1; });
