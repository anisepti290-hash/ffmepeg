const { spawnSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');

const root = path.resolve(__dirname, '..');
const toolsDirectory = path.join(root, 'resources', 'ffmpeg');
const env = { ...process.env };

if (process.platform === 'win32') {
  const preflight = spawnSync(process.execPath, [path.join(__dirname, 'preflight-dist.cjs')], { cwd: root, stdio: 'inherit', env });
  if (preflight.status !== 0) process.exit(preflight.status ?? 1);
  if (fs.existsSync(path.join(toolsDirectory, 'ffmpeg.exe'))) {
    env.PATH = `${toolsDirectory}${path.delimiter}${env.PATH || ''}`;
  }
}

const npmCli = process.env.npm_execpath;
if (!npmCli) throw new Error('Jalankan pengujian melalui npm test.');

const steps = [
  ['npm', 'build'],
  ['npm', 'verify:foundation'],
  ['npm', 'verify:uiux'],
  ['npm', 'verify:blank-screen-fix'],
  ['npm', 'test:playlist'],
  ['npm', 'test:render-engine'],
  ['npm', 'test:orchestrator'],
  ['npm', 'test:monitor-pause-cache'],
  ['npm', 'test:phase22'],
  ['node', 'test-v5i-blend-sticker-timing.cjs'],
  ['node', 'test-v5v-ai-providers.cjs'],
  ['node', 'test-ai-validation-fixes.cjs'],
  ['node', 'test-v5w-playlist-sticker-seo.cjs'],
  ['npm', 'test:v5n-bulk'],
  ['npm', 'test:v6e-seo'],
  ['npm', 'test:v6f'],
  ['npm', 'test:v6g-seo'],
  ['npm', 'test:v6i-smooth-loop'],
  ['npm', 'test:v5x-upgrades'],
  ['npm', 'test:v5y-sync'],
  ['npm', 'test:v5z-assets-render'],
];

for (const [kind, name] of steps) {
  const command = process.execPath;
  const args = kind === 'npm' ? [npmCli, 'run', name] : [path.join(__dirname, name)];
  console.log(`\n[PENGUJIAN] ${name}`);
  const result = spawnSync(command, args, { cwd: root, env, stdio: 'inherit' });
  if (result.status !== 0) {
    console.error(`[PENGUJIAN] Gagal: ${name}${result.error ? ` — ${result.error.message}` : ''}`);
    process.exit(result.status ?? 1);
  }
}

console.log('\n[PENGUJIAN] Pemeriksaan V5W dan alur render terbaru lulus.');
