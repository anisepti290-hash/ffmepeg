import fs from 'node:fs';
import path from 'node:path';
const required = [
  'src/shared/domain/aiTypes.ts',
  'src/main/services/aiService/aiCredentialStore.ts',
  'src/main/services/aiService/keyframeExtractor.ts',
  'src/main/services/aiService/promptBuilder.ts',
  'src/main/services/aiService/aiResponseValidator.ts',
  'src/main/services/aiService/aiProviderClient.ts',
  'src/main/services/aiService/timestampGenerator.ts',
  'src/main/services/aiService/seoFileWriter.ts',
  'src/main/services/aiService/youtubeSeoService.ts',
  'src/main/ipc/seoHandlers.ts',
  'src/renderer/components/YoutubeSeoPanel.tsx',
];
for (const file of required) if (!fs.existsSync(file)) throw new Error(`Missing ${file}`);
const checks = [
  ['Provider selection', 'src/shared/domain/aiTypes.ts', /AiProvider/],
  ['Encrypted credential storage', 'src/main/services/aiService/aiCredentialStore.ts', /safeStorage/],
  ['Three keyframes', 'src/main/services/aiService/keyframeExtractor.ts', /representativeTimestamps/],
  ['Base64', 'src/main/services/aiService/keyframeExtractor.ts', /toString\('base64'\)/],
  ['OpenAI Chat Completions', 'src/main/services/aiService/aiProviderClient.ts', /api\.openai\.com\/v1[\s\S]*chat\/completions/],
  ['Gemini generateContent', 'src/main/services/aiService/aiProviderClient.ts', /generateContent/],
  ['Relevant keyword bounds', 'src/main/services/aiService/aiResponseValidator.ts', /boundedStringArray\(data\.keywordsPrimary, 1, 8[\s\S]*boundedStringArray\(data\.keywordsSecondary, 0, 12[\s\S]*boundedStringArray\(data\.keywordsLongTail, 0, 6/],
  ['95-char title validation', 'src/main/services/aiService/aiResponseValidator.ts', /95/],
  ['500-char tags validation', 'src/main/services/aiService/aiResponseValidator.ts', /500/],
  ['Retry 3 attempts', 'src/main/services/aiService/youtubeSeoService.ts', /attempt <= 3/],
  ['Timestamp file', 'src/main/services/aiService/timestampGenerator.ts', /youtubetimestamp\.txt/],
  ['SEO file', 'src/main/services/aiService/seoFileWriter.ts', /youtubeseo\.txt/],
  ['Main-process IPC wrapper', 'src/main/ipc/seoHandlers.ts', /registerIpcHandler/] ,
  ['SEO result channel', 'src/shared/ipc.ts', /SEO_RESULT/],
];
for (const [name, file, pattern] of checks) if (!pattern.test(fs.readFileSync(file, 'utf8'))) throw new Error(`Check failed: ${name}`);
const forbidden = ['TODO', 'FIXME', 'coming soon', 'dummy implementation', 'mock feature'];
for (const file of required) {
  const content = fs.readFileSync(file, 'utf8').toLowerCase();
  for (const marker of forbidden) if (content.includes(marker.toLowerCase())) throw new Error(`Forbidden placeholder in ${file}: ${marker}`);
}
console.log(`PHASE 18 STATIC VERIFY: PASSED (${checks.length} checks)`);
