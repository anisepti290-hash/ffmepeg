import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'docs/TESTING_STRATEGY_PHASE22.md',
  'scripts/test-phase22-unit.cjs',
  'scripts/test-phase22-integration.cjs',
  'scripts/test-phase22-ipc.cjs',
  'scripts/test-phase22-e2e.cjs',
  'package.json',
  'RTM.md',
];
for (const file of required) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
}
const strategy = fs.readFileSync(path.join(root, 'docs/TESTING_STRATEGY_PHASE22.md'), 'utf8');
const unit = fs.readFileSync(path.join(root, 'scripts/test-phase22-unit.cjs'), 'utf8');
const integration = fs.readFileSync(path.join(root, 'scripts/test-phase22-integration.cjs'), 'utf8');
const ipc = fs.readFileSync(path.join(root, 'scripts/test-phase22-ipc.cjs'), 'utf8');
const e2e = fs.readFileSync(path.join(root, 'scripts/test-phase22-e2e.cjs'), 'utf8');
const rtm = fs.readFileSync(path.join(root, 'RTM.md'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const checks = [
  ['classification taxonomy', ['TEST PASSED','NOT RUN','BLOCKED','MANUAL VERIFICATION REQUIRED'].every((x) => strategy.includes(x)) && ['TEST PASSED','NOT RUN','MANUAL VERIFICATION REQUIRED'].every((x) => e2e.includes(x))],
  ['unit coverage required areas', ['duration','CPU','filter','scheduling','timestamp','error translator','encoding','output edge cases'].every((x) => unit.toLowerCase().includes(x.toLowerCase()))],
  ['unit negative edge cases', ['NaN','invalid blend','invalid color','Playlist kosong','Timestamp','normalizeBitrate(0)','invalidExt'].some((x) => unit.includes(x))],
  ['integration FFmpeg', integration.includes("spawnSync('ffmpeg'") && integration.includes('ffprobe')],
  ['integration lifecycle', integration.includes('RenderOrchestrator') && integration.includes("status === 'done'")],
  ['integration cleanup', integration.includes('CacheManager') && integration.includes('cleanupJob')],
  ['IPC boundary coverage', ipc.includes('shared/ipc.ts') && ipc.includes('preload/index.ts') && ipc.includes('settingsHandlers.ts')],
  ['E2E core plus gated cases', e2e.includes('E2E-001 core render smoke') && e2e.includes('E2E-002 SEO completion') && e2e.includes('E2E-003 Windows GUI packaged path')],
  ['package scripts', ['test:phase22:unit','test:phase22:integration','test:phase22:ipc','test:phase22:e2e','test:phase22'].every((key) => Boolean(pkg.scripts?.[key]))],
  ['RTM phase 22 section', rtm.includes('| R-204 |') && rtm.includes('| R-207 |') && rtm.includes('## PHASE 22 DELTA')],
  ['no phase22 placeholders', !/TODO|FIXME|coming soon|implement later|dummy implementation|mock feature/i.test(strategy + unit + integration + ipc + e2e)],
];
for (const [name, ok] of checks) if (!ok) throw new Error(`FAIL: ${name}`);
console.log(`PHASE 22 STATIC VERIFY: PASSED (${checks.length} checks).`);
