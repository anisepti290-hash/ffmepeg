import fs from 'node:fs';
import path from 'node:path';

const required = [
  'src/main/services/cpuController.ts',
  'src/main/ipc/cpuHandlers.ts',
  'src/main/ipc/validation.ts',
  'src/main/ipc/registerIpc.ts',
  'src/main/services/ffmpegEngine/ffmpegRunner.ts',
  'src/main/services/render/renderOrchestrator.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'src/renderer/App.tsx',
  'src/main/services/project/projectValidator.ts',
];
for (const file of required) if (!fs.existsSync(path.join(process.cwd(), file))) throw new Error(`Missing ${file}`);
const cpu = fs.readFileSync(path.join(process.cwd(), 'src/main/services/cpuController.ts'), 'utf8');
if (!cpu.includes('os.availableParallelism')) throw new Error('Logical core detection missing');
if (!cpu.includes('Math.max(1, calculated)')) throw new Error('Minimum thread clamp missing');
if (!cpu.includes('Math.min(cores')) throw new Error('Maximum thread clamp missing');
if (!cpu.includes("'-threads', String(threads)")) throw new Error('FFmpeg thread mapping missing');
const render = fs.readFileSync(path.join(process.cwd(), 'src/main/services/render/renderOrchestrator.ts'), 'utf8');
if (!render.includes('new FfmpegProcess(cpuLoadPercent)')) throw new Error('Render integration missing');
const settings = fs.readFileSync(path.join(process.cwd(), 'src/renderer/components/SettingsPanel.tsx'), 'utf8');
if (!settings.includes('CPU Load Control')) throw new Error('Settings UI missing');
const app = fs.readFileSync(path.join(process.cwd(), 'src/renderer/App.tsx'), 'utf8');
if (app.includes('CPU Load Control')) throw new Error('CPU control leaked into top-level App markup');
console.log('PHASE 13 STATIC VERIFY: PASSED (10 core files checked).');
