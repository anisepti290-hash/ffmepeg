const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const assert = (ok, message) => { if (!ok) throw new Error(message); };
const app = read('src/renderer/App.tsx');
const nav = read('src/renderer/components/MainNav.tsx');
const canvas = read('src/renderer/components/CanvasPreview.tsx');
const settings = read('src/renderer/components/SettingsPanel.tsx');
const logger = read('src/main/utils/logger.ts');
const index = read('src/main/index.ts');
const html = read('src/renderer/index.html');
const checks = [
  ['Five top-level pages', ['Home','Render','Asset','Setting','Help'].every((x) => nav.includes(x))],
  ['Home superpower cards', ['Video Rendering','Audio Support','Asset Library','Fast & Stable'].every((x) => app.includes(x))],
  ['Render sub-navigation', ['Media','Intro','Overlay','Playlist','Sticker Subscribe','Youtube SEO'].every((x) => app.includes(x))],
  ['Asset page has three grids', app.includes('mrp-asset-grid') && ['intro','overlay','stickerSubscribe'].every((x) => app.includes(x))],
  ['Settings includes FFmpeg, upload folder, resolution, CPU, AI', settings.includes('FFmpeg Path') && settings.includes('Default Upload Folder') && settings.includes('Resolution') && settings.includes('CPU Load Control') && settings.includes('AI Configuration')],
  ['Local media protocol', index.includes("protocol.handle('mrp-media'") && html.includes('mrp-media:') && canvas.includes('mrp-media://local')],
  ['Playback error is logged', canvas.includes('onError') && canvas.includes('Preview video playback failed')],
  ['Realtime log history', logger.includes('recentEntries') && logger.includes('getRecentLogEntries')],
  ['No native application menu invocation', !index.includes('installApplicationMenu(') && !index.includes('setApplicationMenu(')],
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`);
assert(checks.every(([, ok]) => ok), 'Phase 24 UI checks failed.');
console.log('PHASE 24 UI VALIDATION: PASSED');
