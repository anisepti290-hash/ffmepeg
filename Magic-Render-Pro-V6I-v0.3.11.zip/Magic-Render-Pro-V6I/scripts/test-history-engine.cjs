const assert = require('node:assert/strict');

function boundedPush(stack, value, limit) {
  return [...stack, value].slice(-limit);
}

function record(state, next, limit) {
  return { past: boundedPush(state.past, state.present, limit), present: next, future: [] };
}

function undo(state, limit) {
  if (!state.past.length) return state;
  const previous = state.past[state.past.length - 1];
  return { past: state.past.slice(0, -1), present: previous, future: boundedPush(state.future, state.present, limit) };
}

function redo(state, limit) {
  if (!state.future.length) return state;
  const next = state.future[state.future.length - 1];
  return { past: boundedPush(state.past, state.present, limit), present: next, future: state.future.slice(0, -1) };
}

let state = { past: [], present: 'A', future: [] };
state = record(state, 'B', 3);
state = record(state, 'C', 3);
assert.equal(state.present, 'C');
assert.deepEqual(state.past, ['A', 'B']);
state = undo(state, 3);
assert.equal(state.present, 'B');
assert.deepEqual(state.future, ['C']);
state = redo(state, 3);
assert.equal(state.present, 'C');
state = undo(state, 3);
state = record(state, 'D', 3);
assert.deepEqual(state.future, []);
assert.equal(state.present, 'D');
state = record(state, 'E', 3);
state = record(state, 'F', 3);
state = record(state, 'G', 3);
state = record(state, 'H', 3);
assert.deepEqual(state.past, ['E', 'F', 'G']);
console.log('HISTORY TEST: PASSED (7 scenarios).');
