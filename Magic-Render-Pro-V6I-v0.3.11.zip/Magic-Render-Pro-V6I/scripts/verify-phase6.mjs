import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const required = [
  'src/shared/domain/textOverlayTypes.ts',
  'src/main/services/ffmpegEngine/textOverlayBuilder.ts',
  'src/main/services/ffmpegEngine/textOverlayService.ts',
  'src/main/ipc/textOverlayHandlers.ts',
  'src/shared/ipc.ts', 'src/preload/index.ts', 'src/main/ipc/registerIpc.ts', 'src/renderer/App.tsx'
];
for (const file of required) if (!fs.existsSync(path.join(root,file))) throw new Error(`Missing ${file}`);
const files = Object.fromEntries(required.map(f=>[f,fs.readFileSync(path.join(root,f),'utf8')]));
const checks = [
  ['text input', files['src/shared/domain/textOverlayTypes.ts'].includes('text: string')],
  ['font selection', files['src/shared/domain/textOverlayTypes.ts'].includes('fontFamily')],
  ['font style', files['src/shared/domain/textOverlayTypes.ts'].includes('fontStyle')],
  ['neon glow', files['src/shared/domain/textOverlayTypes.ts'].includes('neonGlow') && files['src/main/services/ffmpegEngine/textOverlayBuilder.ts'].includes('shadowcolor')],
  ['font color', files['src/shared/domain/textOverlayTypes.ts'].includes('fontColor')],
  ['bold italic underline', ['bold','italic','underline'].every(x=>files['src/shared/domain/textOverlayTypes.ts'].includes(x))],
  ['stroke', files['src/main/services/ffmpegEngine/textOverlayBuilder.ts'].includes('borderw')],
  ['opacity', files['src/main/services/ffmpegEngine/textOverlayBuilder.ts'].includes('fontcolor=')],
  ['text effects', files['src/shared/domain/textOverlayTypes.ts'].includes('TextEffect')],
  ['animation', files['src/shared/domain/textOverlayTypes.ts'].includes('TextAnimation') && files['src/main/services/ffmpegEngine/textOverlayBuilder.ts'].includes('running-left')],
  ['typed IPC', ['TEXT_ADD','TEXT_UPDATE','TEXT_REMOVE','TEXT_VALIDATE','TEXT_BUILD_FILTER_GRAPH'].every(x=>files['src/shared/ipc.ts'].includes(x))],
  ['renderer preview', files['src/renderer/App.tsx'].includes('Text Overlay System')],
  ['no TODO/FIXME placeholders', !Object.values(files).some(t=>/TODO|FIXME|coming soon|dummy implementation|mock feature/i.test(t))]
];
for (const [name, ok] of checks) if (!ok) throw new Error(`FAIL: ${name}`);
console.log(`PHASE 6 STATIC VERIFY: PASSED (${checks.length} checks).`);
