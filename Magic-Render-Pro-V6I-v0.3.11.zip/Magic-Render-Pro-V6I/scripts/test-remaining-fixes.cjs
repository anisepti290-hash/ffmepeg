const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const Module = require('module');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');
const runtimeRoot = path.join(root, '.remaining-fixes-runtime');
function assert(condition, message) { if (!condition) throw new Error(message); }
function read(rel) { return fs.readFileSync(path.join(root, rel), 'utf8'); }
const staticChecks = [
  ['src/main/services/render/renderOrchestrator.ts', 'findLatestCheckpoint'],
  ['src/main/services/render/renderOrchestrator.ts', 'recoveredCheckpoint?.data.nextStage'],
  ['src/main/services/ffmpegEngine/ffmpegRunner.ts', "stdio: ['pipe', 'pipe', 'pipe']"],
  ['src/main/services/ffmpegEngine/ffmpegRunner.ts', "child.stdin.write('q\\n')"],
  ['src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.ts', 'color=c=black@0:s=${width}x${height}'],
  ['src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts', 'maskedmerge'],
  ['src/main/services/render/renderCommandBuilder.ts', 'scale=${width}:${height}:flags=lanczos,setpts=PTS-STARTPTS'],
  ['src/main/services/ffmpegEngine/commandBuilder.ts', 'pad=${outputWidth}:${outputHeight}'],
  ['src/main/services/render/renderOrchestrator.ts', 'selectRenderStrategy(project, { requireCheckpointPause: false })'],
  ['src/main/services/ffmpegEngine/textOverlayBuilder.ts', 'buildX(c)}+0.9'],
  ['src/main/services/ffmpegEngine/textOverlayBuilder.ts', "'_'.repeat(Math.max(1, Math.ceil(c.text.length * 0.75)))"],
  ['src/main/services/ffmpegEngine/textOverlayBuilder.ts', "const opacity = Number(config.opacity.toFixed(6));"],
  ['src/main/config/environment.ts', "environment === 'development' ? developmentFfmpegRoot : packagedFfmpegRoot"],
  ['src/main/services/audio/audioConcatBuilder.ts', 'inputIndexByPath'],
];
for (const [file, needle] of staticChecks) assert(read(file).includes(needle), `${file} missing ${needle}`);
console.log('STATIC CHECKS #6-16: TEST PASSED');

fs.rmSync(runtimeRoot, { recursive: true, force: true });
const compile = (rel) => {
  const out = path.join(runtimeRoot, rel.replace(/\.tsx?$/, '.js'));
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const source = read(rel);
  fs.writeFileSync(out, ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true }, fileName: rel }).outputText);
};
[
  'src/main/services/ffmpegEngine/commandBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts',
  'src/main/services/ffmpegEngine/textOverlayBuilder.ts',
  'src/main/services/audio/audioConcatBuilder.ts',
  'src/main/services/cache/cacheManager.ts',
  'src/main/services/ffmpegEngine/ffmpegRunner.ts',
  'src/main/services/ffmpegEngine/progressParser.ts',
  'src/main/services/cpuController.ts',
  'src/main/config/environment.ts',
  'src/main/utils/logger.ts',
  'src/shared/app.ts',
].forEach(compile);
const command = require(path.join(runtimeRoot, 'src/main/services/ffmpegEngine/commandBuilder.js'));
const overlay = require(path.join(runtimeRoot, 'src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.js'));
const blend = require(path.join(runtimeRoot, 'src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.js'));
const text = require(path.join(runtimeRoot, 'src/main/services/ffmpegEngine/textOverlayBuilder.js'));
const audio = require(path.join(runtimeRoot, 'src/main/services/audio/audioConcatBuilder.js'));
const c = { autoMute: true, fadeInSec: 1, fadeOutSec: 2, resize: { width: 640, height: 360 }, position: { x: 100, y: 50 }, rotation: 15 };
const filter = command.buildMainMediaFilterGraph(c, 1920, 1080, 10);
assert(filter.includes('pad=1920:1080:100:50:color=black@0') && filter.includes('rotate=15*PI/180:fillcolor=black@0') && (filter.match(/fade=/g) || []).length === 2, '#10 runtime filter regression');
const ov = new overlay.OverlayFilterBuilder();
assert(ov.buildPreOverlayFilters({ type: 'image', config: { speed: 1, resize: null, rotation: 20, opacity: 0.5 } }, 'in', 'out').includes('format=rgba'), '#8 runtime alpha regression');
assert(ov.buildPositionedLayer('a', 'b', 1920, 1080, 5, 7).includes('format=rgba'), '#8 runtime pad regression');
assert(new blend.BlendFilterBuilder().build('a', 'b', 'c', 'screen').includes('format=gbrp'), '#9 RGB blend regression');
const tc = { text: 'RUNNING', fontFamily: 'Arial', fontSize: 50, fontColor: '#ffffff', strokeColor: '#000000', strokeWidth: 1, glowColor: '#ffffff', glowBlur: 2, neonGlow: true, bold: true, italic: false, underline: true, opacity: 0.4, speed: 2, position: { x: 100, y: 100 }, animation: 'running-left' };
const tg = new text.TextOverlayBuilder().build({ id: 'x', config: tc }, 'in', 'out', 10);
assert(tg.includes('w-mod(t*') && !tg.includes("text='________________'"), '#12/#13 runtime text regression');
const pg = new text.TextOverlayBuilder().build({ id: 'p', config: { ...tc, animation: 'pulse' } }, 'in', 'out', 10);
assert(pg.includes("alpha='0.4*"), '#14 runtime opacity regression');
const plan = { totalDurationSeconds: 6, targetDurationSeconds: 6, segments: [{ path: 'same.mp3', durationSeconds: 3 }, { path: 'same.mp3', durationSeconds: 3 }] };
assert(audio.buildAudioConcatCommand('ffmpeg', plan, 'out.aac', 6).args.filter(x => x === '-i').length === 1, '#16 runtime dedupe regression');

const oldLoad = Module._load;
Module._load = function(request) { if (request === 'electron') return { app: { getPath: () => '/tmp' } }; if (request === 'dotenv') return { config: () => {} }; return oldLoad.apply(this, arguments); };
(async () => {
  const { CacheManager } = require(path.join(runtimeRoot, 'src/main/services/cache/cacheManager.js'));
  const temp = fs.mkdtempSync('/tmp/mrp-checkpoint-');
  const cm = new CacheManager(temp);
  const job = await cm.createRenderJob('resume-me');
  await cm.prepareArtifactDirectory(job, 'render');
  const cp = path.join(job, 'render', 'checkpoint.json');
  fs.writeFileSync(cp, JSON.stringify({ projectId: 'resume-me', completedStage: 'visual-layer-composition', nextStage: 'content-flow', jobDir: job, outputPath: path.join(temp, 'out.mp4'), createdAt: new Date().toISOString() }));
  const found = await cm.findLatestCheckpoint('resume-me');
  assert(found && found.data.nextStage === 'content-flow', '#6 checkpoint recovery regression');
  fs.rmSync(temp, { recursive: true, force: true });

  const { FfmpegProcess } = require(path.join(runtimeRoot, 'src/main/services/ffmpegEngine/ffmpegRunner.js'));
  const proc = new FfmpegProcess(null);
  const done = proc.run({ executable: 'ffmpeg', args: ['-f', 'lavfi', '-i', 'testsrc=size=32x32:rate=10', '-f', 'null', '-'] });
  await new Promise(r => setTimeout(r, 250));
  assert(proc.isRunning(), '#7 FFmpeg test did not start');
  proc.gracefulStop(2000);
  const result = await done;
  assert(result.exitCode === 0 && !result.cancelled, '#7 graceful stop did not exit cleanly');

  process.resourcesPath = '/tmp/resources';
  process.env.MAGIC_RENDER_ENV = 'development';
  delete process.env.MAGIC_RENDER_FFMPEG_PATH;
  const env = require(path.join(runtimeRoot, 'src/main/config/environment.js'));
  const cfg = env.createRuntimeConfig();
  assert(cfg.ffmpegPath.replaceAll('\\\\', '/').endsWith('/resources/ffmpeg/ffmpeg.exe') || cfg.ffmpegPath.replaceAll('\\', '/').endsWith('/resources/ffmpeg/ffmpeg.exe'), '#15 dev FFmpeg path regression');
  console.log('RUNTIME CHECKS #6-16: TEST PASSED');
  fs.rmSync(runtimeRoot, { recursive: true, force: true });
})().catch(err => { console.error(err); process.exitCode = 1; });
