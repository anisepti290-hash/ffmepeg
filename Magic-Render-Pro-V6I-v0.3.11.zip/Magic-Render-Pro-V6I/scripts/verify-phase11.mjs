import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/renderer/context/historyContext.tsx',
  'src/renderer/context/index.ts',
  'src/renderer/App.tsx',
  'src/renderer/components/CanvasPreview.tsx',
  'scripts/test-history-engine.cjs',
];
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) throw new Error(`Missing ${rel}`);
}
const history = fs.readFileSync(path.join(root, 'src/renderer/context/historyContext.tsx'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/renderer/App.tsx'), 'utf8');
const canvas = fs.readFileSync(path.join(root, 'src/renderer/components/CanvasPreview.tsx'), 'utf8');
const forbidden = /TODO|FIXME|coming soon|implement later|dummy implementation|mock feature/i;
for (const [name, text] of [['history', history], ['app', app], ['canvas', canvas]]) {
  if (forbidden.test(text)) throw new Error(`Placeholder marker in ${name}`);
}
for (const token of ['Undo', 'Redo', 'clearHistory', 'historyLimit', 'setProject', 'replaceProject']) {
  if (!history.includes(token) && !app.includes(token)) throw new Error(`Missing ${token}`);
}
for (const token of ["mode: 'coalesce'", "mode: 'commit-coalesced'"]) {
  if (!canvas.includes(token)) throw new Error(`Missing drag history coalescing: ${token}`);
}
console.log('PHASE 11 STATIC VERIFY: PASSED (5 core files checked).');
