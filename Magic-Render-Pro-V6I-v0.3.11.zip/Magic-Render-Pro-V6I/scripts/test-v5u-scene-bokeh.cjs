const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process'),ts=require('typescript');
require.extensions['.ts']=(m,f)=>m._compile(ts.transpileModule(fs.readFileSync(f,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,f);
const {buildComposedOutputCommand}=require('../src/main/services/render/renderCommandBuilder.ts');
const {createDefaultProject}=require('../src/main/domain/project/projectFactory.ts');
const run=(args)=>{const p=cp.spawnSync('ffmpeg',['-hide_banner','-loglevel','error',...args],{timeout:60000,maxBuffer:4e6});assert.equal(p.status,0,String(p.stderr));return p.stdout;};
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-v5u-bokeh-'));
try {
 const project=createDefaultProject('Scene Lights',dir,{resolution:'720p',fps:24,bitrateKbps:1000});
 project.intro={enabled:false,path:null,fallbackFadeInSec:0.5,fallbackStyle:'blur',fallbackBlur:12,fallbackBrightness:-0.25};
 project.mainMedia={type:'image',metadata:null,path:'',durationSeconds:0.75,resize:null,position:{x:0,y:0},rotation:0,fade:{fadeInSec:0,fadeOutSec:0},autoMute:true};
 const outputs=[];
 for (const [name,x] of [['left',40],['right',250]]) {
   const input=path.join(dir,`${name}.png`),output=path.join(dir,`${name}.mp4`);
   run(['-f','lavfi','-i','color=c=black:s=320x180','-vf',`drawbox=x=${x}:y=80:w=18:h=18:color=white:t=fill`,'-frames:v','1',input]);
   project.mainMedia.path=input;
   const cmd=buildComposedOutputCommand('ffmpeg',project,output,0.75,0,null,false);
   assert.match(cmd.args.join(' '),/\[scene_lights\]/);
   assert(!cmd.args.some((part)=>part.includes('bokeh-fade.png')));
   run(cmd.args);
   outputs.push(run(['-ss','0.04','-i',output,'-frames:v','1','-pix_fmt','gray','-f','rawvideo','pipe:1']));
 }
 const average=(frame,cx)=>{let n=0,sum=0;for(let y=320;y<384;y++)for(let x=cx-32;x<cx+32;x++){sum+=frame[y*1280+x];n++;}return sum/n;};
 assert(average(outputs[0],200)>average(outputs[1],200)+8,'cahaya di kiri harus berasal dari media kiri');
 assert(average(outputs[1],1036)>average(outputs[0],1036)+8,'cahaya di kanan harus mengikuti media kanan');
 console.log('V5U: bokeh dari lokasi cahaya media utama tanpa tekstur statis PASSED');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
