import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const required = [
  'src/shared/domain/introTypes.ts',
  'src/main/services/intro/introService.ts',
  'src/main/services/intro/index.ts',
  'src/main/ipc/introHandlers.ts',
  'src/renderer/components/IntroPanel.tsx',
  'src/shared/ipc.ts',
  'src/main/ipc/registerIpc.ts',
  'src/preload/index.ts',
  'src/shared/domain/projectTypes.ts',
  'src/main/services/project/projectValidator.ts',
];
for (const relative of required) {
  if (!fs.existsSync(path.join(root, relative))) throw new Error(`Missing ${relative}`);
  const text = fs.readFileSync(path.join(root, relative), 'utf8');
  if (/TODO|FIXME|coming soon|implement later|dummy implementation|mock feature/i.test(text)) throw new Error(`Placeholder in ${relative}`);
}
const projectTypes = fs.readFileSync(path.join(root, 'src/shared/domain/projectTypes.ts'), 'utf8');
if (!projectTypes.includes('intro: ProjectIntro')) throw new Error('ProjectIntro is not shared by ProjectData.');
const ipc = fs.readFileSync(path.join(root, 'src/shared/ipc.ts'), 'utf8');
for (const channel of ['INTRO_LIBRARY','INTRO_SET','INTRO_SELECT','INTRO_BUILD_PLAN']) if (!ipc.includes(channel)) throw new Error(`Missing IPC ${channel}`);
const service = fs.readFileSync(path.join(root, 'src/main/services/intro/introService.ts'), 'utf8');
for (const token of ['getLibrary','set(project','select(project','buildPlan','fallbackFadeInSec','prependIntro']) if (!service.includes(token)) throw new Error(`Missing intro logic ${token}`);
const app = fs.readFileSync(path.join(root, 'src/renderer/App.tsx'), 'utf8');
if (!app.includes("renderTab === 'Intro'") || !app.includes('<IntroPanel')) throw new Error('Intro panel not routed from Render workspace.');
console.log('PHASE 9 STATIC VERIFY: PASSED (10 core files checked).');
