import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/shared/domain/overlayTypes.ts',
  'src/shared/domain/projectTypes.ts',
  'src/main/services/overlay/overlayValidator.ts',
  'src/main/services/overlay/overlayService.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/chromaKeyBuilder.ts',
  'src/main/services/ffmpegEngine/filterGraphBuilder/colorKeyBuilder.ts',
  'src/main/ipc/overlayHandlers.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'src/main/ipc/registerIpc.ts',
];
const read = (f) => fs.readFileSync(path.join(root, f), 'utf8');
for (const file of required) if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
const checks = [
  ['Overlay supports image/video', 'src/shared/domain/overlayTypes.ts', /OverlayMediaType = 'image' \| 'video'/],
  ['Overlay config has opacity', 'src/shared/domain/overlayTypes.ts', /opacity: number/],
  ['Overlay config has position', 'src/shared/domain/overlayTypes.ts', /position: \{ x: number; y: number \}/],
  ['Overlay config has resize', 'src/shared/domain/overlayTypes.ts', /resize: \{ width: number; height: number \} \| null/],
  ['Overlay config has rotation', 'src/shared/domain/overlayTypes.ts', /rotation: number/],
  ['Overlay config has speed', 'src/shared/domain/overlayTypes.ts', /speed: number/],
  ['Overlay config has blend', 'src/shared/domain/overlayTypes.ts', /OverlayBlendMode/],
  ['Overlay config has chroma key', 'src/shared/domain/overlayTypes.ts', /chromaKey: OverlayChromaKey/],
  ['Overlay config has color key', 'src/shared/domain/overlayTypes.ts', /colorKey: OverlayColorKey/],
  ['Modular FilterGraphBuilder', 'src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts', /class FilterGraphBuilder/],
  ['Dedicated OverlayFilterBuilder', 'src/main/services/ffmpegEngine/filterGraphBuilder/overlayFilterBuilder.ts', /class OverlayFilterBuilder/],
  ['Dedicated BlendFilterBuilder', 'src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts', /class BlendFilterBuilder/],
  ['Dedicated ChromaKeyBuilder', 'src/main/services/ffmpegEngine/filterGraphBuilder/chromaKeyBuilder.ts', /class ChromaKeyBuilder/],
  ['Dedicated ColorKeyBuilder', 'src/main/services/ffmpegEngine/filterGraphBuilder/colorKeyBuilder.ts', /class ColorKeyBuilder/],
  ['Argument-array FFmpeg semantics retained', 'src/main/services/ffmpegEngine/ffmpegRunner.ts', /shell: false/],
  ['IPC overlay add whitelisted', 'src/shared/ipc.ts', /OVERLAY_ADD: 'overlay:add'/],
  ['IPC overlay build graph whitelisted', 'src/shared/ipc.ts', /OVERLAY_BUILD_FILTER_GRAPH/],
  ['Renderer has no direct ipcRenderer', 'src/renderer/App.tsx', /^((?!ipcRenderer).)*$/s],
  ['Project validation checks overlays', 'src/main/services/project/projectValidator.ts', /validateOverlayShape/],
];
for (const [label, file, pattern] of checks) if (!pattern.test(read(file))) throw new Error(`Check failed: ${label}`);
const forbidden = ['TODO', 'FIXME', 'coming soon', 'dummy implementation', 'mock feature'];
for (const file of required) for (const token of forbidden) if (read(file).toLowerCase().includes(token.toLowerCase())) throw new Error(`Forbidden placeholder ${token} in ${file}`);
console.log(`PHASE 5 STATIC VERIFY: PASSED (${required.length} files checked).`);
