const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { particlePosition } = require('../dist/shared/domain/effectPreview.js');
const { defaultOverlayConfig } = require('../dist/shared/domain/overlayTypes.js');
const { FilterGraphBuilder } = require('../dist/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.js');
const { buildVisualizerFilters } = require('../dist/main/services/effects/visualizerBuilder.js');
const { buildParticleFilters } = require('../dist/main/services/effects/effectFilterBuilder.js');
const { createDefaultProject } = require('../dist/main/domain/project/projectFactory.js');
const { buildComposedOutputCommand } = require('../dist/main/services/render/renderCommandBuilder.js');
const beat = { bpm: 120, phaseSec: 0, source: 'fallback' };
const particle = { id:'forty-sparks', kind:'twinkle', opacity:.85, flipX:false, flipY:false, rotation:180,
  minCount:40,maxCount:40,minDistance:1200,maxDistance:2000,motion:'spread',speed:4,beatSync:false,color:'#ff00aa',size:25 };
for (const motion of ['spread','fall','drift','evaporate','orbit','spiral','zigzag','bounce','rise']) {
  const xs=[],ys=[];
  for (let i=0;i<40;i++) for (const t of [0,.25,2,17,143]) {
    const p=particlePosition({...particle,motion},i,t,beat);
    assert.ok(p.x >= 25 && p.x <= 1895 && p.y >= 25 && p.y <= 1055,`${motion} #${i} at ${t}: ${JSON.stringify(p)}`);
    if(t===0){xs.push(p.x);ys.push(p.y);}
  }
  assert.ok(Math.max(...xs)-Math.min(...xs)>1200 && Math.max(...ys)-Math.min(...ys)>650,`Full-frame coverage: ${motion}`);
}
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'mrp-v6a-test-'));
function ffmpeg(args){const r=spawnSync('ffmpeg',['-hide_banner','-loglevel','error',...args],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);}
try {
  for(const kind of ['twinkle','smoke','rain']) {
    const graph=buildParticleFilters([{...particle,kind}], '0:v',320,180,beat,10);
    const script=path.join(tmp,`particles-${kind}.txt`);fs.writeFileSync(script,graph.filters.join(';'));
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.2','-filter_complex_script',script,'-map',`[${graph.output}]`,'-frames:v','1','-f','null','-']);
  }
  const masks=[
    {shape:'rectangle',x:.2,y:.2,width:.6,height:.6,inside:[160,90],outside:[35,30]},
    {shape:'square',x:.1,y:.1,width:.8,height:.8,inside:[160,90],outside:[45,35]},
    {shape:'circle',x:.1,y:.1,width:.8,height:.8,inside:[160,90],outside:[55,45]},
    {shape:'oval',x:.1,y:.1,width:.8,height:.8,inside:[160,90],outside:[55,45]},
    {shape:'freehand',x:0,y:0,width:1,height:1,points:[{x:.2,y:.2},{x:.8,y:.2},{x:.8,y:.8},{x:.2,y:.8}],inside:[160,90],outside:[35,30]},
  ];
  for(const mask of masks){
    const config={...defaultOverlayConfig(),resize:{width:320,height:180},mask};
    const graph=new FilterGraphBuilder().build('0:v',[{sourceIndex:1,sourceLabel:'1:v',overlay:{id:'test',type:'image',path:'synthetic',config}}],320,180,10);
    const script=path.join(tmp,`${mask.shape}.txt`), output=path.join(tmp,`${mask.shape}.raw`);
    fs.writeFileSync(script,graph.filterGraph);
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.2','-f','lavfi','-i','color=c=red:s=320x180:r=10:d=0.2','-filter_complex_script',script,'-map',`[${graph.finalLabel}]`,'-frames:v','1','-pix_fmt','rgb24','-f','rawvideo','-y',output]);
    const raw=fs.readFileSync(output), red=([x,y])=>raw[(y*320+x)*3];
    assert.ok(red(mask.inside)>150,`${mask.shape}: inside visible`);
    assert.ok(red(mask.outside)<20,`${mask.shape}: outside transparent`);
  }
  for(const kind of ['bars','line','dots','wave','mirror','spectrum','smoothBars','waveLine','wavePoints','spectrumFire','spectrumCool','spectrumScroll','solidBars','sparkDots','wavePeak','spectrumViridis','spectrumMagma']) {
    const item={id:'v',kind,position:{x:4,y:4},size:{width:300,height:120},color:'#2cf9ff',opacity:.9,sensitivity:2,smoothing:.3,frequencyScale:'log',palette:'rainbow',density:64,glow:0};
    const visual=buildVisualizerFilters([item],'0:v',1,1,10);
    const script=path.join(tmp,`${kind}.txt`);fs.writeFileSync(script,visual.filters.join(';'));
    ffmpeg(['-f','lavfi','-i','color=c=black:s=320x180:r=10:d=0.5','-f','lavfi','-i','sine=frequency=440:duration=0.5','-filter_complex_script',script,'-map',`[${visual.output}]`,'-frames:v','3','-f','null','-']);
  }
  const main=path.join(tmp,'main.png'),overlay=path.join(tmp,'overlay.png'),audio=path.join(tmp,'music.aac'),video=path.join(tmp,'final.mp4');
  ffmpeg(['-f','lavfi','-i','color=c=blue:s=320x180','-frames:v','1','-update','1',main]);
  ffmpeg(['-f','lavfi','-i','color=c=0x00ff00:s=160x90','-vf','drawbox=x=25:y=20:w=110:h=50:color=red:t=fill','-frames:v','1','-update','1',overlay]);
  ffmpeg(['-f','lavfi','-i','sine=frequency=440:duration=1','-c:a','aac',audio]);
  const project=createDefaultProject('V6A integration',tmp,{resolution:'720p',fps:24,bitrateKbps:1000,renderPreset:'fast'});
  project.mainMedia={path:main,type:'image',autoMute:true,resize:{width:1920,height:1080},position:{x:0,y:0},rotation:0,fade:{fadeInSec:0,fadeOutSec:0}};
  project.overlays=[{id:'overlay',type:'image',path:overlay,config:{...defaultOverlayConfig(),resize:{width:600,height:360},position:{x:300,y:300},mask:masks[2],rotation:20,chromaKey:{enabled:true,color:'0x00FF00',similarity:.1,blend:.1}}}];
  project.particleEffects=[{...particle,maxCount:3,minCount:3}];
  project.visualizers=[{id:'visual',kind:'spectrumViridis',position:{x:150,y:800},size:{width:700,height:130},color:'#2cf9ff',opacity:.9,sensitivity:1,frequencyScale:'log',palette:'viridis',density:32,glow:1}];
  ffmpeg(buildComposedOutputCommand('ffmpeg',project,video,1,0,audio,false).args);
  assert.ok(fs.statSync(video).size>10000,'Integrated MP4 with mask, particles and visualizer');
  console.log('V6A: 40 partikel selalu dalam frame, lima bentuk mask transparan, 17 visualizer FFmpeg, dan MP4 gabungan: PASSED');
} finally { fs.rmSync(tmp,{recursive:true,force:true}); }
