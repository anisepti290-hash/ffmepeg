import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const files = {
  app: 'src/renderer/App.tsx',
  css: 'src/renderer/styles/index.css',
  nav: 'src/renderer/components/MainNav.tsx',
  header: 'src/renderer/components/Header.tsx',
  layout: 'src/renderer/components/AppLayout.tsx',
  rtm: 'RTM.md',
};

for (const file of Object.values(files)) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing ${file}`);
}

const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const app = read(files.app);
const css = read(files.css);
const nav = read(files.nav);
const header = read(files.header);
const layout = read(files.layout);
const rtm = read(files.rtm);

const checks = [
  ['Custom window chrome wired', app.includes('<WindowChrome />') && read('src/renderer/components/WindowChrome.tsx').includes('minimizeWindow')],
  ['Home logo and superpowers wired', app.includes('HomePage') && app.includes('Video Rendering') && app.includes('Fast & Stable')],
  ['Futuristic typography', css.includes('font-family: Orbitron,')],
  ['Neon palette', ['--cyan', '--fuchsia', '--violet'].every((token) => css.includes(token))],
  ['Required top-level navigation labels', ['Home', 'Render', 'Asset', 'Setting', 'Help'].every((label) => nav.includes(label)) && !nav.includes('File')],
  ['Render three-column implementation', app.includes('mrp-render-page') && css.includes('mrp-render-page')],
  ['Responsive desktop breakpoint', css.includes('@media (max-width: 1180px)') && css.includes('@media (max-width: 980px)')],
  ['Canvas remains functional', app.includes('<CanvasPreview ') && app.includes('16:9')],
  ['Render control preserved', app.includes("controlRender('pause')") && app.includes("controlRender('resume')") && app.includes("controlRender('cancel')")],
  ['SEO panel preserved', app.includes('<YoutubeSeoPanel ')],
  ['RTM Phase 19 entries', rtm.includes('| R-199 |') && rtm.includes('| R-203 |') && rtm.includes('## PHASE 19 DELTA')],
];

for (const [name, passed] of checks) {
  console.log(`${passed ? 'PASS' : 'FAIL'}: ${name}`);
  if (!passed) process.exitCode = 1;
}

const placeholderPatterns = /\b(TODO|FIXME|coming soon|dummy implementation|mock feature)\b/i;
const sourceFiles = [];
function walk(dir) {
  for (const entry of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
    const relative = path.join(dir, entry.name);
    if (entry.isDirectory() && !['node_modules', 'dist', '.git'].includes(entry.name)) walk(relative);
    else if (entry.isFile() && /\.(ts|tsx|css|html)$/.test(entry.name)) sourceFiles.push(relative);
  }
}
walk('src');
const hits = sourceFiles.filter((file) => placeholderPatterns.test(read(file)));
console.log(`PASS: Placeholder scan (${sourceFiles.length} source files)${hits.length ? ` — hits: ${hits.join(', ')}` : ''}`);
if (hits.length) process.exitCode = 1;

if (process.exitCode) process.exit(1);
console.log(`PHASE 19 STATIC VERIFY: PASSED (${checks.length} checks)`);
