const assert = require('node:assert/strict');
const Module = require('node:module');
const path = require('node:path');
const fs = require('node:fs');
const outputPath = path.join(require('node:os').tmpdir(), `mrp-live-monitor-${process.pid}.mp4`);
fs.writeFileSync(outputPath, 'render-test');
const { IPC_CHANNELS } = require('../dist/shared/ipc.js');
const handlers = new Map();
const sent = [];
const logs = [];
const mockWindow = { webContents: { send: (...args) => sent.push(args) } };
const originals = Module._load;
Module._load = function (request, parent, isMain) {
  if (parent?.filename.endsWith('ipc/renderHandlers.js')) {
    if (request === 'electron') return { BrowserWindow: { getAllWindows: () => [mockWindow] } };
    if (request === './loggedHandler') return { registerIpcHandler: (channel, handler) => handlers.set(channel, handler) };
    if (request === './validation') return { assertProjectData: (value) => value };
    if (request === './settingsHandlers') return { settingsService: { get: () => ({ ffmpegPath: 'ffmpeg', ffprobePath: 'ffprobe', cpuLoadPercent: 60, renderPreset: 'fast' }), getAiCredentials: () => null } };
    if (request === '../utils/logger') return { logger: { info: (...values) => logs.push(values), error: (...values) => logs.push(values) } };
    if (request === '../services/aiService/youtubeSeoService') return { YoutubeSeoService: class { async generateTimestampOnly() { return 'timestamps.txt'; } } };
    if (request === '../services/render/renderOrchestrator') return { RenderOrchestrator: class {} };
    if (request === '../services/render/gpuDetection') return { detectGpu: async () => ({ name: 'GPU test', vramMb: 2048, encoder: null, available: false, message: 'CPU test' }) };
  }
  return originals.call(this, request, parent, isMain);
};
const { registerRenderIpcHandlers } = require('../dist/main/ipc/renderHandlers.js');
Module._load = originals;
Module._load = function (request, parent, isMain) {
  if (parent?.filename.endsWith('ipc/appHandlers.js')) {
    if (request === 'electron') return { app: { getVersion: () => '0.1.0' }, BrowserWindow: { getFocusedWindow: () => null }, dialog: {} };
    if (request === './loggedHandler') return { registerIpcHandler: (channel, handler) => handlers.set(channel, handler) };
    if (request === './validation') return { assertNoArguments: (_channel, args) => assert.equal(args.length, 0) };
    if (request === '../utils/logger') return { getRecentLogEntries: () => [{ createdAt: '2026-09-26T12:00:00Z', level: 'INFO', message: 'Render disiapkan.', detail: null }], logger: {} };
  }
  return originals.call(this, request, parent, isMain);
};
const { registerAppIpcHandlers } = require('../dist/main/ipc/appHandlers.js');
Module._load = originals;
registerAppIpcHandlers({ appName: 'Magic Render Pro', runtime: { environment: 'production' } });
const project = { projectId: 'monitor-test', settings: { cpuLoadPercent: 75, renderPreset: 'slow' }, youtubeSEO: { mode: 'timestamp' } };
const fakeOrchestrator = {
  configureExecutables: () => undefined, isBusy: () => false, isRunning: () => false,
  async start(input, onProgress) {
    assert.equal(input.settings.cpuLoadPercent, 60);
    assert.equal(input.settings.renderPreset, 'fast');
    if (input.projectId === 'broken') throw new Error('FFmpeg tidak tersedia');
    onProgress({ projectId: input.projectId, status: 'compressing_video', percent: 24, currentTimeSec: 2, totalDurationSec: 10, speedMultiplier: 1.5, elapsedRenderSec: 1, logLine: 'FFmpeg running', errorMessage: null });
    await new Promise((resolve) => setTimeout(resolve, 30));
    onProgress({ projectId: input.projectId, status: 'done', percent: 100, currentTimeSec: 10, totalDurationSec: 10, speedMultiplier: 1.5, elapsedRenderSec: 5, logLine: 'Render selesai.', errorMessage: null });
    return { projectId: input.projectId, outputPath, status: 'done' };
  }, pause: () => true, resume: () => true, cancel: () => true,
};
registerRenderIpcHandlers({ runtime: { ffmpegPath: 'ffmpeg', ffprobePath: 'ffprobe' } }, fakeOrchestrator);
(async () => {
  const job = handlers.get(IPC_CHANNELS.RENDER_START)(null, project);
  assert.ok(sent.some(([channel, event]) => channel === IPC_CHANNELS.RENDER_PROGRESS && /Permintaan diterima/.test(event.logLine)), 'Main process must acknowledge render before awaiting the engine.');
  await new Promise((resolve) => setTimeout(resolve, 5));
  const live = handlers.get(IPC_CHANNELS.RENDER_GET_PROGRESS)(null, project.projectId);
  assert.equal(live.percent, 24);
  assert.equal(live.speedMultiplier, 1.5);
  await job;
  assert.equal(handlers.get(IPC_CHANNELS.RENDER_GET_PROGRESS)(null, project.projectId).status, 'done');
  assert.ok(sent.some(([channel, event]) => channel === IPC_CHANNELS.RENDER_PROGRESS && event.percent === 24));
  assert.ok(logs.some(([message]) => message.includes('Timestamps')));
  assert.ok(!sent.some(([channel]) => channel === IPC_CHANNELS.APP_LOG), 'Log must use the structured logger');
  assert.equal(handlers.get(IPC_CHANNELS.APP_GET_RECENT_LOGS)(null)[0].message, 'Render disiapkan.');
  await assert.rejects(handlers.get(IPC_CHANNELS.RENDER_START)(null, { ...project, projectId: 'broken' }), /FFmpeg/);
  assert.equal(handlers.get(IPC_CHANNELS.RENDER_GET_PROGRESS)(null, 'broken').status, 'error');
  assert.ok(logs.some(([message]) => message.includes('Gagal memulai')));
  fs.rmSync(outputPath, { force: true });
  console.log('LIVE MONITOR IPC: PASSED (snapshot during render, stream, final status, structured log).');
})().catch((error) => { console.error(error); process.exitCode = 1; });
