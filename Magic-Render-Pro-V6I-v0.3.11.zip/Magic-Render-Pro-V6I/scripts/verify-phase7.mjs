import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const required = [
 'src/shared/domain/stickerTypes.ts',
 'src/main/services/stickerScheduler.ts',
 'src/main/services/stickerValidator.ts',
 'src/main/services/stickerService.ts',
 'src/main/services/ffmpegEngine/stickerFilterBuilder.ts',
 'src/main/services/ffmpegEngine/stickerAudioBuilder.ts',
 'src/main/ipc/stickerHandlers.ts',
 'src/renderer/components/StickerPanel.tsx',
];
for (const file of required) if (!fs.existsSync(path.join(root,file))) throw new Error(`Missing ${file}`);
const ipc = fs.readFileSync(path.join(root,'src/shared/ipc.ts'),'utf8');
for (const token of ['STICKER_ADD','STICKER_UPDATE','STICKER_REMOVE','STICKER_VALIDATE','STICKER_BUILD_FILTER_GRAPH']) if (!ipc.includes(token)) throw new Error(`Missing IPC ${token}`);
const graph = fs.readFileSync(path.join(root,'src/main/services/ffmpegEngine/stickerFilterBuilder.ts'),'utf8');
for (const token of ['buildScheduleWindows','chromakey=','colorkey=','colorchannelmixer=aa=','overlay=x=']) if (!graph.includes(token)) throw new Error(`Missing graph behavior ${token}`);
const sched = fs.readFileSync(path.join(root,'src/main/services/stickerScheduler.ts'),'utf8');
for (const token of ['iterative','timestamp','full-duration']) if (!sched.includes(token)) throw new Error(`Missing schedule mode ${token}`);
const validator = fs.readFileSync(path.join(root,'src/main/services/stickerValidator.ts'),'utf8');
for (const token of ["'image'","'video'","'gif'",'similarity > 1','blend > 1']) if (!validator.includes(token)) throw new Error(`Missing validation ${token}`);
const projectValidator = fs.readFileSync(path.join(root,'src/main/services/project/projectValidator.ts'),'utf8');
if (!projectValidator.includes('validateStickerShape')) throw new Error('Project validation not wired to sticker model');
const renderer = fs.readFileSync(path.join(root,'src/renderer/App.tsx'),'utf8');
if (!renderer.includes('<StickerPanel')) throw new Error('StickerPanel not wired into renderer');
console.log(`PHASE 7 STATIC VERIFY: PASSED (${required.length} core files checked).`);
