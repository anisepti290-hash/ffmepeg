const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const { buildMainMediaFilterGraph } = require('../dist/main/services/ffmpegEngine/commandBuilder.js');
const { FilterGraphBuilder } = require('../dist/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.js');

function ffmpeg(args) {
  const result = spawnSync('ffmpeg', ['-v', 'error', ...args], { maxBuffer: 4 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(result.stderr.toString());
  return result.stdout;
}
for (const [x, zoom] of [[-80, 0.5], [40, 1.5]]) {
  const graph = buildMainMediaFilterGraph({ autoMute: true, fadeInSec: 0, fadeOutSec: 0, resize: { width: Math.round(320 * zoom), height: Math.round(180 * zoom) }, position: { x, y: -20 }, rotation: 0 }, 320, 180, 1);
  const raw = ffmpeg(['-f', 'lavfi', '-i', 'color=c=red:s=320x180:r=2', '-vf', graph, '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', 'pipe:1']);
  assert.equal(raw.length, 320 * 180 * 3);
}
const overlay = { id: 'green', type: 'image', path: 'green.png', config: { opacity: 1, position: { x: 10, y: 10 }, resize: { width: 64, height: 36 }, rotation: 0, speed: 1, blendMode: 'normal', chromaKey: { enabled: true, color: '0x00FF00', similarity: 0.3, blend: 0.1 }, colorKey: { enabled: false, color: '0x000000', similarity: 0.3, blend: 0.1 } } };
const graph = new FilterGraphBuilder().build('0:v', [{ sourceIndex: 1, sourceLabel: '1:v', overlay }], 320, 180);
const raw = ffmpeg(['-f', 'lavfi', '-i', 'color=c=red:s=320x180:r=2', '-f', 'lavfi', '-i', 'color=c=0x00ff00:s=64x36:r=2', '-filter_complex', graph.filterGraph, '-map', `[${graph.finalLabel}]`, '-frames:v', '1', '-f', 'rawvideo', '-pix_fmt', 'rgb24', 'pipe:1']);
const i = (20 * 320 + 20) * 3;
assert.ok(raw[i] > raw[i+1] * 2, `Expected keyed overlay to expose red background: ${raw.subarray(i, i+3)}`);
console.log('V5 REPAIR INTEGRATION: PASSED (signed position, zoom, keyed FFmpeg overlay).');
