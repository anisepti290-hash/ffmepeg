const assert = require('node:assert/strict');
const fs = require('node:fs');
const Module = require('node:module');
const ts = require('typescript');
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');

for (const extension of ['.ts', '.tsx']) {
  Module._extensions[extension] = (mod, filename) => mod._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText, filename);
}
const { CanvasPreview } = require('../src/renderer/components/CanvasPreview.tsx');
const { validateProvider, generateMultimodal } = require('../src/main/services/aiService/aiProviderClient.ts');
const sticker = { id: 'sticker-1', path: 'subscribe.png', type: 'image', config: { position: { x: 1600, y: 900 }, scale: 1, rotation: 0, opacity: 1, blendMode: 'normal', backgroundRemoval: 'none', schedule: { mode: 'timestamp', timestamps: ['00:30'] }, durationSec: 3 } };
const project = { overlays: [], textOverlays: [], stickerSubscribe: sticker, stickerSubscribes: [sticker], mainMedia: null, playlistTracks: [] };
const markup = renderToStaticMarkup(React.createElement(CanvasPreview, { project, onProjectChange: () => {}, onInfo: () => {} }));
assert.match(markup, /alt="Sticker 1"/, 'Sticker scheduled at 30s must show on initial edit canvas');
assert.match(markup, /Lihat jadwal sticker/, 'Timing preview must be an explicit control');
const hidden = renderToStaticMarkup(React.createElement(CanvasPreview, { project, hiddenLayers: new Set(['sticker:sticker-1']), onProjectChange: () => {}, onInfo: () => {} }));
assert.doesNotMatch(hidden, /alt="Sticker 1"/, 'Eye visibility override must still hide sticker');

(async () => {
  const failure = (code) => ({ ok: false, status: 429, json: async () => ({ error: { code } }), text: async () => JSON.stringify({ error: { code } }) });
  global.fetch = async () => failure('insufficient_quota');
  await assert.rejects(validateProvider('openai', 'gpt-4o-mini', 'sk-proj-test'), /kuota generasi API.*Billing.*insufficient_quota/);
  await assert.rejects(generateMultimodal('openai', 'gpt-4o-mini', 'sk-proj-test', 'SEO', []), /kuota generasi API.*Billing.*insufficient_quota/);
  global.fetch = async () => failure('rate_limit_exceeded');
  await assert.rejects(validateProvider('openai', 'gpt-4o-mini', 'sk-proj-test'), /batas laju permintaan\/token/);
  global.fetch = async () => ({ ok: false, status: 401, json: async () => ({ error: { code: 'invalid_api_key' } }) });
  await assert.rejects(validateProvider('openai', 'gpt-4o-mini', 'sk-proj-test'), /API key tidak valid/);
  console.log('V5J sticker edit preview, eye visibility, AI quota/rate/auth diagnostics: PASSED');
})().catch((error) => { console.error(error); process.exitCode = 1; });
