const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const checks = [];
function check(name, ok, detail='') { checks.push({name, ok, detail}); console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}${detail ? ` — ${detail}` : ''}`); }

const app = read('src/renderer/App.tsx');
const nav = read('src/renderer/components/MainNav.tsx');
const canvas = read('src/renderer/components/CanvasPreview.tsx');
const sticker = read('src/renderer/components/StickerPanel.tsx');
const settings = read('src/renderer/components/SettingsPanel.tsx');
const seo = read('src/renderer/components/YoutubeSeoPanel.tsx');
const css = read('src/renderer/styles/index.css');
const graph = read('src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts');
const playlist = read('src/main/ipc/playlistHandlers.ts');
const providers = read('src/main/services/aiService/aiProviderClient.ts');
const render = read('src/main/ipc/renderHandlers.ts');
const recent = read('src/main/ipc/projectHandlers.ts');
const logged = read('src/main/ipc/loggedHandler.ts');

check('Horizontal Home/Render/Asset/Setting/Help nav', /flex-direction:row/.test(css) && /Home.*Render.*Asset.*Setting.*Help/.test(nav.replace(/\n/g,' ')));
check('No File menu in main navigation', !/File/.test(nav));
check('Recent projects on empty Render page', /Recent Projects/.test(app) && /removeRecentProject/.test(app));
check('Recent project thumbnail/path', /mainMediaPath/.test(app) && /mrp-recent-thumb/.test(app));
check('Canvas resize/rotate handles', /mrp-resize-handle/.test(canvas) && /mrp-rotate-handle/.test(canvas) && /beginGesture\(kind, id, 'rotate'/.test(canvas));
check('Text canvas scale/rotation persisted', /scale\?: number/.test(read('src/shared/domain/textOverlayTypes.ts')) && /rotation\?: number/.test(read('src/shared/domain/textOverlayTypes.ts')));
check('Dark select + white text', /\.mrp-dark-select, select \{ background:#000 !important; color:#fff !important/.test(css));
check('Chroma key slider in overlay', /Chroma Key Level/.test(app) && /type="range"/.test(app));
check('Overlay modular filtergraph button removed', !/Build Modular FilterGraph/.test(app));
check('No IPC activity logger noise', !/IPC activity/.test(logged));
check('Overlay graph avoids disabled identity format chains', /if \(needsChroma\)/.test(graph) && /if \(needsColorKey\)/.test(graph));
check('Playlist summary exposes shuffled playback order', /valid\.playlist\.shuffle \? getService\(\)\.getPlaybackOrder/.test(playlist));
check('Sticker keying sliders and automatic duration display', /Chroma Key Level/.test(sticker) && /Durasi otomatis/.test(sticker));
check('Sticker timestamp minute/second sliders', /Menit/.test(sticker) && /Detik/.test(sticker) && /type="range"/.test(sticker));
check('SEO timestamp-only mode', /mode === 'timestamp'/.test(seo) && /timestamp-seo/.test(seo));
check('Render gates AI only for SEO mode', /seoMode === 'timestamp-seo'/.test(render) && /generateTimestampOnly/.test(render));
check('Recent delete IPC', /PROJECT_REMOVE_RECENT/.test(recent));
check('Five AI providers', /openrouter/.test(providers) && /groq/.test(providers) && /mistral/.test(providers));
check('Settings 3-column grid', /mrp-settings-grid/.test(settings) && /repeat\(3/.test(css));

const failed = checks.filter(x => !x.ok);
console.log(`\nPHASE 27 VALIDATION: ${failed.length ? 'FAILED' : 'PASSED'} (${checks.length} checks)`);
process.exitCode = failed.length ? 1 : 0;
