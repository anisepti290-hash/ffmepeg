import { readFile } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/main/services/cache/cacheManager.ts',
  'src/main/services/render/renderOrchestrator.ts',
  'src/main/services/ffmpegEngine/artifactRegistry.ts',
  'src/main/services/render/tempArtifactRegistry.ts',
  'src/main/index.ts',
  'scripts/test-cache-manager.cjs',
];
const checks = [];
for (const file of required) {
  const full = path.join(root, file);
  const content = await readFile(full, 'utf8');
  if (!content.trim()) throw new Error(`Empty required file: ${file}`);
  checks.push(file);
}
const cache = await readFile(path.join(root, 'src/main/services/cache/cacheManager.ts'), 'utf8');
const render = await readFile(path.join(root, 'src/main/services/render/renderOrchestrator.ts'), 'utf8');
for (const token of ['app.getPath(\'temp\')', 'MagicRenderPro', 'createRenderJob', 'cleanupJob', 'cleanupStaleJobs', 'RETRIES', 'EACCES', 'EPERM']) {
  if (!cache.includes(token)) throw new Error(`Missing cache requirement token: ${token}`);
}
for (const token of ['appendRenderLog', 'cleanupJob(jobDir)', 'RenderArtifactRegistry']) {
  if (!render.includes(token)) throw new Error(`Missing render integration token: ${token}`);
}
if (render.includes('SIGSTOP')) throw new Error('Phase 16 introduced forbidden SIGSTOP handling.');
console.log(`PHASE 16 STATIC VERIFY: PASSED (${checks.length} files checked).`);
