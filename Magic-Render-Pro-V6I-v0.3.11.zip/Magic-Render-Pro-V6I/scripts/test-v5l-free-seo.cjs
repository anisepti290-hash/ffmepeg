const assert = require('node:assert/strict');
const fs = require('node:fs');
const Module = require('node:module');
const ts = require('typescript');

Module._extensions['.ts'] = (mod, filename) => mod._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText, filename);
const { listProviderModels, validateProvider, generateMultimodal } = require('../src/main/services/aiService/aiProviderClient.ts');
const { normalizeSeoContext } = require('../src/main/services/aiService/seoContext.ts');
const { buildSeoPrompt } = require('../src/main/services/aiService/promptBuilder.ts');
const { parseAndValidateAiResponse } = require('../src/main/services/aiService/aiResponseValidator.ts');

const seo = {
  visualAnalysis: 'A person sits near a sunset landscape.', audienceIntent: 'People seeking relaxing music.',
  visualEvidence: { observed: ['One person', 'Orange sky'], interpreted: ['Reflective mood'], uncertain: ['Actual location unknown'], visibleText: [] },
  titleNotes: ['Clear topic', 'Search phrase', 'Audience fit', 'Distinct angle', 'Honest promise'],
  keywordsPrimary: ['relaxing blues'], keywordsSecondary: ['slow music'], keywordsLongTail: ['blues for a quiet evening'],
  titles: ['Relaxing Blues for a Quiet Evening', 'Slow Blues Music for Reflection', 'Evening Blues to Unwind', 'Gentle Blues Playlist', 'Soft Blues for a Peaceful Night'],
  descriptions: { seoRich: 'Relaxing blues music for a quiet evening.', engagement: 'Unwind with slow blues.', premium: 'A calm blues listening experience.' },
  tags: ['relaxing blues', 'slow blues', 'evening music', 'calm music', 'blues playlist'], hashtags: ['#Blues', '#RelaxingMusic', '#EveningMusic'],
};
const response = (payload) => ({ ok: true, status: 200, text: async () => JSON.stringify(payload), json: async () => payload });
const calls = [];
global.fetch = async (url, options = {}) => {
  calls.push({ url: String(url), ...options });
  if (String(url).includes('generativelanguage') && !options.method) return response({ models: [{ name: 'models/gemini-2.5-flash-lite', supportedGenerationMethods: ['generateContent'] }, { name: 'models/gemini-2.5-pro', supportedGenerationMethods: ['generateContent'] }] });
  if (String(url).includes('groq.com') && !options.method) return response({ data: [{ id: 'qwen/qwen3.8-27b' }, { id: 'llama-3.1-8b-instant' }] });
  if (String(url).includes('openrouter.ai') && !options.method) return response({ data: [
    { id: 'vision/free:free', pricing: { prompt: '0', completion: '0' }, architecture: { input_modalities: ['text', 'image'] } },
    { id: 'text/free:free', pricing: { prompt: '0', completion: '0' }, architecture: { input_modalities: ['text'] } },
    { id: 'vision/paid:free', pricing: { prompt: '0.01', completion: '0' }, architecture: { input_modalities: ['image'] } },
  ] });
  if (String(url).includes('/api/tags')) return response({ models: [{ name: 'gemma3:4b' }, { name: 'llama3:8b' }] });
  if (options.method === 'POST' && String(url).includes('gemini')) return response({ candidates: [{ content: { parts: [{ text: JSON.stringify(seo) }] } }] });
  if (options.method === 'POST') return response({ choices: [{ message: { content: JSON.stringify(seo) } }] });
  throw new Error(`Unexpected ${url}`);
};

(async () => {
  assert.deepEqual(await listProviderModels('gemini', 'test', true), ['gemini-2.5-flash-lite']);
  assert.deepEqual(await listProviderModels('groq', 'test', true), ['qwen/qwen3.8-27b']);
  assert.deepEqual(await listProviderModels('openrouter', 'test', true), ['openrouter/free', 'vision/free:free']);
  assert.deepEqual(await listProviderModels('ollama', '', true), ['gemma3:4b']);
  await validateProvider('ollama', 'gemma3:4b', '');
  const localCall = calls.at(-1);
  assert.equal(localCall.headers.Authorization, undefined);
  assert.equal(JSON.parse(localCall.body).messages[0].content[1].type, 'image_url');
  const frame = { timestampSec: 2, mimeType: 'image/jpeg', base64: 'YQ==' };
  const prompt = buildSeoPrompt('relaxing blues', [frame], normalizeSeoContext({ videoTopic: 'slow blues', audioGenre: 'blues', excludeTerms: 'actual location', seoStrategy: 'search' }));
  assert.match(prompt, /actual location/);
  assert.match(prompt, /No invented numerical confidence percentages/);
  const generated = await generateMultimodal('gemini', 'gemini-2.5-flash-lite', 'test', prompt, [frame]);
  assert.deepEqual(parseAndValidateAiResponse(generated.text).visualEvidence.observed, ['One person', 'Orange sky']);
  const geminiRequest = JSON.parse(calls.at(-1).body);
  assert.equal(geminiRequest.contents[0].parts[1].inlineData.mimeType, 'image/jpeg');
  assert.equal(geminiRequest.generationConfig.thinkingConfig.thinkingBudget, 0);
  assert.throws(() => normalizeSeoContext({ videoTopic: 'x'.repeat(241) }), /maksimal 240/);
  assert.throws(() => parseAndValidateAiResponse(JSON.stringify({ ...seo, titles: [] })), /titles harus/);
  console.log('V5L provider catalog, local vision, context, compact SEO output: PASSED');
})().catch((error) => { console.error(error); process.exitCode = 1; });
