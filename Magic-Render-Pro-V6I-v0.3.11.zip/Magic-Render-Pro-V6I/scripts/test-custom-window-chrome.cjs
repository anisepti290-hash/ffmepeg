const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const main = read('src/main/index.ts');
const app = read('src/renderer/App.tsx');
const nav = read('src/renderer/components/MainNav.tsx');
const chrome = read('src/renderer/components/WindowChrome.tsx');
const css = read('src/renderer/styles/index.css');
const intro = read('src/main/ipc/introHandlers.ts');
const canvas = read('src/renderer/components/CanvasPreview.tsx');
const html = read('src/renderer/index.html');
const pkg = JSON.parse(read('package.json'));
const checks = [
  ['React custom title bar enabled', /frame:\s*false/.test(main) && /autoHideMenuBar:\s*true/.test(main)],
  ['React window controls exist', /minimizeWindow|toggleMaximizeWindow|closeWindow/.test(chrome)],
  ['Native File/Help menu is not rendered', !/setApplicationMenu\(/.test(main) && !/File/.test(chrome) && !/Help/.test(chrome)],
  ['Five main navigation pages exist', ['Home', 'Render', 'Asset', 'Setting', 'Help'].every((label) => nav.includes(label)) && !nav.includes('File')],
  ['Home page has only hero/start/superpowers', /HomePage/.test(app) && /Start New Project/.test(app) && /Video Rendering/.test(app) && /Audio Support/.test(app) && /Asset Library/.test(app) && /Fast & Stable/.test(app)],
  ['Render page has six work tabs', ['Media', 'Intro', 'Overlay', 'Playlist', 'Sticker Subscribe', 'Youtube SEO'].every((label) => app.includes(label))],
  ['Window IPC handlers exist', /WINDOW_MINIMIZE/.test(read('src/main/ipc/appHandlers.ts')) && /WINDOW_CLOSE/.test(read('src/main/ipc/appHandlers.ts'))],
  ['Preload exposes window controls', /minimizeWindow:/.test(read('src/preload/index.ts')) && /closeWindow:/.test(read('src/preload/index.ts'))],
  ['Drag/no-drag regions exist', /-webkit-app-region:\s*drag/.test(css) && /-webkit-app-region:no-drag/.test(css)],
  ['Intro dialog import is defined', /import \{ showOpenDialog \} from '\.\/dialogHelper';/.test(intro)],
  ['Local media protocol is wired', /mrp-media/.test(main) && /mrp-media:/.test(html) && /mrp-media:\/\/local/.test(canvas)],
  ['React and React DOM pinned equally', pkg.dependencies.react === pkg.dependencies['react-dom']],
  ['Global IPC wrapper is used', read('src/main/ipc/loggedHandler.ts').includes('IPC activity started') && !['appHandlers.ts','cpuHandlers.ts','introHandlers.ts','lockedAssetHandlers.ts','outputHandlers.ts','overlayHandlers.ts','playlistHandlers.ts','previewHandlers.ts','projectHandlers.ts','renderHandlers.ts','seoHandlers.ts','settingsHandlers.ts','stickerHandlers.ts','textOverlayHandlers.ts'].some((f) => /ipcMain\.handle\(/.test(read(`src/main/ipc/${f}`)))],
  ['Realtime log buffer exists', read('src/main/utils/logger.ts').includes('getRecentLogEntries') && read('src/main/utils/logger.ts').includes('MAX_RECENT_ENTRIES')],
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`); if (!ok) failed++; }
if (failed) process.exit(1);
console.log('CUSTOM WINDOW + PHASE 24 UI VALIDATION: PASSED');
