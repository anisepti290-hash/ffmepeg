import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const requiredFiles = [
  'src/shared/domain/lockedAssetTypes.ts',
  'src/main/services/persistentStore/electronStoreAdapter.ts',
  'src/main/services/persistentStore/lockedAssetValidator.ts',
  'src/main/services/persistentStore/lockedAssetStore.ts',
  'src/main/services/persistentStore/index.ts',
  'src/main/ipc/lockedAssetHandlers.ts',
  'src/main/ipc/registerIpc.ts',
  'src/preload/index.ts',
  'src/main/index.ts',
];

for (const relative of requiredFiles) {
  if (!fs.existsSync(path.join(root, relative))) throw new Error(`Missing Phase 3 file: ${relative}`);
}

const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const store = read('src/main/services/persistentStore/lockedAssetStore.ts');
const adapter = read('src/main/services/persistentStore/electronStoreAdapter.ts');
const ipc = read('src/main/ipc/lockedAssetHandlers.ts');
const preload = read('src/preload/index.ts');
const sharedIpc = read('src/shared/ipc.ts');
const main = read('src/main/index.ts');
const pkg = JSON.parse(read('package.json'));

const checks = [
  ['electron-store dependency declared', typeof pkg.dependencies?.['electron-store'] === 'string'],
  ['electron-store runtime import exists', adapter.includes("dynamicImport('electron-store')")],
  ['locked assets store key exists', store.includes("const STORAGE_KEY = 'lockedAssets'")],
  ['lock implementation exists', store.includes('async lock(')],
  ['unlock implementation exists', store.includes('async unlock(')],
  ['missing asset pruning exists', store.includes('async removeMissing(')],
  ['asset validation exists', store.includes('validateLockedAssetPath')],
  ['metadata persisted', store.includes('metadata = {') && store.includes('originalName') && store.includes('sizeBytes')],
  ['global persistence initialized at app startup', main.includes('initializeLockedAssetPersistence()')],
  ['four supported menus', ipc.includes("'intro', 'overlay', 'stickerSubscribe', 'playlist'")],
  ['typed IPC list/lock/unlock/validate', sharedIpc.includes('LOCKED_ASSETS_LIST') && sharedIpc.includes('LOCKED_ASSETS_LOCK') && sharedIpc.includes('LOCKED_ASSETS_UNLOCK') && sharedIpc.includes('LOCKED_ASSETS_VALIDATE')],
  ['preload exposes no raw ipcRenderer', !preload.match(/exposeInMainWorld\([^,]+,\s*ipcRenderer/)],
  ['project does not own locked asset collection', !read('src/shared/domain/projectTypes.ts').includes('lockedAssets')],
];

const failed = checks.filter(([, ok]) => !ok);
if (failed.length) throw new Error(`Phase 3 verification failed: ${failed.map(([name]) => name).join(', ')}`);
console.log(`PHASE 3 STATIC VERIFY: PASSED (${checks.length} checks)`);
