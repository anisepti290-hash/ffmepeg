import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/shared/domain/renderTypes.ts',
  'src/main/services/ffmpegEngine/progressParser.ts',
  'src/main/services/ffmpegEngine/artifactRegistry.ts',
  'src/main/services/ffmpegEngine/ffmpegRunner.ts',
  'src/main/services/render/renderTypes.ts',
  'src/main/services/render/renderStrategySelector.ts',
  'src/main/services/render/renderCommandBuilder.ts',
  'src/main/services/render/renderOrchestrator.ts',
  'src/main/ipc/renderHandlers.ts',
  'src/shared/ipc.ts',
  'src/preload/index.ts',
  'src/main/ipc/registerIpc.ts',
];
for (const file of required) await fs.access(path.join(root, file));

const tsFiles = [];
async function walk(dir) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (entry.name.endsWith('.ts') || entry.name.endsWith('.tsx')) tsFiles.push(full);
  }
}
await walk(path.join(root, 'src'));
if (tsFiles.length < 50) throw new Error(`Unexpected source file count: ${tsFiles.length}`);

const runner = await fs.readFile(path.join(root, 'src/main/services/ffmpegEngine/ffmpegRunner.ts'), 'utf8');
if (!runner.includes("spawn(command.executable, args") || !runner.includes("shell: false")) throw new Error('FFmpeg runner security contract failed.');
if (!runner.includes("kill('SIGKILL')")) throw new Error('FFmpeg cancel lifecycle contract missing.');

const parser = await fs.readFile(path.join(root, 'src/main/services/ffmpegEngine/progressParser.ts'), 'utf8');
for (const token of ['out_time_ms', 'out_time', 'speed', "value === 'continue' || value === 'end'"]) if (!parser.includes(token)) throw new Error(`Progress parser missing ${token}`);

const orchestrator = await fs.readFile(path.join(root, 'src/main/services/render/renderOrchestrator.ts'), 'utf8');
for (const token of ['buildComposedOutputCommand', 'audio-management', 'output', 'RenderArtifactRegistry', 'registry.cleanup()']) if (!orchestrator.includes(token)) throw new Error(`Render orchestrator missing ${token}`);

const commands = await fs.readFile(path.join(root, 'src/main/services/render/renderCommandBuilder.ts'), 'utf8');
for (const token of ['buildVisualCompositionCommand', 'buildIntroConcatCommand', 'buildFinalOutputCommand', 'buildSinglePassCommand', "-progress"] ) {
  if (token === '-progress') continue;
  if (!commands.includes(token)) throw new Error(`Render command builder missing ${token}`);
}

console.log(`PHASE 12 STATIC VERIFY: PASSED (${required.length} core files + ${tsFiles.length} TS/TSX syntax checks).`);
