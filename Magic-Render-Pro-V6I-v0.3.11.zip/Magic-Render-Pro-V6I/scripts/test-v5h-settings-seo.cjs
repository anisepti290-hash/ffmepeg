const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const Module = require('node:module');
const ts = require('typescript');
const realLoad = Module._load;
const db = new Map();
class MemoryStore {
  constructor({ name, defaults }) { this.name = name; if (!db.has(name)) db.set(name, structuredClone(defaults)); }
  get store() { return db.get(this.name); }
  get(key) { return db.get(this.name)[key]; }
  set(key, value) { db.get(this.name)[key] = value; }
}
const safeStorage = {isEncryptionAvailable:()=>true,encryptString:(value)=>Buffer.from(value),decryptString:(value)=>value.toString()};
Module._extensions['.ts'] = (mod, filename) => mod._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'), {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText,filename);
Module._load = function(request,parent,isMain) {
  if(request==='electron') return {app:{getPath:()=>os.tmpdir()},safeStorage};
  if(request==='electron-store') return {__esModule:true,default:MemoryStore};
  return realLoad.apply(this,arguments);
};
const {SettingsService}=require('../src/main/services/settingsService.ts');
const {validateProvider}=require('../src/main/services/aiService/aiProviderClient.ts');
const calls=[];
global.fetch=async (url,options)=>{calls.push({url:String(url),options});const payload={choices:[{message:{content:'OK'}}],candidates:[{content:{parts:[{text:'OK'}]}}]};return {ok:true,status:200,headers:{get:()=>null},json:async()=>payload,text:async()=>JSON.stringify(payload)};};
(async()=>{
  const first=new SettingsService();
  const destination=path.join(os.tmpdir(),'mrp-export-persisted');
  first.update({outputDir:destination});
  const reopened=new SettingsService();
  assert.equal(reopened.get().outputDir,destination,'Output folder was reset when settings reopened');
  const preview=await reopened.checkAiStatus('openai','gpt-4o','typed-key');
  assert.equal(preview.valid,true);assert.equal(preview.configured,false);
  assert.equal(calls[0].options.method,'POST');assert.match(calls[0].url,/chat\/completions$/);assert.match(calls[0].options.body,/image_url/);
  await reopened.configureAi('openai','gpt-4o','persisted-key');
  assert.equal(new SettingsService().getAiCredentials('openai').apiKey,'persisted-key');
  assert.equal((await new SettingsService().checkAiStatus('openai','gpt-4o')).valid,true);
  assert.equal(Object.values(db.get('magic-render-pro-settings')).includes('persisted-key'),false,'API key leaked to global settings');
  await validateProvider('gemini','gemini-2.0-flash','gemini-key');
  assert.match(calls.at(-1).url,/:generateContent\?/);assert.match(calls.at(-1).options.body,/inlineData/);
  await validateProvider('mistral','mistral-small-latest','mistral-key');
  assert.equal(typeof JSON.parse(calls.at(-1).options.body).messages[0].content[1].image_url,'string');
  global.fetch=async()=>({ok:false,status:401,headers:{get:()=>null},text:async()=>JSON.stringify({error:{code:'invalid_api_key'}})});
  assert.equal((await reopened.checkAiStatus('openai','gpt-4o')).valid,false,'Invalid API key accepted');
  await assert.rejects(reopened.configureAi('openai','gpt-4o','bad-key'),/HTTP 401/);
  assert.equal(reopened.getAiCredentials('openai').apiKey,'persisted-key','Rejected key replaced valid credential');
  console.log('V5H SETTINGS OUTPUT PERSISTENCE, LIVE AI CHECK/SAVE/REJECT: PASSED');
})().catch(e=>{console.error(e);process.exitCode=1});
