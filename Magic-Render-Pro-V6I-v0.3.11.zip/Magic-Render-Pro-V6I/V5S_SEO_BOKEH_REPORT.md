# Magic Render Pro V5S — SEO sederhana dan fade bokeh

## Perubahan utama

- YouTube SEO Opsi 2 menampilkan dua isian: **Main Keyword** dan **Niche/Genre**. Template lokal dapat disimpan, dipilih, dan dihapus; tersedia kembali ketika aplikasi dan project dibuka ulang pada profil aplikasi yang sama. Kolom konteks lama tetap dapat dibaca dari project sebelumnya, tetapi tidak mengendalikan prompt jika Niche/Genre baru sudah ada.
- Analisis visual mengambil frame dari **main media** (`project.mainMedia.path`), bukan intro atau video hasil gabungan. Gambar diam maupun video diperkecil menjadi frame JPEG maksimum 1280×720 untuk menghindari unggahan media 4K asli. Cuplikan video diambil dari tiga titik waktu yang mewakili awal, tengah, dan akhir.
- AI berjalan dalam dua tahap. Tahap 1 dengan frame visual mengekstraksi fakta yang terlihat, tafsiran dan ketidakpastian, hipotesis tujuan pendengar US dan pencarian, serta tepat **50 kata kunci utama + 50 sekunder + 25 long-tail**. Tahap 2 berbasis ringkasan terverifikasi tanpa mengunggah frame ulang menghasilkan **10 judul maksimal 95 karakter, 3 variasi deskripsi, 1–50 tags di bawah 500 karakter, dan 5–7 hashtags**. Output dihentikan jika jumlah, duplikasi, panjang, atau format tidak valid; satu kesempatan ulang tersedia per tahap untuk respons model yang tidak lengkap.
- Analisis tujuan audiens dan genre dari gambar adalah dugaan yang ditandai. Aplikasi tidak mengambil data pencarian US secara langsung dan tidak dapat memastikan instrumen, vokal, atau lirik hanya dari gambar. Niche/genre yang diisi pengguna diperlakukan sebagai informasi konfirmasi pengguna. Hasil final tetap draf yang harus diperiksa sebelum publikasi.
- Menu Intro memiliki dua kolom: aset Intro dan Fade tanpa Intro. **Fade bokeh** memakai tekstur lingkar cahaya transparan `resources/bokeh-fade.png`, defokus, durasi dan kecerahan awal. Preview dan FFmpeg menggunakan tekstur yang sama dan tingkat kecerahan sebagai pengali; FFmpeg memproses blur hanya selama segmen pembuka. Tekstur ikut dikemas melalui `extraResources` untuk build Windows. Fade fallback tetap tidak aktif selama intro atau Fade-In Media Utama aktif.

## File yang diubah

- `src/renderer/components/YoutubeSeoPanel.tsx` — dua isian, template tersimpan, hasil SEO.
- `src/main/services/aiService/seoPipeline.ts` — skema, prompt dua tahap, validasi keluaran.
- `src/main/services/aiService/youtubeSeoService.ts` — sumber frame media utama, dua panggilan model, log.
- `src/main/services/aiService/keyframeExtractor.ts` — resize gambar diam.
- `src/main/services/aiService/aiProviderClient.ts` — batas token keluaran per tahap.
- `src/shared/domain/aiTypes.ts`, `src/main/services/aiService/seoContext.ts`, `src/main/ipc/seoHandlers.ts`, `src/main/ipc/renderHandlers.ts` — Niche/Genre dan validasi.
- `src/renderer/components/IntroPanel.tsx`, `src/renderer/components/CanvasPreview.tsx`, `src/renderer/styles/index.css`, `src/main/services/render/renderCommandBuilder.ts`, `resources/bokeh-fade.png` — dua kolom dan fade bokeh preview/render.
- `package.json`, `package-lock.json`, `src/renderer/App.tsx`, `src/main/ipc/appHandlers.ts` — versi, bundel tekstur, bantuan.
- Tes baru: `scripts/test-v5s-seo-bokeh.cjs`, `scripts/test-v5s-seo-service.cjs`. Tidak ada file sumber fitur lama yang dihapus.

## Pengujian

`npm run build`, tes V5S layanan SEO dengan respons model tiruan, validasi 125 kandidat + 10 judul, ekstraksi dua gambar berbeda, ekspor FFmpeg dan piksel bokeh awal/akhir; tes regresi V5L, V5Q, V5R dan `test-render-orchestrator` lulus. Panggilan sungguhan ke layanan AI tidak diuji karena membutuhkan model vision dan kredensial pengguna. Kualitas dan kemampuan memenuhi 125 keyword bergantung pada model terpilih; jika model tidak memenuhi aturan, aplikasi mengeluarkan kesalahan jelas tanpa menyimpan draf parsial.
