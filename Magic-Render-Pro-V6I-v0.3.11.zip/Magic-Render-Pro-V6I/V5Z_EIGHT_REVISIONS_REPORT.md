# Magic Render Pro V5Z • v0.3.2

## Revisi dan penyebab

| Bagian | Penyebab / perubahan |
| --- | --- |
| Panel kanan | Workspace digulir dalam `.mrp-page-content`; kolom kanan belum `sticky`. Pada desktop kolom kanan sekarang sticky dan mempunyai gulir internal jika terlalu tinggi. |
| Visualizer preview | Ref audio dapat berubah tanpa memicu efek Web Audio, sedangkan loop gambar menangkap `playing=false` dari render awal sehingga tetap diam saat Play. Media element kini dikirim sebagai state, memakai `crossOrigin`; status Play dibaca dari ref terbaru dan gaya baru diberi bentuk diam sebelum playback. |
| Overlay Asset | Preset belum menyimpan crop/trim. Area crop disimpan sebagai persen sumber; trim memilih rentang video yang diputar berulang pada filter final tanpa intermediate encode. |
| Pintasan Asset | Handler global menghentikan shortcut saat dialog terbuka. Canvas editor aset kini memiliki fokus dan handler lokal untuk geser, resize, rotasi, play, dan awal. Ctrl+S tetap memakai tombol Simpan Preset. |
| Bulk Render | Durasi sticker default selalu 3 detik meskipun asset video/GIF lebih panjang. Mode otomatis membaca durasi file sticker yang terpilih untuk tiap video. Gambar tetap 3 detik, dan durasi manual tersedia. |
| Help | About dan System Information kini ditampilkan sebagai artikel dengan spesifikasi praktis dan teknologi aplikasi; kontak 082220893828. |
| INVALID_FILTER | Pilihan `linear` dari UI tidak sah sebagai `fscale` FFmpeg, yang mensyaratkan `lin`. Nilai similarity chroma/color 0 juga di luar rentang FFmpeg. Kedua parameter dipetakan ke nilai sah dan kesalahan FFmpeg yang spesifik tidak lagi disembunyikan dari pesan. |

## Penjelasan alur render, tanpa perubahan strategi

Playlist menentukan panjang **konten**. Bila intro aktif, durasi intro ditambahkan
pada durasi final. Lagu disatukan menjadi AAC pada tahap `audio-management`.
Tahap `output` me-loop media utama/overlay, menggabungkan seluruh lapisan,
intro, sticker, partikel, dan visualizer, lalu mengode video final **satu kali**.
Video tidak dapat di-*stream copy* ketika ada perubahan piksel; audio hasil
tahap pertama dipetakan dengan `-c:a copy` ke MP4. Sticker gambar ber-keying
dapat dibuat sebagai PNG RGBA satu kali sebelum tahap output, bukan encode
video kedua. Preset trim overlay memakai pemilihan frame selama output.

## Validasi

`npm run typecheck`; `npm run test:v5z-assets-render` menguji MP4 nyata
bersama overlay trim/crop/chroma, sticker, serta visualizer `Linear`. Jalankan
`npm test` untuk regresi gabungan. Paket Electron Windows dan tampilan pada
perangkat pengguna tetap memerlukan uji nyata.
