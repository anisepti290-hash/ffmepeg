# Magic Render Pro V5O — 10 revisi

Basis: V5N terakhir. Arsip ini berisi source, build `dist`, konfigurasi, skrip uji, dan laporan. Jalankan `npm ci` dan `npm run dev` untuk pengembangan, atau `npm run build` lalu `npm start` untuk build lokal. `node_modules` tidak disertakan.

## Hasil

- Pengaturan sticker diperbarui langsung ke state proyek sehingga tidak hilang ketika berpindah menu; pilihan jenis media juga diingat sepanjang sesi. Tombol Terapkan memvalidasi dan menyimpan pengaturan sticker. Komposisi FFmpeg menetapkan straight alpha secara eksplisit supaya PNG beralpha dan nilai opacity sesuai preview.
- Selama render, panel kontrol media dan canvas preview yang berat dijeda; Pause/Cancel dan monitor tetap berfungsi. Event progress UI dibatasi, polling dikurangi, log FFmpeg ditulis secara batch, dan buffer keluaran proses dibatasi untuk mencegah beban memori saat render panjang. Jam render memakai waktu dinding yang diperbarui tiap satu detik serta berhenti saat pause/cancel.
- Tombol Reset Render dihapus; Cancel menghentikan proses dan mengosongkan monitor termasuk render yang masih menyiapkan media. Ikon mata, gembok, dan hapus tersedia tepat di header Text Overlay System untuk teks terpilih.
- GPU Mode dapat dipilih CPU/GPU di Settings. Detect GPU menampilkan nama VGA dan VRAM yang dapat dibaca sistem, memeriksa encoder H.264 yang cocok dan mencoba encode satu frame. GPU Mode memilih NVENC/AMF/QSV; bila tidak ada encoder/driver yang siap, render menampilkan pesan kesalahan jelas. Komposisi filter video tetap dapat memakai CPU. Pop-up selesai menampilkan mode render, VGA, VRAM, dan suara notifikasi dua nada diputar melalui Web Audio.
- Setelah membuat proyek, ada modal Import Media. Folder yang dipilih menjadi folder export dan tersinkron ke Output Export Folder di Settings; data proyek disimpan dalam subfolder unik. Nama proyek dapat diganti dari menu Media. Default Upload Folder berubah menjadi Default Project Save Folder dan menjadi folder awal pemilihan saat membuat proyek.

## Penyebab dan file terkait

| Masalah | Penyebab | File utama yang diubah |
| --- | --- | --- |
| Sticker reset / transparan | Nilai dipegang hanya pada draft komponen; pencampuran alpha otomatis dapat tidak sesuai | `src/renderer/components/StickerPanel.tsx`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts` |
| Lag / timer / cancel | Render ulang preview dan log berulang; buffer serta penulisan log FFmpeg tidak dibatasi; reset terpisah dari cancel | `src/renderer/App.tsx`, `src/main/services/render/renderOrchestrator.ts`, `src/main/services/ffmpegEngine/ffmpegRunner.ts`, `src/main/ipc/renderHandlers.ts` |
| GPU Mode / informasi selesai | Belum ada deteksi VGA, pemilihan encoder, dan metadata hasil | `src/main/services/render/gpuDetection.ts` (baru), `src/main/services/render/encodingBuilder.ts`, `src/main/services/render/renderCommandBuilder.ts`, `src/main/ipc/settingsHandlers.ts`, `src/main/services/settingsService.ts`, `src/renderer/components/SettingsPanel.tsx`, `src/renderer/App.tsx` |
| Folder proyek / rename | Folder proyek lama dipakai langsung sebagai direktori project.json dan bukan sebagai output | `src/main/ipc/projectHandlers.ts`, `src/main/services/project/projectService.ts`, `src/main/domain/project/projectFactory.ts`, `src/renderer/App.tsx` |

File penghubung yang diubah: `src/shared/domain/{settingsTypes,projectTypes,renderTypes}.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`, `src/renderer/styles/index.css`, `package.json`, `scripts/test-live-monitor.cjs`. Skrip uji baru: `scripts/test-v5o-revisions.cjs`. Tidak ada file yang dihapus; tombol Reset Render hanya dihapus dari antarmuka.

## Verifikasi

`npm run build`, `npm run typecheck`, `npm run test:v5o-revisions`, `npm run test:v5n-bulk`, `npm run test:v5m-revisions`, `npm run test:monitor-pause-cache`, `npm run test:render-startup`, `npm run test:live-monitor-ipc`, dan `npm run test:orchestrator` lulus. Uji V5O mencakup warna pixel sticker PNG alpha 50%, argumen encoder GPU, folder export baru, serta rename. Perangkat GPU fisik dan interaksi jendela Electron Windows tidak tersedia di lingkungan pengujian Linux; uji Detect GPU, suara, dan render GPU pada komputer Windows sebelum dipakai untuk antrean panjang.
