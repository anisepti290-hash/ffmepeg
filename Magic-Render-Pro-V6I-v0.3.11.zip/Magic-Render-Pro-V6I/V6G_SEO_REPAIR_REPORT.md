# Magic Render Pro V6G — 0.3.9

Baseline: Magic-Render-Pro-V6F-v0.3.8.zip.

## Akar masalah

`seoPipeline.ts` menolak seluruh hasil AI ketika satu dari lima judul berisi kurang dari 85 atau lebih dari 95 karakter. `youtubeSeoService.ts` kemudian mengulang seluruh tahap produksi sekali. Jika provider mengulangi kesalahan jumlah karakter, handler `seo:generate` gagal dan `youtubeSEO.txt` tidak dibuat, meskipun deskripsi dan tag sudah benar.

## Perbaikan

- Validasi struktur deskripsi dan tag segera setelah respons utama, tetapi penilaian judul dilakukan terpisah. Jika judul tidak sesuai, hanya lima judul yang diminta ulang dengan informasi panjang karakter yang jelas. Analisis media, deskripsi, dan tag tidak diulang.
- Bila revisi provider gagal atau masih meleset, penyesuaian lokal memakai frasa audiens yang sudah disusun AI dan fakta visual yang diamati. Hasil tetap divalidasi: lima judul unik, 85–95 karakter Unicode, keyword utama, dan emoji pemisah. Tidak memakai klaim tambahan dari luar konteks.
- Respons HTTP gagal pada tahap revisi judul juga dapat kembali ke penyesuaian lokal tanpa membuang deskripsi dan tag yang sudah divalidasi. Kesalahan yang benar-benar tidak dapat diperbaiki tetap diberi pesan yang spesifik.

Berkas inti diubah: `src/main/services/aiService/seoPipeline.ts`, `src/main/services/aiService/youtubeSeoService.ts`. Uji terarah: `scripts/test-v6g-seo-title-repair.cjs` dan skenario provider pada `scripts/test-v6e-seo-framework.cjs`. Versi aplikasi, README, Help, daftar tes, dan `dist/` diperbarui. Tidak ada berkas sumber yang dihapus.

Verifikasi: `npm run build`, `npm run test:v6e-seo`, `npm run test:v6g-seo`, serta regresi SEO dan project V6F lulus. Uji panggilan langsung dengan API key pengguna belum dijalankan di lingkungan ini.
