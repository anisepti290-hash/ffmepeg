# Magic Render Pro V6D · v0.3.6

Baseline: `Magic-Render-Pro-V6C-v0.3.5.zip`.

## Perbaikan

1. **Kesalahan `render:start`:** `renderOrchestrator.ts` sebelumnya menerjemahkan ulang kesalahan FFmpeg dari tahap render. Pesan spesifik berubah menjadi `Render gagal diproses ... tahap render`. Kesalahan kini mempertahankan tahap, kode, penyebab yang diterjemahkan, dan rincian relevan FFmpeg pada Console Log. Stack trace yang diberikan tidak berisi stderr FFmpeg, sehingga penyebab kegagalan *proyek pengguna yang persis sama* belum dapat dipastikan hanya dari stack tersebut.
2. **Sticker timestamp:** mode `screen`, `multiply`, dan `overlay` kini membatasi komposisi pada jendela jadwal, seperti mode normal. Ketika jadwal diubah, Canvas Preview kembali ke tampilan yang mengikuti jadwal; mode edit yang menampilkan sticker di luar jadwal tidak tertinggal.
3. **Dua jalur otomatis Bulk Render:** komposisi visual yang aman diulang (media utama gambar atau video pendek dan overlay gambar statis, tanpa intro, sticker, fade, teks, visualizer, atau efek waktu) dikode satu unit singkat, lalu video dan playlist digabung sampai durasi target melalui stream copy. Komposisi lain tetap memakai satu encoding sepanjang durasi final. Jika jalur cepat gagal, proses otomatis mencoba ulang jalur normal. Pengaturan bitrate, FPS, resolusi, preset, CPU/GPU, dan output tetap berasal dari proyek Bulk.

## Berkas terkait

Diubah: `src/main/services/render/renderOrchestrator.ts`, `src/main/services/ffmpegEngine/errorTranslator.ts`, `src/main/services/ffmpegEngine/filterGraphBuilder/blendFilterBuilder.ts`, `src/main/services/ffmpegEngine/stickerFilterBuilder.ts`, `src/renderer/components/StickerPanel.tsx`, `src/renderer/components/CanvasPreview.tsx`, `src/renderer/components/HelpPage.tsx`, `package.json`, `package-lock.json`.

Ditambahkan: `src/main/services/render/bulkFastPath.ts`, `scripts/test-v6d-bulk-fast-sticker.cjs`, laporan ini. Tidak ada berkas sumber yang dihapus.

## Verifikasi

`npm run build`, `npm run typecheck`, `npm run test:v6d-bulk`, `npm run test:v5n-bulk`, `npm run test:orchestrator`, dan `node scripts/test-v5i-blend-sticker-timing.cjs` lulus pada FFmpeg Linux. Tes memeriksa video, audio, durasi, overlay statis sebelum dan setelah unit diulang, media video pendek, sticker tidak muncul sebelum timestamp, serta pesan kegagalan encoder yang tetap spesifik. Installer Windows belum dapat dibangun atau diuji di lingkungan Linux; jalankan `npm run dist` pada Windows x64 setelah mengekstrak ZIP dan memasang dependensi.
