# V6I — SEO dan Smooth Loop Overlay (v0.3.11)

Baseline: V6H v0.3.10. Arsip menyertakan source dan `dist` terbaru.

## Perubahan SEO

- Sepuluh judul sekarang diterima pada 80–99 karakter Unicode; judul 81/84 karakter tidak lagi memicu kegagalan perbaikan 85–95. Title Case diterapkan sebelum validasi akhir. Prompt, pembetulan judul, parser, dan Help mengikuti batas yang sama.
- Model memilih `bestTitleIndex` berdasarkan emotional hook, relevansi, dan search intent. Penulis `youtubeSEO.txt` menempatkan judul pilihan (tanpa emoji) dan penjabaran dari AI di paragraf pertama.
- Instruksi produksi mengembangkan empat paragraf yang halus, menjabarkan 4–8 kebutuhan konkret dalam Perfect For, dan merangkai tag relevan ke penutup sebelum hashtag. Hashtag tetap muncul sekali di akhir deskripsi; playlist dan tag dipertahankan.
- `resources/seo/promptimageSEO.md` diselaraskan. Analisis visual tetap membedakan fakta teramati dari interpretasi motif penonton.

## Smooth loop overlay

- Editor preset Asset Library menampilkan **Buat Smooth Loop** dengan keadaan memproses, **Duplikat Smooth Loop · Periksa 2 putaran**, dan **Hapus duplikat**.
- Sumber video diproses satu kali: bagian 70% akhir menjadi timeline pertama; 30% awal masuk timeline kedua. `xfade` menurunkan opacity timeline pertama sembari menaikkan timeline kedua selama bagian overlap, sehingga akhir klip bertemu dengan awal klip berikutnya pada frame sumber yang bersebelahan.
- Hasil menjadi video MP4 terpisah di Asset Library dengan pengaturan visual tersalin tanpa trim. Video asli tidak ditimpa. Memilih asset hasil pada menu Overlay atau Bulk Render menggunakan jalur render yang sudah ada dan tidak membuat ulang transisi tiap render.
- Format input yang memiliki kanal alpha ditolak dengan pesan jelas karena encoding MP4 H.264 akan menghilangkan transparansi. Overlay berwarna/chroma key tetap dapat diproses. Tombol hapus melepas duplikat dari Library sesuai perilaku penghapusan asset yang sudah ada; berkas disimpan agar project yang terlanjur memakainya tidak rusak.

Berkas utama: `src/main/services/aiService/seoPipeline.ts`, `youtubeSeoService.ts`, `seoFileWriter.ts`, `src/main/services/overlay/smoothLoopService.ts`, `src/main/ipc/lockedAssetHandlers.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`, `src/renderer/components/AssetVisualEditor.tsx`, `HelpPage.tsx`, `resources/seo/promptimageSEO.md`, dan pengujian terkait. Tidak ada berkas fungsional yang dihapus.

Verifikasi: `npm test` termasuk render FFmpeg dan uji klip turunan lulus. API AI langsung dan antarmuka Electron Windows tidak diuji tanpa kunci API serta lingkungan Windows.
