# Magic Render Pro V5L — AI gratis & kerangka SEO visual

## Ringkas penggunaan

ChatGPT Plus dan API OpenAI ditagih terpisah. API key baru tidak otomatis mendapat kredit gratis. Untuk mencoba tanpa tagihan OpenAI, buka **Settings → AI Configuration**, pilih salah satu:

| Provider | Model awal | Persiapan | Catatan |
| --- | --- | --- | --- |
| Gemini | `gemini-2.5-flash-lite` | API key Google AI Studio | Free tier tersedia sesuai kuota/region/akun. Model 2.5 Flash juga ada di filter. |
| Groq | `qwen/qwen3.8-27b` | API key GroqCloud | Free plan dan kuota berlaku; daftar model aktual diambil dari API. |
| OpenRouter | `openrouter/free` | API key OpenRouter | Router memilih model gratis yang sesuai input gambar; dapat pula memilih model `:free` vision yang tercantum. |
| Ollama lokal | `gemma3:4b` | Instal Ollama, `ollama pull gemma3:4b`, jalankan server lokal | Tidak perlu API key ataupun biaya panggilan cloud; perlu RAM/CPU/GPU lokal. |
| OpenAI/Mistral | Model sesuai akun | API key dan billing provider | Tetap tersedia sebagai pilihan berbayar. |

Klik **Muat Model**, pilih model yang mendukung gambar, lalu **Simpan & Validasi**. Filter gratis menyaring daftar kandidat; ID manual dapat dikenai biaya dan free tier masih bergantung pada aturan provider. Setelah video dirender, buka **YouTube SEO**, pilih **Opsi 2**, isi keyword dan konteks, pilih video final, lalu **Generate YouTube SEO**. Opsi 1 tetap membuat timestamp tanpa API.

## Penerapan 26 poin kerangka pengguna

| Poin | Penerapan pada V5L |
| --- | --- |
| 1. Visual understanding | Prompt mengamati subjek, jumlah, atribut, objek, interaksi, komposisi, warna, gaya, teks yang jelas pada tiga frame video final. Pembacaan teks memakai model vision, belum OCR khusus. |
| 2. Semantic understanding | Mood, tema, narasi hanya ditulis sebagai interpretasi; fakta diamati terpisah. |
| 3. Relationship analysis | Relasi objek/aksi diminta, tanpa menyatakan hubungan atau peristiwa yang belum terbukti. |
| 4. Scene & context | Lingkungan, latar, kondisi visual, cahaya, dan cuaca bila tampak. |
| 5. Emotion & tone | Ekspresi subjek dibedakan dari suasana yang ditafsirkan. |
| 6. Visual style | Gaya foto/ilustrasi, kamera, komposisi, dan palet diminta. |
| 7. Subject classification | Subjek primer dan sekunder diarahkan oleh gambar dan topik pengguna. |
| 8. Keyword extraction | Klaster primer 1–8, sekunder 0–12, long tail 0–6 supaya tidak memaksa puluhan keyword tidak relevan. |
| 9. Search intent | Kolom intent dan strategi judul. |
| 10. Target audience | Kolom audiens serta tujuan menonton. |
| 11. Channel context | Nama dan niche channel. |
| 12. Video context | Topik, ringkasan isi video, koreksi visual, teks thumbnail. |
| 13. Music/audio analysis | Genre, mood, instrumen/vokal/tempo dan keterangan lirik berasal dari masukan pengguna; gambar tidak dijadikan bukti audio. |
| 14. SEO input | Main keyword, keyword sekunder, bahasa/negara target, pengecualian, dan strategi. |
| 15. Trend data | Kolom catatan tren pengguna; tidak mengklaim pencarian tren langsung. |
| 16. Competitor analysis | Kolom catatan kompetitor pengguna; tidak mengklaim scraping/pengukuran performa langsung. |
| 17. Title generator | Lima variasi judul, masing-masing maksimal 95 karakter. |
| 18. Title quality | Alasan singkat tiap judul, tanpa skor SEO yang dibuat-buat. |
| 19. Description generator | Tiga versi deskripsi: SEO-rich, engagement, premium; tanpa klaim/tautan/timestamp palsu. |
| 20. Tag generator | Maksimal 15 tag relevan, total di bawah 500 karakter. |
| 21. Hashtag generator | 3–5 hashtag relevan diminta dan 3–7 diterima untuk toleransi respons model. |
| 22. Negative/uncertain detection | Hal yang belum pasti ditandai untuk tinjauan dan tidak dimasukkan ke metadata terbit. |
| 23. Confidence system | Kategori observed/interpreted/uncertain; tidak memberikan persentase confidence palsu tanpa kalibrasi. |
| 24. Fact vs interpretation | Dipisah dalam hasil UI dan file `youtubeseo.txt`. |
| 25. User override | Pengguna menentukan topik, koreksi visual, konteks audio, dan kata yang dilarang; hasil tetap draf untuk diedit sebelum dipublikasikan. |
| 26. Core data pipeline | Frame video final + konteks → prompt visual/semantik → keyword → judul/deskripsi/tag/hashtag, lalu validasi dan berkas keluaran. |

Semua kolom konteks opsional secara teknis untuk menjaga kompatibilitas proyek lama. **Topik video dan ringkasan isi paling disarankan**; isi juga audio sebenarnya jika video musik. Tiga sampel frame tidak mencakup keseluruhan video, dan model dapat salah membaca teks kecil. Konfirmasi draf sebelum upload.

## Kinerja dan biaya

- Sampel frame video dikecilkan sampai batas 1280×720 dan dikirim sebagai JPEG agar permintaan lebih kecil. Gambar tunggal yang menjadi main media tetap dibaca sebagaimana adanya.
- Generator tidak memanggil validasi berbiaya lagi tepat sebelum generasi. Pemeriksaan ringan melalui daftar model atau endpoint model; **Simpan & Validasi** / **Check API Key** secara eksplisit menguji satu permintaan multimodal.
- Kegagalan respons format dan kuota tidak dicoba ulang berkali-kali. Hanya HTTP 5xx sementara yang dicoba ulang sampai tiga kali.
- Pilihan lokal menghemat tagihan API tetapi kecepatannya mengikuti mesin pengguna. Free plan cloud bisa mencapai 429 saat kuota atau rate limit habis.

## Berkas terkait yang diubah

`src/shared/domain/aiTypes.ts`, `src/shared/domain/projectTypes.ts`, `src/shared/ipc.ts`, `src/preload/index.ts`, `src/main/domain/project/projectFactory.ts`, `src/main/services/project/projectValidator.ts`, `src/main/services/settingsService.ts`, `src/main/services/aiService/aiProviderClient.ts`, `src/main/services/aiService/promptBuilder.ts`, `src/main/services/aiService/aiResponseValidator.ts`, `src/main/services/aiService/keyframeExtractor.ts`, `src/main/services/aiService/youtubeSeoService.ts`, `src/main/services/aiService/seoFileWriter.ts`, `src/main/ipc/settingsHandlers.ts`, `src/main/ipc/seoHandlers.ts`, `src/renderer/components/SettingsPanel.tsx`, `src/renderer/components/YoutubeSeoPanel.tsx`, `package.json`, `scripts/verify-phase18.mjs`, `scripts/test-ai-response.cjs`. Berkas baru: `src/main/services/aiService/seoContext.ts`, `scripts/test-v5l-free-seo.cjs`, laporan ini. Tidak ada berkas yang dihapus. `docs/AI_Visual_SEO_Analysis_Framework.md` tetap sebagai rujukan asli.

## Verifikasi

- `npm run typecheck`, `npm run build`, `npm run test:v5l-free-seo`, `npm run test:ai-response`, `npm run verify:phase18`, dan uji V5K 429 lulus.
- FFmpeg berhasil mengekstrak frame JPEG dari video contoh lokal.
- Suite `npm test` masih berhenti pada pemeriksaan statis fase 10 yang mencari token `aspect-video` dalam komponen preview lama; pemeriksaan lama lain juga mengasumsikan struktur kode terdahulu. Sebanyak 9 dari 35 pemeriksaan sisanya gagal pada aturan lama yang tidak terkait penambahan AI/SEO ini. Pengujian akun provider dan perilaku pada Windows perlu dilakukan dengan API key/instalasi pengguna.

Dokumentasi provider dapat berubah. Rujukan: OpenAI Help (billing API terpisah), Google Gemini API pricing, Groq Models/Vision dan rate limits, OpenRouter Free Models Router, Ollama Gemma 3 model library.
