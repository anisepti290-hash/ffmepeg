# Magic Render Pro 0.2.5 — Revisi V5U

Baseline: V5T. ZIP ini berisi sumber, build `dist`, skrip pengujian, dan panduan.

## Penyebab dan perbaikan

| Masalah | Penyebab | Berkas yang diperbaiki |
| --- | --- | --- |
| Lingkar bokeh berulang dan tidak mengikuti adegan | Preview dan FFmpeg membaca satu gambar `bokeh-fade.png` yang sama | `src/main/services/render/renderCommandBuilder.ts`, `src/renderer/components/CanvasPreview.tsx`, `src/renderer/styles/index.css`. Sorotan terang kini dihitung dari setiap frame media utama dan memudar menjadi gambar tajam. Tekstur lama dihapus dari `resources` serta pengemasan `package.json`. |
| Bulk tidak dapat memilih bokeh | Opsi fade hanya berisi durasi | `src/shared/domain/bulkTypes.ts`, `src/main/services/bulk/bulkPlanner.ts`, `src/renderer/components/BulkRenderPage.tsx`, `src/renderer/App.tsx`. Fade bokeh, defokus, dan kecerahan tersedia saat klip intro dimatikan. |
| Radio sumber analisis tidak sejajar | Aturan CSS umum menjadikan semua label/input SEO bertumpuk | `src/renderer/components/YoutubeSeoPanel.tsx`, `src/renderer/styles/index.css`. Layout sumber visual ditetapkan sebagai dua baris dengan dot radio dan teks sejajar. |
| Status render selesai tanpa aksi | Monitor dan hasil bulk hanya menampilkan status | `src/renderer/App.tsx`, `src/renderer/components/BulkRenderPage.tsx`. Buka Folder, Buka Video, dan Reset tersedia di status selesai; Reset membersihkan tugas/log di layar tanpa menghapus MP4. |
| Format SEO sebelumnya | Prompt dan pembuat file memakai pola judul lama serta satu audiens | `src/main/services/aiService/seoPipeline.ts`, `seoFileWriter.ts`, `src/shared/domain/aiTypes.ts`. Judul mengikuti tiga pola baru, Playlist 🎧 dan timestamp ditempatkan sebelum 4–6 butir tujuan pendengar, sementara tags tetap sama. |

Panduan Help diperbarui ke 0.2.5. Pengujian yang diperbarui ada pada `scripts/test-v5s-seo-bokeh.cjs`, `test-v5t-seo-format.cjs`, `test-v5s-seo-service.cjs`, `test-v5n-bulk.cjs`; `test-v5u-scene-bokeh.cjs` ditambahkan.

## Verifikasi dan batas

- `npm run build`, pengujian FFmpeg bokeh dengan dua lokasi lampu, Bulk Render 2 gambar dan 1 video, penulisan SEO, dan IPC lulus.
- Preview menggunakan filter CSS yang mendekati ambang sorotan FFmpeg. Keduanya mengikuti isi dan gerak media utama, tetapi kesamaan piksel mutlak pada setiap perangkat tidak dijanjikan. Jika tidak ada titik yang cukup terang, bokeh menjadi defokus lembut tanpa mengarang lampu.
- Respons AI diuji menggunakan data tiruan. Generasi dengan akun/model pengguna tetap harus diperiksa pada perangkat pengguna.
