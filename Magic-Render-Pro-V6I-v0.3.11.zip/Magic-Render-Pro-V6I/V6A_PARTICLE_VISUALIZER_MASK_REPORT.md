# Magic Render Pro v0.3.3 — Partikel, Visualizer, dan Mask Overlay

Baseline: Magic-Render-Pro-V5Z-v0.3.2.zip.

## Perbaikan

- **Partikel:** 8 gaya tambahan (25 total), ukuran dan warna khusus. Koordinat memakai hash stabil dari ID efek dan indeks partikel, tersebar pada seluruh frame. Jarak menjadi amplitudo gerak yang dibatasi oleh tepi; 40 titik tidak keluar frame saat jarak maksimum. Preview dan FFmpeg berbagi glyph, palet, ukuran, serta posisi dasar. Waktu preview dikurangi durasi intro agar gerakan sejajar dengan bagian konten pada video hasil.
- **Visualizer:** 5 gaya tambahan (17 total), kontrol kepadatan dan glow. Keluarga spectrum memakai batang frekuensi dengan palet pada piksel berisi sinyal; latar hitam dibuat transparan sebelum digabung. Preview memakai batang dan palet serupa. Semua gaya diuji sebagai filter FFmpeg dan pada contoh MP4 gabungan.
- **Editor aset overlay:** durasi sumber dan durasi setelah trim ditampilkan. Mask persegi panjang, persegi, lingkaran, oval, serta pola gambar bebas (3–32 titik) tersimpan dalam preset. Kontrol posisi dan ukuran mask, pegangan resize dan rotate langsung di canvas. Mask diterapkan sesudah keying dan sebelum rotasi pada FFmpeg agar warna transparan dan bentuk mask mengikuti pengaturan di preview. Rotasi FFmpeg memakai kanvas yang diperluas sehingga sudut layer tidak terpotong.
- Panduan Help dan nomor versi diperbarui.

## Sumber kesalahan dan file terkait

| Masalah | Akar masalah | File utama |
| --- | --- | --- |
| Partikel berbaris/keluar frame | Posisi lama mengikuti sudut emas dan radius dari pusat tanpa pembatas tepi | `src/shared/domain/effectPreview.ts`, `src/main/services/effects/effectFilterBuilder.ts`, `src/shared/domain/particleGeometry.ts` |
| Visualizer menjadi blok warna | `showspectrum` menghasilkan heatmap berbentuk bidang, sementara preview menggambar bentuk berbeda | `src/main/services/effects/visualizerBuilder.ts`, `src/renderer/components/VisualizerPreview.tsx` |
| Crop terbatas tepi dan tidak ada durasi trim | Config overlay hanya menyimpan empat persentase crop dan trim tanpa kontrol bentuk | `src/renderer/components/AssetVisualEditor.tsx`, `src/shared/domain/overlayTypes.ts`, `src/shared/domain/overlayMask.ts`, `src/main/services/ffmpegEngine/filterGraphBuilder/filterGraphBuilder.ts` |

File lain yang diubah: validator efek, visualizer, dan overlay; `EffectsPanels.tsx`; `CanvasPreview.tsx`; `OverlayCrop.tsx`; `assetPreset.ts`; `index.css`; `HelpPage.tsx`; `package.json` dan `package-lock.json`. Ditambah `scripts/test-v6a-particles-visualizers-mask.cjs`. Tidak ada file sumber yang dihapus.

## Verifikasi

- `npm run build` — lulus.
- `node scripts/test-v6a-particles-visualizers-mask.cjs` — 40 partikel, semua arah, lima mask dengan pemeriksaan piksel transparan, 17 grafik FFmpeg, dan MP4 dengan mask + partikel + spectrum — lulus.
- `npm run test:v5z-assets-render` dan `npm run test:v5x-upgrades` — lulus.

Paket ini berisi kode sumber dan hasil build Electron, bukan installer Windows. Pemeriksaan klik dan gerak pada perangkat Windows tetap perlu dilakukan setelah aplikasi dijalankan di sana; pengujian di lingkungan ini mencakup filter FFmpeg, berkas MP4 contoh, validasi, serta build renderer.
