# Magic Render Pro v5 — perbaikan editor

Baseline: `Magic-Render-Pro-v5.zip`. Paket ini berisi source code; jalankan `npm ci` lalu `npm run build` pada sistem yang memenuhi dependensi Electron dan FFmpeg.

## Perbaikan

1. Tinggi aplikasi mengikuti viewport dan halaman render dapat digulir; Render Monitor dan bagian bawah panel tetap dapat dijangkau.
2. Canvas memakai ruang koordinat 1920×1080 yang diskalakan ke lebar panel. Overlay dan sticker ditampilkan sesuai posisi yang tersimpan, termasuk sticker default saat berhenti di awal preview. Preview chroma/color key memakai canvas pixel processing; ekspor tetap memakai filter FFmpeg.
3. Tombol mata pada overlay dan sticker hanya menyembunyikan/menampilkan layer di preview; hasil render tidak berubah.
4. Saat Intro aktif, kontrol fallback pada menu Intro dinonaktifkan; Fade-In Media Utama tetap dapat diatur secara mandiri. Fallback dipakai saat Intro dimatikan dan Fade-In Media Utama bernilai 0. Refresh Intro membaca asset terkunci terbaru; pemilihan intro tetap tersedia setelah mengubah fade. Intro gambar berdurasi 3 detik juga dapat disusun dalam render.
5. Posisi X/Y dan rotasi media utama menjadi slider dengan nol di tengah, disertai zoom 25–300% dan tombol Ubah Media. Filter FFmpeg mendukung posisi negatif serta zoom melebihi ukuran canvas.
6. Output parser FFmpeg menjaga baris progres lintas potongan stream. Monitor menerima event serta snapshot status setiap detik dan menampilkan persen, estimasi durasi video, waktu render, speed, dan perkiraan sisa waktu. Console mengambil riwayat saat dibuka dan menampilkan error render. Progres single-pass dimulai dari 0%, dan kegagalan IPC ditampilkan sebagai status error.

## File yang berubah

- UI: `src/renderer/App.tsx`, `src/renderer/styles/index.css`, `src/renderer/components/CanvasPreview.tsx`, `IntroPanel.tsx`, `StickerPanel.tsx`.
- Proses utama: `src/main/index.ts`, `src/main/services/ffmpegEngine/commandBuilder.ts`, `ffmpegRunner.ts`, `src/main/services/intro/introService.ts`, `src/main/services/media/mediaService.ts`, `src/main/services/render/renderCommandBuilder.ts`, `renderOrchestrator.ts`.
- Baru: `src/renderer/components/KeyedMedia.tsx`, `PreviewEyeIcon.tsx`, `scripts/test-v5-repairs.cjs`, `package-lock.json`.
- Tes disesuaikan: `scripts/test-render-orchestrator.cjs` (durasi target mencakup intro). Tidak ada file baseline yang dihapus.

## Verifikasi

- `npm run build`: lulus.
- `node scripts/test-v5-repairs.cjs`: lulus dengan FFmpeg untuk posisi negatif, zoom, dan transparansi chroma overlay.
- `npm run test:render-engine` dan `npm run test:orchestrator`: lulus, termasuk durasi intro dan metrik progres.
- Suite `npm test` penuh tertahan pada `verify-phase10.mjs` yang memeriksa token UI lama `aspect-video`, yang memang tidak ada dalam baseline v5. Pemeriksaan ini bukan kegagalan build atau render. Belum ada uji interaksi manual pada Windows/Electron dalam lingkungan ini.
