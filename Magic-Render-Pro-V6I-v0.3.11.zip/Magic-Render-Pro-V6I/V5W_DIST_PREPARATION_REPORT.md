# Magic Render Pro V5W — persiapan `npm run dist` (versi 0.2.8)

Baseline: `Magic-Render-Pro-V5W-Playlist-Sticker-SEO-Help.zip`.

## Temuan dan perbaikan

1. ZIP awal tidak berisi `ffmpeg.exe` dan `ffprobe.exe`, tetapi installer akan
   dibuat meski tanpa keduanya. `npm run dist` sekarang menjalankan preflight,
   mengambil binary Windows x64 dari dependensi build setelah `npm ci`, lalu
   memeriksa kedua versi, encoder `libx264` dan `aac`, serta filter `overlay`,
   `chromakey`, `drawtext`, dan `scale`. Bila tidak tersedia, build berhenti
   dengan pesan jelas sebelum membuat installer yang tidak bisa merender.
2. `electron-builder` semula menggunakan direktori keluaran bawaan `dist`,
   yang juga dipakai output kompilasi. Installer sekarang masuk `release/`.
3. Pengaturan lama bisa menyimpan path FFmpeg di drive lain yang tidak ada pada
   PC baru. Saat path tersimpan hilang, aplikasi memilih binary yang sudah
   dibundel. Path kustom yang masih ada tetap digunakan.
4. Aplikasi terpaket selalu memakai halaman produksi dari `dist/renderer`,
   walaupun variabel lingkungan pengembang masih tersetel. Dalam mode pengembang,
   FFmpeg hanya memakai path eksternal bawaan jika berkas itu benar-benar ada.
5. Menutup jendela saat render dapat menunggu tanpa batas. Pembatalan kini
   menghentikan pohon proses FFmpeg di Windows; penutupan dibatasi delapan detik,
   dan folder kerja yang masih aktif tidak dihapus. Pembersihan cache startup
   berjalan setelah jendela dibuat agar UI tidak tertahan oleh file lama.
6. `npm test` sebelumnya berhenti pada sejumlah verifikasi fase lama yang
   mengasumsikan struktur file dan label UI sebelum V5W. Suite utama sekarang
   memakai pemeriksaan V5W dan render terbaru. Skrip lama tetap tersedia lewat
   `npm run test:legacy` dan belum sepenuhnya dimigrasikan.

## Verifikasi di lingkungan ini

- `npm run build`: lulus.
- `npm test`: lulus; mencakup playlist, render FFmpeg sungguhan, progress,
  pause/cancel, cache, IPC, chroma/sticker, provider AI, timestamp, dan SEO.
- `npm ci --ignore-scripts` pada folder bersih: lulus, 498 paket. Opsi
  `--ignore-scripts` berarti pengunduhan binary native belum diuji di sini.
- `npm audit --omit=dev`: tidak melaporkan kerentanan produksi pada saat audit.
- `npm run dist` pada Linux ini sengaja berhenti di preflight karena binary
  Windows belum tersedia. Build installer serta uji GUI pada Windows x64 tetap
  harus dijalankan pada mesin Windows.

## Kompatibilitas dan langkah pada Windows

1. Ekstrak ZIP pada Windows x64 dan buka terminal di `mrp_buildfix_work`.
2. Pasang Node.js 22+ **di mesin pembuat installer**, lalu jalankan `npm ci`.
   Instalasi mengambil Electron, FFmpeg, dan FFprobe dari sumber dependensi;
   akses jaringan dibutuhkan saat pertama kali.
3. Jalankan `npm test`, kemudian `npm run dist`.
4. Ambil `release/Magic-Render-Pro-0.2.8-Setup.exe`. Komputer tujuan cukup
   menjalankan installer tersebut; tidak memerlukan Node.js, Python, FFmpeg,
   atau Electron terpisah. FFmpeg berada di folder `resources/ffmpeg` instalasi.

Jika unduhan FFmpeg saat `npm ci` gagal, simpan binary Windows x64 yang lengkap
secara manual di `resources/ffmpeg/` dan ulangi `npm run dist`. Catat asal dan
lisensi binary sebelum menyebarkan installer. Target build saat ini hanya
Windows x64. Pemakaian API AI masih memerlukan jaringan, akun, dan kredensial;
Ollama lokal memerlukan instalasi Ollama dan modelnya.

## Batas pemeriksaan

Belum dilakukan uji installer `.exe` di Windows bersih tanpa runtime terpasang,
uji GPU/driver pada setiap perangkat, atau uji AI live memakai kredensial.
Pemeriksaan tersebut memerlukan Windows dan akun/asset tujuan. Tidak ada klaim
bahwa semua kemungkinan freeze atau bug telah tersingkir.

## Berkas diubah/ditambah

- `package.json`, `package-lock.json`, `README.md`.
- `scripts/preflight-dist.cjs`, `scripts/run-current-tests.cjs` (baru).
- `scripts/verify-uiux-redesign.mjs`, `scripts/verify-blank-screen-fix.mjs`.
- `src/main/config/environment.ts`, `src/main/index.ts`.
- `src/main/services/settingsService.ts`.
- `src/main/services/render/renderOrchestrator.ts`.
- `resources/ffmpeg/README.md`.
- `dist/` dibangun ulang dari source. Tidak ada script aplikasi yang dihapus.
