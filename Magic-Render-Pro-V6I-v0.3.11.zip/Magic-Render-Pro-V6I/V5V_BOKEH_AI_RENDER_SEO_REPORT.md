# Magic Render Pro V5V — perbaikan bokeh dan AI SEO

Baseline: V5U. Versi aplikasi: 0.2.6.

## Akar masalah

1. Fade bokeh mencampur kanal YUV dengan mode `screen`; kanal krominans neutral ikut berubah sehingga warna cahaya dapat menjadi merah muda/ungu. Kini cahaya dicampur pada kanal RGB lalu dikonversi kembali untuk encoding.
2. Klien AI mengasumsikan semua balasan sukses HTTP memiliki `choices[0].message.content` berupa string. Respons vision dapat berupa bagian teks, `content` kosong ketika anggaran token habis, penolakan, atau error dari router di dalam HTTP 200. Validasi lama juga menerima respons kosong. Parser, validasi multimodal, diagnostik, dan retry terbatas sudah diperbaiki untuk OpenRouter, OpenAI, Gemini, Groq, Mistral, dan Ollama.
3. Render handler tidak menggerakkan SEO otomatis, sehingga Opsi 2 tidak menghasilkan SEO dari tombol Render. Kini renderer memulai AI sejajar dengan FFmpeg, menampilkan status satu baris pada panel SEO dan tetap mengizinkan panel tersebut dibuka ketika render berlangsung. Timestamp final dari MP4 dipertahankan bila AI selesai lebih lambat.
4. Label checkbox memakai aturan form Setting yang meregangkan input. Layout khusus mengunci lebar checkbox dan menyelaraskannya dengan teks.
5. Peringatan `GoogleDriveFSPipe_Desktop_shell` adalah keluaran ekstensi shell Windows Google Drive for desktop, bukan pesan FFmpeg/SEO. Launcher `npm run dev` dan `npm start` kini memfilter tepat baris peringatan tersebut dan jejak langsungnya, sedangkan error lain tetap dicetak. Integrasi Google Drive pada Windows tidak dapat diuji di Linux.

## Berkas diubah

- `src/main/services/render/renderCommandBuilder.ts` — pencampuran cahaya intro bokeh di RGB.
- `src/main/services/aiService/aiProviderClient.ts` — format multimodal, output provider, diagnostik, validasi vision, batas waktu.
- `src/main/services/aiService/youtubeSeoService.ts` — retry terukur, pelestarian timestamp final.
- `src/main/ipc/renderHandlers.ts` — timestamp final setelah render tanpa generasi AI ganda.
- `src/renderer/App.tsx` dan `src/renderer/components/YoutubeSeoPanel.tsx` — SEO otomatis, status, hasil selama render, tab SEO tetap terbuka.
- `src/renderer/components/SettingsPanel.tsx` dan `src/renderer/styles/index.css` — perataan checkbox filter model.
- `scripts/launch-electron.cjs`, `package.json`, `package-lock.json` — launcher dan versi 0.2.6.
- `src/main/ipc/appHandlers.ts` — panduan dan pemecahan masalah.
- `scripts/test-v5s-seo-bokeh.cjs`, `scripts/test-v5h-settings-seo.cjs`, `scripts/test-v5v-ai-providers.cjs` — uji regresi dan mock enam provider.

Tidak ada berkas yang dihapus. `dist` dibangun ulang dari source.

## Verifikasi

- `npm run build` — lulus.
- `node scripts/test-v5s-seo-bokeh.cjs` dan `node scripts/test-v5u-scene-bokeh.cjs` — render bokeh FFmpeg lulus.
- `node scripts/test-v5v-ai-providers.cjs` — enam provider dalam simulasi HTTP, output kosong, dan filter peringatan lulus.
- `node scripts/test-v5h-settings-seo.cjs`, `node scripts/test-v5l-free-seo.cjs`, `node scripts/test-ai-response.cjs` — lulus.
- `node scripts/test-render-orchestrator.cjs` — render pendek end-to-end lulus.

Kunci API pengguna, layanan nyata, tampilan Electron Windows, serta Google Drive Windows tidak tersedia di lingkungan uji. Untuk validasi akhir, jalankan V5V di Windows, pilih model vision yang tersedia bagi akun, lalu coba Opsi 2. Bila provider mengembalikan batas token atau penolakan, status SEO sekarang menunjukkan penyebab spesifik. Warna bokeh perlu juga diperiksa pada media pengguna yang sebelumnya menjadi merah muda.
