# Magic Render Pro V6E · v0.3.7

Baseline: V6D v0.3.6. Sumber prompt: `resources/seo/promptimageSEO.md`, salinan dari lampiran pengguna. Installer Windows menyertakannya sebagai `resources/seo/promptimageSEO.md`.

## Perubahan

- Opsi 2 YouTube SEO menerima sumber visual (main content / upload), jenis konten, beberapa keyword dipisahkan koma, negara/bahasa target, lima checkbox tujuan optimasi (semuanya aktif secara default), dan satu dari lima gaya judul (SEO Friendly sebagai default). Jenis konten dan negara lain dapat diketik.
- Template lokal menyimpan semua pilihan dan dapat digunakan lintas proyek. Template lama berupa keyword + niche masih dapat dibaca.
- Dua tahap AI membaca bagian relevan prompt `.md`: analisis visual dan keyword, lalu penulisan metadata, validasi, dan pemilihan judul terbaik. Bagian format A–G pada lampiran digantikan oleh format file yang secara eksplisit diminta pengguna. Permintaan AI memakai JSON tervalidasi; aplikasi menyusun teks siap salin dan timestamp dari playlist nyata.
- Output `youtubeSEO.txt`: `youtube seo untuk [nama project]`, `#judul` (lima judul dengan emoji), `#deskripsi` (hook, isi, playlist bila ada, perfect for, ajakan, hashtags), `#tag` (maksimal 500 karakter), dan `# kombinasi terbaik` (judul, deskripsi, tags, hashtags).
- Cache analisis mempertimbangkan media, keyword, jenis konten, negara/bahasa, dan isi prompt. Perubahan gaya judul atau tujuan optimasi hanya mengulang tahap penulisan metadata. Tag yang dipilih AI digabung dengan keyword pengguna dan kandidat yang terkait media, kemudian dibatasi.
- Validasi Render dan IPC SEO tidak lagi mensyaratkan Niche/Genre; keyword utama wajib ada.

## Berkas

Diubah: `src/renderer/components/YoutubeSeoPanel.tsx`, `src/renderer/styles/index.css`, `src/renderer/components/HelpPage.tsx`, `src/shared/domain/aiTypes.ts`, `src/main/services/aiService/{seoPipeline,youtubeSeoService,seoContext,seoTags,seoFileWriter,seoAnalysisCache}.ts`, `src/main/ipc/{seoHandlers,renderHandlers}.ts`, `package.json`, `package-lock.json`, serta tes SEO terkait. Ditambah: `resources/seo/promptimageSEO.md`, `src/main/services/aiService/seoPromptFramework.ts`, `scripts/test-v6e-seo-framework.cjs`, laporan ini. Tidak ada berkas dihapus.

## Verifikasi

`npm run typecheck`, `npm run build`, `npm run test:v6e-seo`, `node scripts/test-v5s-seo-service.cjs`, `node scripts/test-v5s-seo-bokeh.cjs`, `node scripts/test-v5t-seo-format.cjs`, `node scripts/test-v5h-seo-integration.cjs`, dan `node scripts/test-v5w-playlist-sticker-seo.cjs` lulus. Tes provider memakai respons tiruan; keandalan model/API langsung masih bergantung pada model vision, kuota, dan jaringan pengguna. Installer Windows tidak dibangun dari lingkungan Linux ini; `npm run dist` dijalankan pada Windows x64.
