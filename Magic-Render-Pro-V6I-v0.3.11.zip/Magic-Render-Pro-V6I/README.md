> Versi sumber: 0.3.11 (V6I). Rincian revisi: [V6I_SEO_SMOOTH_LOOP_REPORT.md](V6I_SEO_SMOOTH_LOOP_REPORT.md).

# Magic Render Pro

## Versi 0.3.2 — panel tetap, preset trim/crop, visualizer, Bulk Render

- Canvas Preview, Render Monitor, dan Console Log tetap tampak di panel kanan
  saat kontrol di kiri digulir pada layar desktop. Panel kanan dapat digulir
  sendiri jika tinggi kontennya melebihi jendela.
- Visualizer menampilkan contoh saat belum diputar, lalu membaca audio melalui
  koneksi Web Audio yang mengikuti elemen MP3 terbaru. Skala frekuensi Linear
  diterjemahkan ke opsi `lin` milik FFmpeg agar render tidak gagal.
- Preset overlay pada Asset Library dapat mengatur crop empat sisi dan trim
  titik awal/akhir video sumber. Hasil disimpan dalam preset, tampil pada
  preview, dan dipakai oleh filter render tanpa encoding klip perantara.
- Canvas editor aset bisa difokuskan untuk panah, Shift+panah, +/-, R, Spasi,
  Home, dan Ctrl+S. Slider tetap menerima panah sesuai kontrolnya.
- Bulk Render mengelompokkan lapisan dan transisi. Durasi sekali tampil
  sticker mengikuti panjang video/GIF terpilih secara otomatis; gambar 3 detik.
  Opsi durasi manual tetap tersedia.
- Help menampilkan About, System Information dan kontak bantuan. Detail galat
  FFmpeg yang relevan kini muncul pada pesan `INVALID_FILTER`.

Render saat ini sudah memakai playlist untuk durasi konten, `-stream_loop -1`
untuk sumber video, lalu satu encode video final. Playlist disatukan dalam
tahap audio sebelumnya (AAC), sehingga istilah *satu encode* berlaku bagi
video, bukan seluruh proses audio. Filter visual mencegah `-c:v copy` pada
video final. Alur ini tidak diubah atas pertanyaan performa pada revisi ini.

## Versi 0.3.1 — edit langsung, partikel, visualizer, dan pintasan

- Main Media Controls, Overlay, dan Sticker Subscribe langsung mengubah project
  serta Canvas Preview; tidak ada lagi tombol Terapkan pada ketiga panel tersebut.
- Tersedia 17 jenis partikel dengan sembilan arah dan 12 gaya visualizer. Tombol
  chevron di samping Tambah Partikel/Visualizer membuka atau menutup kontrol.
- Filter render visualizer memakai sensitivitas, palet, skala frekuensi, dan
  opacity project. Chroma key asset, preview, dan ekspor memakai jarak warna RGB.
- Pintasan editor: Ctrl+1–6 halaman, Alt+1–6 tab Render, Ctrl+N/O/S/I,
  Ctrl+Enter, Ctrl+Shift+P/X, Space, Home, +/-, Delete, panah dan Shift+panah,
  Ctrl+Z/Y, Esc, serta F1. Input teks tetap memakai shortcut teks biasa.
- Di Windows, klik dua kali `Jalankan-Magic-Render-Pro.bat` untuk menjalankan
  enam perintah instalasi, pembaruan Electron, build, dan dev secara berurutan.
  Jalankan dari folder sumber yang memiliki Node.js dan npm; ini bukan installer
  aplikasi siap pakai. Pembuatan installer: `npm run dist` di Windows.

## Versi 0.3.0 — preset asset, visualizer, dan Bulk Render

- Asset Library: tombol tambah sesuai jenis, kunci yang bisa dibuka tanpa menghapus,
  tombol hapus tersendiri, dan editor preset visual overlay/sticker pada contoh media
  utama. Preset dipakai ketika asset diimpor kembali, termasuk lewat Bulk Render.
- Menu Overlay dapat memuat ulang Asset Library. Efek media dan partikel mendapat
  pilihan baru; enam visualizer mengikuti audio playlist saat preview dan export.
- Ikon reset kontrol tampil setelah nilai pada bagian tersebut berubah. Halaman
  Asset dan Setting memakai lebar area yang tersedia.
- Bulk Render menyediakan jadwal sticker per interval atau beberapa timestamp.
  Setiap video membuat file `NAMA-VIDEO-youtubetimestamp.txt` tersendiri. Kartu
  hasil selesai menyediakan tombol buka folder, buka video, reset, dan tutup.
- Pemilihan asset yang dibatalkan kembali tanpa error terminal. Jalankan
  `npm test` untuk regresi render; buat installer dengan `npm run dist` di Windows
  x64 setelah dependensi terpasang.

## Versi 0.2.9 — validasi AI Gemini dan Groq

- Model bawaan Gemini sekarang `gemini-3.5-flash-lite`. Bila project lama masih
  memakai Gemini 2.5 dan API menolaknya dengan HTTP 404, Simpan & Validasi akan
  mencari model pengganti di katalog project, mengujinya, lalu menyimpan model
  yang benar-benar berhasil. Buka Settings → AI Configuration → Muat Model jika
  project tidak menyediakan model pengganti.
- Uji Groq memakai gambar PNG 96×96 dan parameter Qwen vision saat ini. Jika
  Groq tetap mengembalikan HTTP 400, pesan provider dan ID permintaan muncul
  di UI agar penyebabnya dapat diketahui tanpa membaca stack trace terminal.
- Uji pada PC pembuat: `npm test`. Kesiapan API pada akun pengguna tetap harus
  diperiksa dengan API key asli melalui Simpan & Validasi di Settings.

## Versi 0.2.8 — persiapan distribusi Windows

- `npm run dist` memeriksa keberadaan dan kemampuan FFmpeg/FFprobe Windows
  sebelum membuat installer, lalu menaruh hasil di folder `release/`.
- Installer memakai Electron serta runtime media yang ikut dikemas. Path FFmpeg
  lama yang sudah tidak tersedia dialihkan ke salinan dalam instalasi.
- Proses tutup memiliki batas tunggu; pembersihan cache lama tidak menahan
  jendela saat aplikasi dimulai.

## Versi 0.2.1 — posisi stiker, CPU, ukuran file, daftar AI

- Posisi stiker saat export mempertahankan koordinat desain, termasuk nilai negatif yang menempatkan sebagian stiker di luar canvas. Jalur render mandiri memakai skala 720p/1080p yang sama dengan komposisi utama.
- Stiker normal tanpa keying, rotasi, fade, atau pengurangan opacity memakai overlay langsung tanpa konversi RGBA dan padding tiap frame. Alfa asli PNG tetap dihormati.
- Preset Standar CPU menggunakan H.264 `veryfast` dengan CRF 20 dan batas bitrate tetap, sehingga jalur standar lebih cepat pada tes lokal. Output VBR tetap merupakan pilihan untuk mengendalikan ukuran tanpa mengubah resolusi, FPS, atau encoding audio. Perbandingan ukuran dan waktu pada video nyata akan bergantung pada media dan mesin.
- Settings menunggu status API key tersimpan sebelum meminta daftar model otomatis. Tanpa key, daftar kosong dan muncul petunjuk; IPC tidak lagi melempar error. Input key yang belum disimpan tetap dapat dipakai melalui tombol Muat Model.
- Jalankan `node scripts/test-v5q-sticker-cpu-ai.cjs` untuk regresi posisi/alfa dan AI key kosong.

## Versi 0.2.0 — perbaikan render dan canvas

- Setelah mengimpor media utama, pilih canvas/output 720p atau 1080p. Posisi layer tetap dalam koordinat desain 16:9 dan diskalakan proporsional saat export.
- Sticker Subscribe: mode timestamp dan berulang langsung mengisi nilai jadwal yang tersimpan, durasi sekali tampil dapat diatur, dan preview serta render memakai perhitungan waktu yang sama. Cek dengan menggeser timeline ke detik yang dipilih. Proyek lama yang menyimpan jadwal kosong diperbaiki saat divalidasi.
- Stiker normal disusun sebagai YUV420 dengan alfa lurus; opacity 100% melewati filter alfa yang tidak diperlukan. Output VBR membatasi bitrate sementara preset cepat dapat dipilih untuk pekerjaan CPU. Performa dan ukuran akhir tetap bergantung pada resolusi, FPS, sumber, dan pengaturan bitrate; kompresi berkas media yang benar-benar tanpa kehilangan tidak bisa dijamin.
- Ikon reset tersedia untuk kontrol media utama, efek media, overlay, teks, partikel, dan stiker. Media utama, panel teks, dan Console Log tertutup saat pertama dibuka.
- Simpan pengaturan umum tidak memerlukan API key. Pengaturan proyek yang gagal disimpan diberitahukan terpisah. Kunci yang sudah disimpan tidak dihapus ketika kolom kosong.
- Buka **Help → User Guide** untuk alur terbaru atau **Troubleshooting** untuk pemeriksaan stiker, output, FFmpeg, dan performa.

Verifikasi lokal: `npm run build`, `node scripts/test-v5i-blend-sticker-timing.cjs`, `node scripts/test-v5o-revisions.cjs`, dan `node scripts/test-render-orchestrator.cjs`. Untuk Windows, uji aplikasi dan encoder FFmpeg pada mesin tujuan sebelum pekerjaan panjang.

Windows-first Electron desktop foundation for Magic Render Pro.

## Phase 1 status

This repository contains the Phase 1 foundation only: Electron Main Process, React Renderer, Tailwind CSS, TypeScript, secure preload bridge, explicit IPC whitelist, runtime configuration, logging foundation, and Windows packaging configuration.

## Development

1. Install Node.js 22+ and npm.
2. Run `npm install`.
3. Run `npm run dev`.

Development serves the React Renderer from the Vite development server and opens it from the Electron Main Process.

## Production validation

Run `npm run build`, then `npm start`.

Untuk membuat installer Windows x64, gunakan Node.js 22+ pada **komputer pembuat**,
kemudian jalankan `npm ci`, `npm test`, dan `npm run dist` **di Windows**.
Tahap preflight mengambil FFmpeg/FFprobe Windows dari dependensi build dan
memvalidasi encoder serta filter sebelum membuat installer. Bila pengunduhan
dependensi build diblokir, taruh `resources/ffmpeg/ffmpeg.exe` dan
`resources/ffmpeg/ffprobe.exe` secara manual (lihat README di folder itu).
Komputer tujuan hanya menjalankan installer; Node.js, Python, FFmpeg, dan
Electron tidak perlu dipasang terpisah. Installer ini hanya menargetkan Windows
x64; macOS, Linux, dan Windows ARM native memerlukan build/penyesuaian lain.
Penggunaan AI/SEO tetap memerlukan akses jaringan dan kredensial provider,
sedangkan Ollama lokal hanya tersedia bila Ollama serta modelnya dipasang.

## Security baseline

The BrowserWindow is configured with:

- `contextIsolation: true`
- `nodeIntegration: false`
- `sandbox: false` pada preload yang memuat modul lokal; renderer tetap terisolasi
- a minimal `contextBridge` API
- an explicit shared IPC channel whitelist
- argument validation at IPC handler boundaries

Renderer code does not import or access `ipcRenderer` directly.

`npm test` menjalankan pemeriksaan V5W, playlist, render, monitor, dan IPC yang
sesuai dengan struktur terbaru. Pemeriksaan statis fase lama disimpan sebagai
`npm run test:legacy`; beberapa di antaranya masih merujuk nama komponen dan
susunan modul sebelum V5W, sehingga hasilnya tidak dipakai sebagai gerbang
distribusi.

## Phase 2 status

Phase 2 adds the core project domain and project management layer:

- typed project model and schema versioning
- project creation, loading, and saving
- atomic JSON serialization to `project.json`
- recent project persistence under the application user-data directory
- Open Project Folder
- Import Main Media with extension and file existence validation
- project state held independently from future persistent global locked assets
- IPC validation for all Phase 2 project channels

Global locked assets remain a separate Phase 3 concern and are not stored in the project state.

### Phase 3 — Persistent Asset Lock System

Global locked assets are stored independently from project documents using `electron-store`. Supported global asset menus are `intro`, `overlay`, `stickerSubscribe`, and `playlist`. Lock records persist path, file metadata, configuration, and lock timestamp; missing files are pruned during application startup and can be revalidated through IPC.

## Phase 4 — Main Media Engine

Implements typed main-media metadata/probing, image-to-video command generation, resolution mapping, main-media preparation, and persistent main-media controls. FFmpeg is invoked via argument arrays with `shell:false`.


## Phase 15 checkpoint

Console logging and human-readable FFmpeg error translation are implemented. The renderer shows command, activity, progress, and translated error entries with collapse/expand and filtering. Runtime verification remains dependent on installing project dependencies.


## PHASE 18 — AI YouTube SEO & Timestamp
The application now supports provider/model selection, Main-process-only API key handling using Electron `safeStorage`, multimodal keyframe analysis, strict SEO response validation, retries, `youtubeseo.txt`, and `youtubetimestamp.txt`. OpenAI uses the Responses API with image inputs; Gemini uses `generateContent` with inline Base64 image data.

### Native FFmpeg runtime
Before packaging for Windows, place both `resources/ffmpeg/ffmpeg.exe` and `resources/ffmpeg/ffprobe.exe`. The renderer/media probe uses `ffprobe.exe` for media and audio metadata discovery; shipping only `ffmpeg.exe` is incomplete.


## Local development

Use `npm run dev` for rapid renderer testing without building an installer. Vite serves the renderer on the local development server while Electron runs the desktop shell. Renderer changes are reflected through Vite HMR; main/preload changes require restarting Electron. Use `npm run build` for production compile verification and `npm run dist` only when a Windows installer is required.

## Branding

Application branding uses the Magic Render Pro neon M/play logo. Copyright: © 2026 Radist Ginola.
## Runtime Repair Baseline
This archive is the current repair baseline. Windows development defaults to `C:\\ffmpeg\\bin\\ffmpeg.exe` and `C:\\ffmpeg\\bin\\ffprobe.exe` when those files exist; users may choose other executables in Settings. New Project uses an in-app dialog, Settings is available without an active project, and Main/Renderer application errors are forwarded to the in-app Console Log in user-friendly language.


### Chain Fix — Console Log status typing

Fixed `ConsoleLogPanel.tsx` so application log entries use an explicit `RenderStatus` (`error` for WARN/ERROR, `idle` otherwise), eliminating the renderer TypeScript mismatch while preserving the human-readable application logging flow.
