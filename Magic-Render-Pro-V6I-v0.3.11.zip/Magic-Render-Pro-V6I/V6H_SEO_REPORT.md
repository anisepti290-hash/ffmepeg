# V6H — YouTube SEO (v0.3.10)

Baseline: Magic Render Pro V6G v0.3.9. Paket sumber mencakup `dist` hasil build, seperti baseline.

- Prompt analisis merangkum adegan visual teramati dalam frasa 2–3 kata dan membedakan motivasi emosional penonton dari fakta dalam gambar. Prompt produksi meminta tepat 10 judul unik sepanjang 85–95 karakter: adegan, emoji, keyword utama beserta variasi relevan, dan motivasi/tujuan/audiens pencari.
- Parser memeriksa jumlah judul dan catatan, panjang, keyword utama, emoji, dan panjang frasa adegan. Perbaikan judul meminta ulang hanya judul jika meleset, dengan batas output yang sesuai untuk sepuluh judul.
- Deskripsi memakai keyword terkait, motivasi, serta intent dan target audiens dalam paragraf yang sudah ada. Hashtag yang disisipkan provider di paragraf dibersihkan, dan daftar hashtag ditempatkan sekali pada akhir deskripsi. Daftar tag tidak menyimpan awalan `#`.
- Bantuan dan teks UI diperbarui untuk sepuluh judul. Versi paket dinaikkan ke 0.3.10.

Berkas utama: `src/main/services/aiService/seoPipeline.ts`, `youtubeSeoService.ts`, `seoFileWriter.ts`, `seoTags.ts`, `resources/seo/promptimageSEO.md`, `src/renderer/components/YoutubeSeoPanel.tsx`, `HelpPage.tsx`; pengujian SEO V6E/V6F/V6G diperbarui. Tidak ada berkas fungsional yang dihapus.

Verifikasi: `npm test` lulus, termasuk build TypeScript/Vite dan uji render. Uji API AI langsung dan installer Windows memerlukan kunci API serta lingkungan Windows yang sesuai; keduanya tidak dijalankan dalam pengujian ini.
