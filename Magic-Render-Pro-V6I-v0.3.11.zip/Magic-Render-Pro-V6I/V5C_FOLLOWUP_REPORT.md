# Magic Render Pro v5 — perbaikan lanjutan 3

## Akar masalah dan perubahan

1. **Render Monitor:** `ffmpegRunner.ts` membaca pasangan `-progress` dari stderr, bercampur dengan keluaran diagnostik; `renderOrchestrator.ts` memakai pembagian lima tahap meskipun jumlah tahap aktual berbeda. Progres kini dibaca dari stdout khusus (`pipe:1`), dihitung berdasarkan tahap yang benar-benar dijalankan, dan speed diambil dari FFmpeg atau dihitung selama tahap aktif. `App.tsx` menerima pembaruan monitor dan estimasi sisa dari progres aktual.
2. **Pause/Cancel:** jeda sebelumnya menunggu akhir tahap, sehingga render satu tahap tidak pernah mencapai titik jeda. Sekarang proses aktif dihentikan segera, status menjadi `paused`, lalu tahap tersebut diulang saat Resume. Waktu jeda dan waktu setelah Cancel tidak ditambahkan ke jam render. Output parsial dibersihkan setelah batal/gagal.
3. **Console Log:** perintah, aktivitas, progres, dan kesalahan ditampilkan dengan penjelasan bahasa Indonesia; rincian FFmpeg mentah hanya disimpan sementara pada log pekerjaan, tidak memenuhi panel dengan data diagnostik. Duplikasi log dari polling dihilangkan.
4. **Text Overlay:** font yang terpasang di perangkat (Windows via InstalledFontCollection) dimuat ke pilihan font. Terapkan Edit mempertahankan posisi, rotasi, skala, dan dimensi teks saat ini.
5. **Cache:** tombol pembersihan di Setting serta pembersihan saat jendela ditutup hanya menyasar direktori sementara milik aplikasi. Direktori render aktif dan yang berisi asset terkunci dilewati. Penulisan log sementara ditunggu sebelum pembersihan agar direktori tidak tercipta kembali setelah dihapus.

## Berkas yang diubah

- `src/main/services/ffmpegEngine/ffmpegRunner.ts`
- `src/main/services/render/renderOrchestrator.ts`
- `src/main/services/cache/cacheManager.ts`
- `src/main/ipc/registerIpc.ts`, `settingsHandlers.ts`, `textOverlayHandlers.ts`
- `src/main/index.ts`
- `src/shared/ipc.ts`, `src/preload/index.ts`
- `src/renderer/App.tsx`, `components/ConsoleLogPanel.tsx`, `components/SettingsPanel.tsx`
- `package.json`

## Berkas baru

- `src/main/services/ffmpegEngine/deviceFonts.ts`
- `scripts/test-monitor-pause-cache.cjs`
- `V5C_FOLLOWUP_REPORT.md`

Tidak ada berkas yang dihapus.

## Pemeriksaan

- `npm run build`, `npm run typecheck`, `npm run test:render-engine`, `npm run test:orchestrator`, `npm run test:cache`, `npm run test:critical-hotfixes`, dan `npm run test:monitor-pause-cache` lulus pada lingkungan Linux dengan FFmpeg.
- Uji langsung mencakup progres dan speed yang bergerak, pause/resume satu tahap, cancel saat berjalan atau dijeda, waktu render yang membeku, output parsial, dan asset terkunci saat membersihkan cache.
- Font Windows, tampilan Electron di Windows, serta instalasi `.exe` memerlukan pengujian pada perangkat Windows; paket ini berupa source dan hasil build, bukan installer Windows.
